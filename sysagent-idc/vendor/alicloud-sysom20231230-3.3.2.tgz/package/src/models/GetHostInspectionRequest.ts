// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetHostInspectionRequest extends $dara.Model {
  inspectionId?: string;
  static names(): { [key: string]: string } {
    return {
      inspectionId: 'inspectionId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      inspectionId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

