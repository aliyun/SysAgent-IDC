// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetVllmTracingResultResponseBodyData extends $dara.Model {
  agentAnalysis?: string;
  ossPath?: string;
  ossUrl?: string;
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      agentAnalysis: 'agentAnalysis',
      ossPath: 'ossPath',
      ossUrl: 'ossUrl',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentAnalysis: 'string',
      ossPath: 'string',
      ossUrl: 'string',
      taskId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetVllmTracingResultResponseBody extends $dara.Model {
  code?: string;
  data?: GetVllmTracingResultResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetVllmTracingResultResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

