// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListVllmTracingJobsResponseBodyDataRecordsParams extends $dara.Model {
  endTime?: number;
  serviceName?: string;
  startTime?: number;
  static names(): { [key: string]: string } {
    return {
      endTime: 'endTime',
      serviceName: 'serviceName',
      startTime: 'startTime',
    };
  }

  static types(): { [key: string]: any } {
    return {
      endTime: 'number',
      serviceName: 'string',
      startTime: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListVllmTracingJobsResponseBodyDataRecords extends $dara.Model {
  params?: ListVllmTracingJobsResponseBodyDataRecordsParams;
  status?: string;
  submitTime?: string;
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      params: 'params',
      status: 'status',
      submitTime: 'submitTime',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      params: ListVllmTracingJobsResponseBodyDataRecordsParams,
      status: 'string',
      submitTime: 'string',
      taskId: 'string',
    };
  }

  validate() {
    if(this.params && typeof (this.params as any).validate === 'function') {
      (this.params as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListVllmTracingJobsResponseBodyData extends $dara.Model {
  page?: number;
  pageSize?: number;
  records?: ListVllmTracingJobsResponseBodyDataRecords[];
  total?: number;
  totalPages?: number;
  static names(): { [key: string]: string } {
    return {
      page: 'page',
      pageSize: 'pageSize',
      records: 'records',
      total: 'total',
      totalPages: 'totalPages',
    };
  }

  static types(): { [key: string]: any } {
    return {
      page: 'number',
      pageSize: 'number',
      records: { 'type': 'array', 'itemType': ListVllmTracingJobsResponseBodyDataRecords },
      total: 'number',
      totalPages: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.records)) {
      $dara.Model.validateArray(this.records);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListVllmTracingJobsResponseBody extends $dara.Model {
  /**
   * @example
   * 200
   */
  code?: string;
  data?: ListVllmTracingJobsResponseBodyData;
  maxResults?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 你好，世界！
   */
  message?: string;
  nextToken?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ListVllmTracingJobsResponseBodyData,
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

