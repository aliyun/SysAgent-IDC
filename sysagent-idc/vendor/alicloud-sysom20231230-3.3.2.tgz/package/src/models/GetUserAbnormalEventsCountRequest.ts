// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetUserAbnormalEventsCountRequest extends $dara.Model {
  xDebugId?: string;
  cluster?: string;
  end?: number;
  instance?: string;
  level?: string;
  namespace?: string;
  pod?: string;
  showPod?: number;
  start?: number;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      cluster: 'cluster',
      end: 'end',
      instance: 'instance',
      level: 'level',
      namespace: 'namespace',
      pod: 'pod',
      showPod: 'showPod',
      start: 'start',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      cluster: 'string',
      end: 'number',
      instance: 'string',
      level: 'string',
      namespace: 'string',
      pod: 'string',
      showPod: 'number',
      start: 'number',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

