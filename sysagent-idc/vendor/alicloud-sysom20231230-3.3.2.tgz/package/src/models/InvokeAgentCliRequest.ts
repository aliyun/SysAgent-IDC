// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class InvokeAgentCliRequestTarget extends $dara.Model {
  /**
   * @example
   * i-xxx
   */
  instanceId?: string;
  /**
   * @example
   * cn-hangzhou
   */
  region?: string;
  /**
   * @example
   * ecs
   */
  scope?: string;
  static names(): { [key: string]: string } {
    return {
      instanceId: 'instanceId',
      region: 'region',
      scope: 'scope',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instanceId: 'string',
      region: 'string',
      scope: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * memory.memgraph.deep
   */
  actionId?: string;
  params?: string;
  target?: InvokeAgentCliRequestTarget;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      actionId: 'actionId',
      params: 'params',
      target: 'target',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      actionId: 'string',
      params: 'string',
      target: InvokeAgentCliRequestTarget,
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    if(this.target && typeof (this.target as any).validate === 'function') {
      (this.target as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

