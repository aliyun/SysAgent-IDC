// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetUserAbnormalyDistributionResponseBodyData extends $dara.Model {
  cluster?: any;
  events?: any;
  level?: any;
  static names(): { [key: string]: string } {
    return {
      cluster: 'cluster',
      events: 'events',
      level: 'level',
    };
  }

  static types(): { [key: string]: any } {
    return {
      cluster: 'any',
      events: 'any',
      level: 'any',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetUserAbnormalyDistributionResponseBody extends $dara.Model {
  code?: string;
  data?: GetUserAbnormalyDistributionResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetUserAbnormalyDistributionResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

