// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListInspectionScheduleRunsRequest extends $dara.Model {
  current?: number;
  pageSize?: number;
  /**
   * @example
   * insp-sched-2f1c9d4e-6b7a-4c31-9a52-0e8f7d6c5b4a
   */
  scheduleId?: string;
  static names(): { [key: string]: string } {
    return {
      current: 'current',
      pageSize: 'pageSize',
      scheduleId: 'scheduleId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      current: 'number',
      pageSize: 'number',
      scheduleId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

