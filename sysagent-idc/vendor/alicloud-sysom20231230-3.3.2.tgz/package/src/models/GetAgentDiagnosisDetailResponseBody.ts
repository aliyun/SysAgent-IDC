// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentDiagnosisDetailResponseBodyDataEventsList extends $dara.Model {
  agentName?: string;
  conversationId?: string;
  detail?: string;
  interruptionId?: string;
  occurredAt?: number;
  pid?: number;
  resolved?: boolean;
  sessionId?: string;
  severity?: string;
  traceId?: string;
  type?: string;
  static names(): { [key: string]: string } {
    return {
      agentName: 'agentName',
      conversationId: 'conversationId',
      detail: 'detail',
      interruptionId: 'interruptionId',
      occurredAt: 'occurredAt',
      pid: 'pid',
      resolved: 'resolved',
      sessionId: 'sessionId',
      severity: 'severity',
      traceId: 'traceId',
      type: 'type',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentName: 'string',
      conversationId: 'string',
      detail: 'string',
      interruptionId: 'string',
      occurredAt: 'number',
      pid: 'number',
      resolved: 'boolean',
      sessionId: 'string',
      severity: 'string',
      traceId: 'string',
      type: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBodyDataEvents extends $dara.Model {
  list?: GetAgentDiagnosisDetailResponseBodyDataEventsList[];
  page?: number;
  pageSize?: number;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      list: 'list',
      page: 'page',
      pageSize: 'pageSize',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      list: { 'type': 'array', 'itemType': GetAgentDiagnosisDetailResponseBodyDataEventsList },
      page: 'number',
      pageSize: 'number',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.list)) {
      $dara.Model.validateArray(this.list);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBodyDataSummarySeverityStats extends $dara.Model {
  critical?: number;
  high?: number;
  low?: number;
  medium?: number;
  static names(): { [key: string]: string } {
    return {
      critical: 'critical',
      high: 'high',
      low: 'low',
      medium: 'medium',
    };
  }

  static types(): { [key: string]: any } {
    return {
      critical: 'number',
      high: 'number',
      low: 'number',
      medium: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBodyDataSummaryTypeStats extends $dara.Model {
  agentCrash?: number;
  authError?: number;
  contextOverflow?: number;
  llmError?: number;
  networkTimeout?: number;
  rateLimit?: number;
  safetyFilter?: number;
  serviceUnavailable?: number;
  sseTruncated?: number;
  tokenLimit?: number;
  static names(): { [key: string]: string } {
    return {
      agentCrash: 'agentCrash',
      authError: 'authError',
      contextOverflow: 'contextOverflow',
      llmError: 'llmError',
      networkTimeout: 'networkTimeout',
      rateLimit: 'rateLimit',
      safetyFilter: 'safetyFilter',
      serviceUnavailable: 'serviceUnavailable',
      sseTruncated: 'sseTruncated',
      tokenLimit: 'tokenLimit',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentCrash: 'number',
      authError: 'number',
      contextOverflow: 'number',
      llmError: 'number',
      networkTimeout: 'number',
      rateLimit: 'number',
      safetyFilter: 'number',
      serviceUnavailable: 'number',
      sseTruncated: 'number',
      tokenLimit: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBodyDataSummary extends $dara.Model {
  agentName?: string;
  healthScore?: number;
  instance?: string;
  severityStats?: GetAgentDiagnosisDetailResponseBodyDataSummarySeverityStats;
  status?: string;
  subStatus?: string;
  taskId?: string;
  timeRangeEnd?: string;
  timeRangeStart?: string;
  totalConversations?: number;
  totalIssues?: number;
  totalSessions?: number;
  typeStats?: GetAgentDiagnosisDetailResponseBodyDataSummaryTypeStats;
  unresolvedCount?: number;
  static names(): { [key: string]: string } {
    return {
      agentName: 'agentName',
      healthScore: 'healthScore',
      instance: 'instance',
      severityStats: 'severityStats',
      status: 'status',
      subStatus: 'subStatus',
      taskId: 'taskId',
      timeRangeEnd: 'timeRangeEnd',
      timeRangeStart: 'timeRangeStart',
      totalConversations: 'totalConversations',
      totalIssues: 'totalIssues',
      totalSessions: 'totalSessions',
      typeStats: 'typeStats',
      unresolvedCount: 'unresolvedCount',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentName: 'string',
      healthScore: 'number',
      instance: 'string',
      severityStats: GetAgentDiagnosisDetailResponseBodyDataSummarySeverityStats,
      status: 'string',
      subStatus: 'string',
      taskId: 'string',
      timeRangeEnd: 'string',
      timeRangeStart: 'string',
      totalConversations: 'number',
      totalIssues: 'number',
      totalSessions: 'number',
      typeStats: GetAgentDiagnosisDetailResponseBodyDataSummaryTypeStats,
      unresolvedCount: 'number',
    };
  }

  validate() {
    if(this.severityStats && typeof (this.severityStats as any).validate === 'function') {
      (this.severityStats as any).validate();
    }
    if(this.typeStats && typeof (this.typeStats as any).validate === 'function') {
      (this.typeStats as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBodyData extends $dara.Model {
  events?: GetAgentDiagnosisDetailResponseBodyDataEvents;
  summary?: GetAgentDiagnosisDetailResponseBodyDataSummary;
  static names(): { [key: string]: string } {
    return {
      events: 'events',
      summary: 'summary',
    };
  }

  static types(): { [key: string]: any } {
    return {
      events: GetAgentDiagnosisDetailResponseBodyDataEvents,
      summary: GetAgentDiagnosisDetailResponseBodyDataSummary,
    };
  }

  validate() {
    if(this.events && typeof (this.events as any).validate === 'function') {
      (this.events as any).validate();
    }
    if(this.summary && typeof (this.summary as any).validate === 'function') {
      (this.summary as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisDetailResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentDiagnosisDetailResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentDiagnosisDetailResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

