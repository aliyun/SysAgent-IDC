// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListInspectionItemThresholdsResponseBodyDataItemsThresholdRange extends $dara.Model {
  max?: number;
  min?: number;
  static names(): { [key: string]: string } {
    return {
      max: 'max',
      min: 'min',
    };
  }

  static types(): { [key: string]: any } {
    return {
      max: 'number',
      min: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListInspectionItemThresholdsResponseBodyDataItems extends $dara.Model {
  defaultThresholds?: number[];
  effectiveThresholds?: number[];
  itemName?: string;
  levelMapping?: string[];
  source?: string;
  target?: string;
  thresholdConfigurable?: boolean;
  thresholdRange?: ListInspectionItemThresholdsResponseBodyDataItemsThresholdRange;
  title?: string;
  unit?: string;
  updatedAt?: string;
  userThresholds?: number[];
  static names(): { [key: string]: string } {
    return {
      defaultThresholds: 'defaultThresholds',
      effectiveThresholds: 'effectiveThresholds',
      itemName: 'itemName',
      levelMapping: 'levelMapping',
      source: 'source',
      target: 'target',
      thresholdConfigurable: 'thresholdConfigurable',
      thresholdRange: 'thresholdRange',
      title: 'title',
      unit: 'unit',
      updatedAt: 'updatedAt',
      userThresholds: 'userThresholds',
    };
  }

  static types(): { [key: string]: any } {
    return {
      defaultThresholds: { 'type': 'array', 'itemType': 'number' },
      effectiveThresholds: { 'type': 'array', 'itemType': 'number' },
      itemName: 'string',
      levelMapping: { 'type': 'array', 'itemType': 'string' },
      source: 'string',
      target: 'string',
      thresholdConfigurable: 'boolean',
      thresholdRange: ListInspectionItemThresholdsResponseBodyDataItemsThresholdRange,
      title: 'string',
      unit: 'string',
      updatedAt: 'string',
      userThresholds: { 'type': 'array', 'itemType': 'number' },
    };
  }

  validate() {
    if(Array.isArray(this.defaultThresholds)) {
      $dara.Model.validateArray(this.defaultThresholds);
    }
    if(Array.isArray(this.effectiveThresholds)) {
      $dara.Model.validateArray(this.effectiveThresholds);
    }
    if(Array.isArray(this.levelMapping)) {
      $dara.Model.validateArray(this.levelMapping);
    }
    if(this.thresholdRange && typeof (this.thresholdRange as any).validate === 'function') {
      (this.thresholdRange as any).validate();
    }
    if(Array.isArray(this.userThresholds)) {
      $dara.Model.validateArray(this.userThresholds);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListInspectionItemThresholdsResponseBodyData extends $dara.Model {
  items?: ListInspectionItemThresholdsResponseBodyDataItems[];
  metricSourceRequirement?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      items: 'items',
      metricSourceRequirement: 'metricSourceRequirement',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      items: { 'type': 'array', 'itemType': ListInspectionItemThresholdsResponseBodyDataItems },
      metricSourceRequirement: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.items)) {
      $dara.Model.validateArray(this.items);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListInspectionItemThresholdsResponseBody extends $dara.Model {
  code?: string;
  data?: ListInspectionItemThresholdsResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ListInspectionItemThresholdsResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

