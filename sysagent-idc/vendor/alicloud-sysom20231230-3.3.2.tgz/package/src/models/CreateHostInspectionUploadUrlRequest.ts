// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateHostInspectionUploadUrlRequest extends $dara.Model {
  arch?: string;
  contentType?: string;
  /**
   * @example
   * 0f0c9d2a4b6c
   */
  deviceId?: string;
  expiresIn?: number;
  /**
   * @example
   * host-01
   */
  hostname?: string;
  machineId?: string;
  os?: string;
  static names(): { [key: string]: string } {
    return {
      arch: 'arch',
      contentType: 'contentType',
      deviceId: 'deviceId',
      expiresIn: 'expiresIn',
      hostname: 'hostname',
      machineId: 'machineId',
      os: 'os',
    };
  }

  static types(): { [key: string]: any } {
    return {
      arch: 'string',
      contentType: 'string',
      deviceId: 'string',
      expiresIn: 'number',
      hostname: 'string',
      machineId: 'string',
      os: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

