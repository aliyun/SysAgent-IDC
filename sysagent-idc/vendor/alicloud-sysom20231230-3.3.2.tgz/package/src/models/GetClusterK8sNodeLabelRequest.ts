// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetClusterK8sNodeLabelRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  clusterId?: string;
  filter?: string;
  instances?: string;
  mode?: string;
  nodeNames?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  region?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      clusterId: 'clusterId',
      filter: 'filter',
      instances: 'instances',
      mode: 'mode',
      nodeNames: 'nodeNames',
      region: 'region',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      clusterId: 'string',
      filter: 'string',
      instances: 'string',
      mode: 'string',
      nodeNames: 'string',
      region: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

