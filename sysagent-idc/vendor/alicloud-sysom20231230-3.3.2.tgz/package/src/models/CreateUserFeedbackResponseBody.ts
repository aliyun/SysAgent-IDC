// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateUserFeedbackResponseBodyData extends $dara.Model {
  /**
   * @remarks
   * 反馈记录 ID
   */
  feedbackId?: string;
  static names(): { [key: string]: string } {
    return {
      feedbackId: 'feedbackId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      feedbackId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CreateUserFeedbackResponseBody extends $dara.Model {
  code?: string;
  data?: CreateUserFeedbackResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: CreateUserFeedbackResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

