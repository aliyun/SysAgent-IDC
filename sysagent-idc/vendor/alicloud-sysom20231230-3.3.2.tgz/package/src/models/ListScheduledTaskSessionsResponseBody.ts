// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListScheduledTaskSessionsResponseBodyData extends $dara.Model {
  errorCode?: string;
  finishedAt?: string;
  runId?: string;
  scheduledAt?: string;
  sessionId?: string;
  startedAt?: string;
  status?: string;
  taskId?: number;
  static names(): { [key: string]: string } {
    return {
      errorCode: 'errorCode',
      finishedAt: 'finishedAt',
      runId: 'runId',
      scheduledAt: 'scheduledAt',
      sessionId: 'sessionId',
      startedAt: 'startedAt',
      status: 'status',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      errorCode: 'string',
      finishedAt: 'string',
      runId: 'string',
      scheduledAt: 'string',
      sessionId: 'string',
      startedAt: 'string',
      status: 'string',
      taskId: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListScheduledTaskSessionsResponseBody extends $dara.Model {
  code?: string;
  data?: ListScheduledTaskSessionsResponseBodyData[];
  message?: string;
  requestId?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListScheduledTaskSessionsResponseBodyData },
      message: 'string',
      requestId: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

