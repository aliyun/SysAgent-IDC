// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateEcsModelChallengeResponseBodyData extends $dara.Model {
  audience?: string;
  challengeId?: string;
  expiresAt?: string;
  serverTime?: string;
  static names(): { [key: string]: string } {
    return {
      audience: 'audience',
      challengeId: 'challengeId',
      expiresAt: 'expiresAt',
      serverTime: 'serverTime',
    };
  }

  static types(): { [key: string]: any } {
    return {
      audience: 'string',
      challengeId: 'string',
      expiresAt: 'string',
      serverTime: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CreateEcsModelChallengeResponseBody extends $dara.Model {
  code?: string;
  data?: CreateEcsModelChallengeResponseBodyData;
  message?: string;
  requestId?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  success?: boolean;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
      success: 'success',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: CreateEcsModelChallengeResponseBodyData,
      message: 'string',
      requestId: 'string',
      success: 'boolean',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

