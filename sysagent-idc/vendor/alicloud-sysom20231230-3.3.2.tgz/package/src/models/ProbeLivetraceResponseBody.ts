// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ProbeLivetraceResponseBodyDataModules extends $dara.Model {
  aiMonitor?: boolean;
  gperf?: boolean;
  gpuMon?: boolean;
  gpuTopo?: boolean;
  kmsg?: boolean;
  meta?: boolean;
  metrics?: boolean;
  mullprof?: boolean;
  pouchPid?: boolean;
  stdLog?: boolean;
  static names(): { [key: string]: string } {
    return {
      aiMonitor: 'aiMonitor',
      gperf: 'gperf',
      gpuMon: 'gpuMon',
      gpuTopo: 'gpuTopo',
      kmsg: 'kmsg',
      meta: 'meta',
      metrics: 'metrics',
      mullprof: 'mullprof',
      pouchPid: 'pouchPid',
      stdLog: 'stdLog',
    };
  }

  static types(): { [key: string]: any } {
    return {
      aiMonitor: 'boolean',
      gperf: 'boolean',
      gpuMon: 'boolean',
      gpuTopo: 'boolean',
      kmsg: 'boolean',
      meta: 'boolean',
      metrics: 'boolean',
      mullprof: 'boolean',
      pouchPid: 'boolean',
      stdLog: 'boolean',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ProbeLivetraceResponseBodyData extends $dara.Model {
  /**
   * @example
   * true
   */
  healthy?: boolean;
  /**
   * @example
   * i-example
   */
  instance?: string;
  modules?: ProbeLivetraceResponseBodyDataModules;
  /**
   * @example
   * 1727155200
   */
  reportTime?: number;
  static names(): { [key: string]: string } {
    return {
      healthy: 'healthy',
      instance: 'instance',
      modules: 'modules',
      reportTime: 'reportTime',
    };
  }

  static types(): { [key: string]: any } {
    return {
      healthy: 'boolean',
      instance: 'string',
      modules: ProbeLivetraceResponseBodyDataModules,
      reportTime: 'number',
    };
  }

  validate() {
    if(this.modules && typeof (this.modules as any).validate === 'function') {
      (this.modules as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ProbeLivetraceResponseBody extends $dara.Model {
  /**
   * @example
   * Success
   */
  code?: string;
  data?: ProbeLivetraceResponseBodyData;
  /**
   * @example
   * success
   */
  message?: string;
  requestId?: string;
  /**
   * @example
   * true
   */
  success?: boolean;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
      success: 'success',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ProbeLivetraceResponseBodyData,
      message: 'string',
      requestId: 'string',
      success: 'boolean',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

