// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListUserAbnormalyEventsRequest extends $dara.Model {
  xDebugId?: string;
  cluster?: string;
  current?: number;
  end?: number;
  event?: string;
  instance?: string;
  level?: string;
  maxResults?: number;
  nextToken?: string;
  pageSize?: number;
  start?: number;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      cluster: 'cluster',
      current: 'current',
      end: 'end',
      event: 'event',
      instance: 'instance',
      level: 'level',
      maxResults: 'maxResults',
      nextToken: 'nextToken',
      pageSize: 'pageSize',
      start: 'start',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      cluster: 'string',
      current: 'number',
      end: 'number',
      event: 'string',
      instance: 'string',
      level: 'string',
      maxResults: 'number',
      nextToken: 'string',
      pageSize: 'number',
      start: 'number',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

