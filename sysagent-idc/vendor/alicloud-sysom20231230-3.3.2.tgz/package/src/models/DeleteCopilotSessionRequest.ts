// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class DeleteCopilotSessionRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * The agent identifier.
   * 
   * @example
   * sre_agent
   */
  agentId?: string;
  /**
   * @remarks
   * The session ID.
   * 
   * This parameter is required.
   * 
   * @example
   * c356bc310e4345c3a602a2912322ad21
   */
  sessionId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      agentId: 'agentId',
      sessionId: 'sessionId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      agentId: 'string',
      sessionId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

