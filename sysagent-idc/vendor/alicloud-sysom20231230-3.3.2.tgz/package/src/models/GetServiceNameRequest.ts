// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetServiceNameRequest extends $dara.Model {
  xDebugId?: string;
  current?: number;
  endTime?: number;
  maxResults?: number;
  nextToken?: string;
  pageSize?: number;
  region?: string;
  startTime?: number;
  workspace?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      current: 'current',
      endTime: 'endTime',
      maxResults: 'maxResults',
      nextToken: 'nextToken',
      pageSize: 'pageSize',
      region: 'region',
      startTime: 'startTime',
      workspace: 'workspace',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      current: 'number',
      endTime: 'number',
      maxResults: 'number',
      nextToken: 'string',
      pageSize: 'number',
      region: 'string',
      startTime: 'number',
      workspace: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

