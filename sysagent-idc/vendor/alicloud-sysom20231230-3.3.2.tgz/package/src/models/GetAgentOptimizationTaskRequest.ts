// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentOptimizationTaskRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * a1b2c3d4_e5f6_7890_abcd_ef1234567890
   */
  taskId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      taskId: 'taskId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      taskId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

