// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetClusterHealthCountResponseBodyData extends $dara.Model {
  errorCount?: number;
  healthCount?: number;
  potentialCount?: number;
  totalCount?: number;
  warningCount?: number;
  static names(): { [key: string]: string } {
    return {
      errorCount: 'errorCount',
      healthCount: 'healthCount',
      potentialCount: 'potentialCount',
      totalCount: 'totalCount',
      warningCount: 'warningCount',
    };
  }

  static types(): { [key: string]: any } {
    return {
      errorCount: 'number',
      healthCount: 'number',
      potentialCount: 'number',
      totalCount: 'number',
      warningCount: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetClusterHealthCountResponseBody extends $dara.Model {
  code?: string;
  data?: GetClusterHealthCountResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetClusterHealthCountResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

