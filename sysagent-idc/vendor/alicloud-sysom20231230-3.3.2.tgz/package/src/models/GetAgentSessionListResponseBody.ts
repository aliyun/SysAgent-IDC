// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentSessionListResponseBodyDataSessionsConversations extends $dara.Model {
  callCount?: number;
  conversationId?: string;
  durationMs?: number;
  hasError?: boolean;
  inputTokens?: number;
  outputTokens?: number;
  startTime?: string;
  totalTokens?: number;
  userQuery?: string;
  static names(): { [key: string]: string } {
    return {
      callCount: 'callCount',
      conversationId: 'conversationId',
      durationMs: 'durationMs',
      hasError: 'hasError',
      inputTokens: 'inputTokens',
      outputTokens: 'outputTokens',
      startTime: 'startTime',
      totalTokens: 'totalTokens',
      userQuery: 'userQuery',
    };
  }

  static types(): { [key: string]: any } {
    return {
      callCount: 'number',
      conversationId: 'string',
      durationMs: 'number',
      hasError: 'boolean',
      inputTokens: 'number',
      outputTokens: 'number',
      startTime: 'string',
      totalTokens: 'number',
      userQuery: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentSessionListResponseBodyDataSessions extends $dara.Model {
  conversationCount?: number;
  conversations?: GetAgentSessionListResponseBodyDataSessionsConversations[];
  durationMs?: number;
  inputTokens?: number;
  model?: string;
  outputTokens?: number;
  sessionId?: string;
  startTime?: string;
  totalTokens?: number;
  static names(): { [key: string]: string } {
    return {
      conversationCount: 'conversationCount',
      conversations: 'conversations',
      durationMs: 'durationMs',
      inputTokens: 'inputTokens',
      model: 'model',
      outputTokens: 'outputTokens',
      sessionId: 'sessionId',
      startTime: 'startTime',
      totalTokens: 'totalTokens',
    };
  }

  static types(): { [key: string]: any } {
    return {
      conversationCount: 'number',
      conversations: { 'type': 'array', 'itemType': GetAgentSessionListResponseBodyDataSessionsConversations },
      durationMs: 'number',
      inputTokens: 'number',
      model: 'string',
      outputTokens: 'number',
      sessionId: 'string',
      startTime: 'string',
      totalTokens: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.conversations)) {
      $dara.Model.validateArray(this.conversations);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentSessionListResponseBodyData extends $dara.Model {
  page?: number;
  pageSize?: number;
  sessions?: GetAgentSessionListResponseBodyDataSessions[];
  total?: number;
  static names(): { [key: string]: string } {
    return {
      page: 'page',
      pageSize: 'pageSize',
      sessions: 'sessions',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      page: 'number',
      pageSize: 'number',
      sessions: { 'type': 'array', 'itemType': GetAgentSessionListResponseBodyDataSessions },
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.sessions)) {
      $dara.Model.validateArray(this.sessions);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentSessionListResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentSessionListResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentSessionListResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

