// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetVllmModelNameRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @example
   * 1768551700000
   */
  endTime?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  region?: string;
  /**
   * @example
   * my-vllm-service
   */
  serviceName?: string;
  /**
   * @example
   * 1768551690000
   */
  startTime?: number;
  workspace?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      endTime: 'endTime',
      region: 'region',
      serviceName: 'serviceName',
      startTime: 'startTime',
      workspace: 'workspace',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      endTime: 'number',
      region: 'string',
      serviceName: 'string',
      startTime: 'number',
      workspace: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

