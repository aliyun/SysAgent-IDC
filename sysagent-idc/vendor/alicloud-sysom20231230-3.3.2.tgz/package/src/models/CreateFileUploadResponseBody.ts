// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateFileUploadResponseBodyData extends $dara.Model {
  chunkSize?: number;
  fileId?: string;
  maxParts?: number;
  static names(): { [key: string]: string } {
    return {
      chunkSize: 'chunkSize',
      fileId: 'fileId',
      maxParts: 'maxParts',
    };
  }

  static types(): { [key: string]: any } {
    return {
      chunkSize: 'number',
      fileId: 'string',
      maxParts: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CreateFileUploadResponseBody extends $dara.Model {
  code?: string;
  data?: CreateFileUploadResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: CreateFileUploadResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

