// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetClusterK8sInfoRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  clusterId?: string;
  infoType?: string;
  labelSelector?: string;
  namespace?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  region?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      clusterId: 'clusterId',
      infoType: 'infoType',
      labelSelector: 'labelSelector',
      namespace: 'namespace',
      region: 'region',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      clusterId: 'string',
      infoType: 'string',
      labelSelector: 'string',
      namespace: 'string',
      region: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

