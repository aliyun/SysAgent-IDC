// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ConnectIdcChannelRequest extends $dara.Model {
  /**
   * @remarks
   * IDC Connector 实例标识名
   * 
   * @example
   * idc-bj-prod-01
   */
  connectorName?: string;
  static names(): { [key: string]: string } {
    return {
      connectorName: 'connectorName',
    };
  }

  static types(): { [key: string]: any } {
    return {
      connectorName: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

