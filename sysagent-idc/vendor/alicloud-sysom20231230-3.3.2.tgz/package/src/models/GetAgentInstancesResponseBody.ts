// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentInstancesResponseBodyDataInstances extends $dara.Model {
  instanceId?: string;
  instanceName?: string;
  static names(): { [key: string]: string } {
    return {
      instanceId: 'instanceId',
      instanceName: 'instanceName',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instanceId: 'string',
      instanceName: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentInstancesResponseBodyData extends $dara.Model {
  count?: number;
  instances?: GetAgentInstancesResponseBodyDataInstances[];
  static names(): { [key: string]: string } {
    return {
      count: 'count',
      instances: 'instances',
    };
  }

  static types(): { [key: string]: any } {
    return {
      count: 'number',
      instances: { 'type': 'array', 'itemType': GetAgentInstancesResponseBodyDataInstances },
    };
  }

  validate() {
    if(Array.isArray(this.instances)) {
      $dara.Model.validateArray(this.instances);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentInstancesResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentInstancesResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentInstancesResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

