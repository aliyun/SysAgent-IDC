// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetClusterK8sInfoResponseBodyData extends $dara.Model {
  metadata?: string;
  name?: string;
  static names(): { [key: string]: string } {
    return {
      metadata: 'metadata',
      name: 'name',
    };
  }

  static types(): { [key: string]: any } {
    return {
      metadata: 'string',
      name: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetClusterK8sInfoResponseBody extends $dara.Model {
  code?: string;
  data?: GetClusterK8sInfoResponseBodyData[];
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': GetClusterK8sInfoResponseBodyData },
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

