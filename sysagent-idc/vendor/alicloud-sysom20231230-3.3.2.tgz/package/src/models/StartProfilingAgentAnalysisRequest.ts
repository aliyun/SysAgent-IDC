// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class StartProfilingAgentAnalysisRequestFiles extends $dara.Model {
  content?: string;
  name?: string;
  type?: string;
  static names(): { [key: string]: string } {
    return {
      content: 'content',
      name: 'name',
      type: 'type',
    };
  }

  static types(): { [key: string]: any } {
    return {
      content: 'string',
      name: 'string',
      type: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class StartProfilingAgentAnalysisRequestParams extends $dara.Model {
  analysisId?: string[];
  analysisMode?: string;
  fileFilter?: string;
  static names(): { [key: string]: string } {
    return {
      analysisId: 'analysisId',
      analysisMode: 'analysis_mode',
      fileFilter: 'file_filter',
    };
  }

  static types(): { [key: string]: any } {
    return {
      analysisId: { 'type': 'array', 'itemType': 'string' },
      analysisMode: 'string',
      fileFilter: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.analysisId)) {
      $dara.Model.validateArray(this.analysisId);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class StartProfilingAgentAnalysisRequest extends $dara.Model {
  xDebugId?: string;
  files?: StartProfilingAgentAnalysisRequestFiles[];
  params?: StartProfilingAgentAnalysisRequestParams;
  /**
   * @example
   * ai
   */
  profilingType?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 分析性能瓶颈
   */
  prompt?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      files: 'files',
      params: 'params',
      profilingType: 'profiling_type',
      prompt: 'prompt',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      files: { 'type': 'array', 'itemType': StartProfilingAgentAnalysisRequestFiles },
      params: StartProfilingAgentAnalysisRequestParams,
      profilingType: 'string',
      prompt: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.files)) {
      $dara.Model.validateArray(this.files);
    }
    if(this.params && typeof (this.params as any).validate === 'function') {
      (this.params as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

