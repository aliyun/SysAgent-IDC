// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetHostInspectionResponseBodyError extends $dara.Model {
  code?: string;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      message: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetHostInspectionResponseBodyObject extends $dara.Model {
  bytes?: number;
  objectKey?: string;
  sha256?: string;
  static names(): { [key: string]: string } {
    return {
      bytes: 'bytes',
      objectKey: 'objectKey',
      sha256: 'sha256',
    };
  }

  static types(): { [key: string]: any } {
    return {
      bytes: 'number',
      objectKey: 'string',
      sha256: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetHostInspectionResponseBody extends $dara.Model {
  coverage?: number;
  createdAt?: string;
  deviceId?: string;
  error?: GetHostInspectionResponseBodyError;
  finishedAt?: string;
  hostname?: string;
  inspectionId?: string;
  object?: GetHostInspectionResponseBodyObject;
  phase?: string;
  progress?: number;
  reportId?: string;
  reportStatus?: string;
  retryable?: boolean;
  status?: string;
  uid?: string;
  static names(): { [key: string]: string } {
    return {
      coverage: 'coverage',
      createdAt: 'createdAt',
      deviceId: 'deviceId',
      error: 'error',
      finishedAt: 'finishedAt',
      hostname: 'hostname',
      inspectionId: 'inspectionId',
      object: 'object',
      phase: 'phase',
      progress: 'progress',
      reportId: 'reportId',
      reportStatus: 'reportStatus',
      retryable: 'retryable',
      status: 'status',
      uid: 'uid',
    };
  }

  static types(): { [key: string]: any } {
    return {
      coverage: 'number',
      createdAt: 'string',
      deviceId: 'string',
      error: GetHostInspectionResponseBodyError,
      finishedAt: 'string',
      hostname: 'string',
      inspectionId: 'string',
      object: GetHostInspectionResponseBodyObject,
      phase: 'string',
      progress: 'number',
      reportId: 'string',
      reportStatus: 'string',
      retryable: 'boolean',
      status: 'string',
      uid: 'string',
    };
  }

  validate() {
    if(this.error && typeof (this.error as any).validate === 'function') {
      (this.error as any).validate();
    }
    if(this.object && typeof (this.object as any).validate === 'function') {
      (this.object as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

