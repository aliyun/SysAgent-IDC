// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class TriggerInspectionScheduleResponseBodyData extends $dara.Model {
  runId?: string;
  static names(): { [key: string]: string } {
    return {
      runId: 'runId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      runId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class TriggerInspectionScheduleResponseBody extends $dara.Model {
  code?: string;
  data?: TriggerInspectionScheduleResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: TriggerInspectionScheduleResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

