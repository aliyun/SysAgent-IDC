// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class SubmitHostInspectionRequestHost extends $dara.Model {
  arch?: string;
  hostname?: string;
  machineId?: string;
  os?: string;
  static names(): { [key: string]: string } {
    return {
      arch: 'arch',
      hostname: 'hostname',
      machineId: 'machineId',
      os: 'os',
    };
  }

  static types(): { [key: string]: any } {
    return {
      arch: 'string',
      hostname: 'string',
      machineId: 'string',
      os: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class SubmitHostInspectionRequest extends $dara.Model {
  /**
   * @remarks
   * This parameter is required.
   */
  bytes?: number;
  collectedAt?: string;
  contentType?: string;
  host?: SubmitHostInspectionRequestHost;
  /**
   * @remarks
   * This parameter is required.
   */
  objectKey?: string;
  profile?: string;
  schemaVersion?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
   */
  sha256?: string;
  window?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  inspectionId?: string;
  static names(): { [key: string]: string } {
    return {
      bytes: 'bytes',
      collectedAt: 'collectedAt',
      contentType: 'contentType',
      host: 'host',
      objectKey: 'objectKey',
      profile: 'profile',
      schemaVersion: 'schemaVersion',
      sha256: 'sha256',
      window: 'window',
      inspectionId: 'inspectionId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      bytes: 'number',
      collectedAt: 'string',
      contentType: 'string',
      host: SubmitHostInspectionRequestHost,
      objectKey: 'string',
      profile: 'string',
      schemaVersion: 'string',
      sha256: 'string',
      window: 'string',
      inspectionId: 'string',
    };
  }

  validate() {
    if(this.host && typeof (this.host as any).validate === 'function') {
      (this.host as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

