// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentListResponseBodyDataAgents extends $dara.Model {
  name?: string;
  pid?: number;
  static names(): { [key: string]: string } {
    return {
      name: 'name',
      pid: 'pid',
    };
  }

  static types(): { [key: string]: any } {
    return {
      name: 'string',
      pid: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentListResponseBodyData extends $dara.Model {
  agents?: GetAgentListResponseBodyDataAgents[];
  static names(): { [key: string]: string } {
    return {
      agents: 'agents',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agents: { 'type': 'array', 'itemType': GetAgentListResponseBodyDataAgents },
    };
  }

  validate() {
    if(Array.isArray(this.agents)) {
      $dara.Model.validateArray(this.agents);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentListResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentListResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentListResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

