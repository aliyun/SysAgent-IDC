// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CompleteFileUploadResponseBodyData extends $dara.Model {
  analysisId?: string;
  contentType?: string;
  /**
   * @remarks
   * Use the UTC time format: yyyy-MM-ddTHH:mm:ssZ
   */
  createdAt?: string;
  fileId?: string;
  filename?: string;
  kind?: string;
  meta?: { [key: string]: any };
  preview?: string;
  profilingType?: string;
  size?: number;
  truncated?: boolean;
  static names(): { [key: string]: string } {
    return {
      analysisId: 'analysisId',
      contentType: 'contentType',
      createdAt: 'createdAt',
      fileId: 'fileId',
      filename: 'filename',
      kind: 'kind',
      meta: 'meta',
      preview: 'preview',
      profilingType: 'profilingType',
      size: 'size',
      truncated: 'truncated',
    };
  }

  static types(): { [key: string]: any } {
    return {
      analysisId: 'string',
      contentType: 'string',
      createdAt: 'string',
      fileId: 'string',
      filename: 'string',
      kind: 'string',
      meta: { 'type': 'map', 'keyType': 'string', 'valueType': 'any' },
      preview: 'string',
      profilingType: 'string',
      size: 'number',
      truncated: 'boolean',
    };
  }

  validate() {
    if(this.meta) {
      $dara.Model.validateMap(this.meta);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CompleteFileUploadResponseBody extends $dara.Model {
  code?: string;
  data?: CompleteFileUploadResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: CompleteFileUploadResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

