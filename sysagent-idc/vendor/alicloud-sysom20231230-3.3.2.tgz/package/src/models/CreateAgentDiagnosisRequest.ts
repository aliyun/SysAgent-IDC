// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateAgentDiagnosisRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @example
   * OpenClaw
   */
  agentName?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 1768823100000
   */
  endTime?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * i-uf63p6e27uvz74h94ar1
   */
  instance?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 1768822500000
   */
  startTime?: number;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      agentName: 'agentName',
      endTime: 'endTime',
      instance: 'instance',
      regionId: 'regionId',
      startTime: 'startTime',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      agentName: 'string',
      endTime: 'number',
      instance: 'string',
      regionId: 'string',
      startTime: 'number',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

