// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class SubmitAppAnalysisRequest extends $dara.Model {
  /**
   * @remarks
   * This parameter is required.
   */
  appType?: string;
  comms?: string;
  cut?: number;
  end?: number;
  /**
   * @remarks
   * This parameter is required.
   */
  instance?: string;
  pids?: string;
  podip?: string;
  podname?: string;
  ports?: string;
  start?: number;
  static names(): { [key: string]: string } {
    return {
      appType: 'appType',
      comms: 'comms',
      cut: 'cut',
      end: 'end',
      instance: 'instance',
      pids: 'pids',
      podip: 'podip',
      podname: 'podname',
      ports: 'ports',
      start: 'start',
    };
  }

  static types(): { [key: string]: any } {
    return {
      appType: 'string',
      comms: 'string',
      cut: 'number',
      end: 'number',
      instance: 'string',
      pids: 'string',
      podip: 'string',
      podname: 'string',
      ports: 'string',
      start: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

