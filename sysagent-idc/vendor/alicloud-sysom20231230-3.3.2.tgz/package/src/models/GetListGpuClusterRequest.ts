// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetListGpuClusterRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * The ID of the region to query.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  /**
   * @remarks
   * The time range to query. Unit: milliseconds. Format: [start,end]. Example: [13254125000, 52451241000].
   * 
   * @example
   * [1757820000, 1757823600]
   */
  timeRegion?: any;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      regionId: 'regionId',
      timeRegion: 'timeRegion',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      regionId: 'string',
      timeRegion: 'any',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

