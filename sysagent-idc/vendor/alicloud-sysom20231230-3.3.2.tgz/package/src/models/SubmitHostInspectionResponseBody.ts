// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class SubmitHostInspectionResponseBody extends $dara.Model {
  inspectionId?: string;
  reportId?: string;
  retryable?: boolean;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      inspectionId: 'inspectionId',
      reportId: 'reportId',
      retryable: 'retryable',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      inspectionId: 'string',
      reportId: 'string',
      retryable: 'boolean',
      status: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

