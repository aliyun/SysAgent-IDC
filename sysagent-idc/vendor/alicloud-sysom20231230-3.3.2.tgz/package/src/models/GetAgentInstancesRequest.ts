// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentInstancesRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 1777432638
   */
  endTime?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 1776616991
   */
  startTime?: number;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      endTime: 'endTime',
      regionId: 'regionId',
      startTime: 'startTime',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      endTime: 'number',
      regionId: 'string',
      startTime: 'number',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

