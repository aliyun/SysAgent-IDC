// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentConversationDetailRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 548ddc90f321ecffd7f29c88a2402d19
   */
  conversationId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      conversationId: 'conversationId',
      regionId: 'regionId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      conversationId: 'string',
      regionId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

