// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListAppAnalysisRecordsRequest extends $dara.Model {
  analysisId?: string;
  analysisTime?: string;
  maxResults?: number;
  nextToken?: string;
  page?: number;
  pageSize?: number;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      analysisId: 'analysisId',
      analysisTime: 'analysisTime',
      maxResults: 'maxResults',
      nextToken: 'nextToken',
      page: 'page',
      pageSize: 'pageSize',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      analysisId: 'string',
      analysisTime: 'string',
      maxResults: 'number',
      nextToken: 'string',
      page: 'number',
      pageSize: 'number',
      status: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

