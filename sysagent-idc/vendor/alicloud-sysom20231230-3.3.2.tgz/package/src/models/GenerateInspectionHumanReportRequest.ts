// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GenerateInspectionHumanReportRequest extends $dara.Model {
  /**
   * @example
   * insp-2f1c9d4e6b7a4c319a520e8f7d6c5b4a
   */
  reportId?: string;
  static names(): { [key: string]: string } {
    return {
      reportId: 'reportId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      reportId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

