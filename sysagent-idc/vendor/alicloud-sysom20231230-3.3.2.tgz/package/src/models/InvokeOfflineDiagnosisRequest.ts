// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class InvokeOfflineDiagnosisRequest extends $dara.Model {
  xDebugId?: string;
  params?: any;
  serviceName?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      params: 'params',
      serviceName: 'serviceName',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      params: 'any',
      serviceName: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

