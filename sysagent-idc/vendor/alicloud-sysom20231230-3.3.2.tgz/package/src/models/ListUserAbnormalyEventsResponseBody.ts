// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListUserAbnormalyEventsResponseBodyDataOptsResult extends $dara.Model {
  status?: string;
  url?: string;
  static names(): { [key: string]: string } {
    return {
      status: 'status',
      url: 'url',
    };
  }

  static types(): { [key: string]: any } {
    return {
      status: 'string',
      url: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListUserAbnormalyEventsResponseBodyDataOpts extends $dara.Model {
  label?: string;
  result?: ListUserAbnormalyEventsResponseBodyDataOptsResult;
  type?: string;
  static names(): { [key: string]: string } {
    return {
      label: 'label',
      result: 'result',
      type: 'type',
    };
  }

  static types(): { [key: string]: any } {
    return {
      label: 'string',
      result: ListUserAbnormalyEventsResponseBodyDataOptsResult,
      type: 'string',
    };
  }

  validate() {
    if(this.result && typeof (this.result as any).validate === 'function') {
      (this.result as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListUserAbnormalyEventsResponseBodyDataRawMetrics extends $dara.Model {
  endTime?: number;
  metrics?: string[];
  startTime?: number;
  static names(): { [key: string]: string } {
    return {
      endTime: 'endTime',
      metrics: 'metrics',
      startTime: 'startTime',
    };
  }

  static types(): { [key: string]: any } {
    return {
      endTime: 'number',
      metrics: { 'type': 'array', 'itemType': 'string' },
      startTime: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.metrics)) {
      $dara.Model.validateArray(this.metrics);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListUserAbnormalyEventsResponseBodyData extends $dara.Model {
  cluster?: string;
  createdAt?: number;
  description?: string;
  diagStatus?: number;
  endAt?: number;
  instance?: string;
  item?: string;
  level?: string;
  namespace?: string;
  opts?: ListUserAbnormalyEventsResponseBodyDataOpts[];
  pod?: string;
  rawMetrics?: ListUserAbnormalyEventsResponseBodyDataRawMetrics;
  regionId?: string;
  type?: string;
  uuid?: string;
  static names(): { [key: string]: string } {
    return {
      cluster: 'cluster',
      createdAt: 'createdAt',
      description: 'description',
      diagStatus: 'diagStatus',
      endAt: 'endAt',
      instance: 'instance',
      item: 'item',
      level: 'level',
      namespace: 'namespace',
      opts: 'opts',
      pod: 'pod',
      rawMetrics: 'rawMetrics',
      regionId: 'regionId',
      type: 'type',
      uuid: 'uuid',
    };
  }

  static types(): { [key: string]: any } {
    return {
      cluster: 'string',
      createdAt: 'number',
      description: 'string',
      diagStatus: 'number',
      endAt: 'number',
      instance: 'string',
      item: 'string',
      level: 'string',
      namespace: 'string',
      opts: { 'type': 'array', 'itemType': ListUserAbnormalyEventsResponseBodyDataOpts },
      pod: 'string',
      rawMetrics: ListUserAbnormalyEventsResponseBodyDataRawMetrics,
      regionId: 'string',
      type: 'string',
      uuid: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.opts)) {
      $dara.Model.validateArray(this.opts);
    }
    if(this.rawMetrics && typeof (this.rawMetrics as any).validate === 'function') {
      (this.rawMetrics as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListUserAbnormalyEventsResponseBody extends $dara.Model {
  code?: string;
  data?: ListUserAbnormalyEventsResponseBodyData[];
  maxResults?: number;
  message?: string;
  nextToken?: string;
  requestId?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
      requestId: 'requestId',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListUserAbnormalyEventsResponseBodyData },
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
      requestId: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

