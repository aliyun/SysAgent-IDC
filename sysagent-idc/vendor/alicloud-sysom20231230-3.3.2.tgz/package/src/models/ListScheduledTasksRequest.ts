// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListScheduledTasksRequest extends $dara.Model {
  current?: number;
  enable?: boolean;
  id?: number;
  maxResults?: number;
  name?: string;
  nextToken?: string;
  pageSize?: number;
  static names(): { [key: string]: string } {
    return {
      current: 'current',
      enable: 'enable',
      id: 'id',
      maxResults: 'maxResults',
      name: 'name',
      nextToken: 'nextToken',
      pageSize: 'pageSize',
    };
  }

  static types(): { [key: string]: any } {
    return {
      current: 'number',
      enable: 'boolean',
      id: 'number',
      maxResults: 'number',
      name: 'string',
      nextToken: 'string',
      pageSize: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

