// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentDiagnosisDetailRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @example
   * context_overflow
   */
  interruptionType?: string;
  /**
   * @example
   * 1
   */
  page?: number;
  /**
   * @example
   * 20
   */
  pageSize?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  /**
   * @example
   * false
   */
  resolved?: string;
  /**
   * @example
   * high
   */
  severity?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * diag-a1b2c3d4e5f6
   */
  taskId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      interruptionType: 'interruptionType',
      page: 'page',
      pageSize: 'pageSize',
      regionId: 'regionId',
      resolved: 'resolved',
      severity: 'severity',
      taskId: 'taskId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      interruptionType: 'string',
      page: 'number',
      pageSize: 'number',
      regionId: 'string',
      resolved: 'string',
      severity: 'string',
      taskId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

