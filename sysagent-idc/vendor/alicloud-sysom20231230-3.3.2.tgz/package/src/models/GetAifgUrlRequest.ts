// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAifgUrlRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * The task identifier.
   * 
   * This parameter is required.
   * 
   * @example
   * 9cd7aee5-d365-4d4e-8236-58a110a4ea09
   */
  taskId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      taskId: 'taskId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      taskId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

