// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListHostInspectionsResponseBodyDataError extends $dara.Model {
  code?: string;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      message: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListHostInspectionsResponseBodyData extends $dara.Model {
  createdAt?: string;
  deviceId?: string;
  error?: ListHostInspectionsResponseBodyDataError;
  finishedAt?: string;
  hostname?: string;
  inspectionId?: string;
  phase?: string;
  progress?: number;
  reportId?: string;
  reportStatus?: string;
  retryable?: boolean;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      createdAt: 'createdAt',
      deviceId: 'deviceId',
      error: 'error',
      finishedAt: 'finishedAt',
      hostname: 'hostname',
      inspectionId: 'inspectionId',
      phase: 'phase',
      progress: 'progress',
      reportId: 'reportId',
      reportStatus: 'reportStatus',
      retryable: 'retryable',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      createdAt: 'string',
      deviceId: 'string',
      error: ListHostInspectionsResponseBodyDataError,
      finishedAt: 'string',
      hostname: 'string',
      inspectionId: 'string',
      phase: 'string',
      progress: 'number',
      reportId: 'string',
      reportStatus: 'string',
      retryable: 'boolean',
      status: 'string',
    };
  }

  validate() {
    if(this.error && typeof (this.error as any).validate === 'function') {
      (this.error as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListHostInspectionsResponseBody extends $dara.Model {
  code?: string;
  data?: ListHostInspectionsResponseBodyData[];
  maxResults?: number;
  message?: string;
  nextToken?: string;
  requestId?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
      requestId: 'requestId',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListHostInspectionsResponseBodyData },
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
      requestId: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

