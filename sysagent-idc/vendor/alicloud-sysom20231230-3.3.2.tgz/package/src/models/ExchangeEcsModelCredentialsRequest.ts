// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ExchangeEcsModelCredentialsRequest extends $dara.Model {
  /**
   * @remarks
   * This parameter is required.
   */
  challengeId?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  pkcs7Base64?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  signedDocumentBase64?: string;
  static names(): { [key: string]: string } {
    return {
      challengeId: 'challengeId',
      pkcs7Base64: 'pkcs7Base64',
      signedDocumentBase64: 'signedDocumentBase64',
    };
  }

  static types(): { [key: string]: any } {
    return {
      challengeId: 'string',
      pkcs7Base64: 'string',
      signedDocumentBase64: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

