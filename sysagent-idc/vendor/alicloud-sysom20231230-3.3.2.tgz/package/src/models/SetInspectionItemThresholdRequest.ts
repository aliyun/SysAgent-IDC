// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class SetInspectionItemThresholdRequest extends $dara.Model {
  inspectionType?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * sysom:metric:memory_usage_rate
   */
  itemName?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  thresholds?: number[];
  static names(): { [key: string]: string } {
    return {
      inspectionType: 'inspectionType',
      itemName: 'itemName',
      thresholds: 'thresholds',
    };
  }

  static types(): { [key: string]: any } {
    return {
      inspectionType: 'string',
      itemName: 'string',
      thresholds: { 'type': 'array', 'itemType': 'number' },
    };
  }

  validate() {
    if(Array.isArray(this.thresholds)) {
      $dara.Model.validateArray(this.thresholds);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

