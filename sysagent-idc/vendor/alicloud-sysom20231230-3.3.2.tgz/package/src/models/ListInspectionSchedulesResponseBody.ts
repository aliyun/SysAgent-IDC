// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListInspectionSchedulesResponseBodyDataTarget extends $dara.Model {
  instance?: string;
  instances?: string[];
  items?: string[];
  metricSource?: string;
  region?: string;
  scopeType?: string;
  static names(): { [key: string]: string } {
    return {
      instance: 'instance',
      instances: 'instances',
      items: 'items',
      metricSource: 'metricSource',
      region: 'region',
      scopeType: 'scopeType',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instance: 'string',
      instances: { 'type': 'array', 'itemType': 'string' },
      items: { 'type': 'array', 'itemType': 'string' },
      metricSource: 'string',
      region: 'string',
      scopeType: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.instances)) {
      $dara.Model.validateArray(this.instances);
    }
    if(Array.isArray(this.items)) {
      $dara.Model.validateArray(this.items);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListInspectionSchedulesResponseBodyData extends $dara.Model {
  completedAt?: string;
  createdAt?: string;
  cronExpr?: string;
  enabled?: boolean;
  fireCount?: number;
  fireTime?: string;
  id?: string;
  inspectionType?: string;
  lastFireAt?: string;
  lastRunId?: string;
  lastStatus?: string;
  minSeverity?: string;
  name?: string;
  nextFireAt?: string;
  notifyDestinations?: number[];
  scheduleType?: string;
  source?: string;
  target?: ListInspectionSchedulesResponseBodyDataTarget;
  timezone?: string;
  uid?: string;
  updatedAt?: string;
  static names(): { [key: string]: string } {
    return {
      completedAt: 'completedAt',
      createdAt: 'createdAt',
      cronExpr: 'cronExpr',
      enabled: 'enabled',
      fireCount: 'fireCount',
      fireTime: 'fireTime',
      id: 'id',
      inspectionType: 'inspectionType',
      lastFireAt: 'lastFireAt',
      lastRunId: 'lastRunId',
      lastStatus: 'lastStatus',
      minSeverity: 'minSeverity',
      name: 'name',
      nextFireAt: 'nextFireAt',
      notifyDestinations: 'notifyDestinations',
      scheduleType: 'scheduleType',
      source: 'source',
      target: 'target',
      timezone: 'timezone',
      uid: 'uid',
      updatedAt: 'updatedAt',
    };
  }

  static types(): { [key: string]: any } {
    return {
      completedAt: 'string',
      createdAt: 'string',
      cronExpr: 'string',
      enabled: 'boolean',
      fireCount: 'number',
      fireTime: 'string',
      id: 'string',
      inspectionType: 'string',
      lastFireAt: 'string',
      lastRunId: 'string',
      lastStatus: 'string',
      minSeverity: 'string',
      name: 'string',
      nextFireAt: 'string',
      notifyDestinations: { 'type': 'array', 'itemType': 'number' },
      scheduleType: 'string',
      source: 'string',
      target: ListInspectionSchedulesResponseBodyDataTarget,
      timezone: 'string',
      uid: 'string',
      updatedAt: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.notifyDestinations)) {
      $dara.Model.validateArray(this.notifyDestinations);
    }
    if(this.target && typeof (this.target as any).validate === 'function') {
      (this.target as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListInspectionSchedulesResponseBody extends $dara.Model {
  code?: string;
  data?: ListInspectionSchedulesResponseBodyData[];
  message?: string;
  requestId?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListInspectionSchedulesResponseBodyData },
      message: 'string',
      requestId: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

