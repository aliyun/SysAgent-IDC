// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class StartAgentOptimizationRequest extends $dara.Model {
  xDebugId?: string;
  dimensions?: string[];
  endTime?: number;
  includeLlmJudgement?: boolean;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * sess-abc123
   */
  sessionId?: string;
  sourceType?: string;
  startTime?: number;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      dimensions: 'dimensions',
      endTime: 'endTime',
      includeLlmJudgement: 'includeLlmJudgement',
      regionId: 'regionId',
      sessionId: 'sessionId',
      sourceType: 'sourceType',
      startTime: 'startTime',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      dimensions: { 'type': 'array', 'itemType': 'string' },
      endTime: 'number',
      includeLlmJudgement: 'boolean',
      regionId: 'string',
      sessionId: 'string',
      sourceType: 'string',
      startTime: 'number',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.dimensions)) {
      $dara.Model.validateArray(this.dimensions);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

