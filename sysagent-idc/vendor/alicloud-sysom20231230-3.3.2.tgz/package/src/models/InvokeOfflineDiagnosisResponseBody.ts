// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class InvokeOfflineDiagnosisResponseBodyDataCommands extends $dara.Model {
  cmd?: string;
  fetchFileList?: string[];
  instance?: string;
  static names(): { [key: string]: string } {
    return {
      cmd: 'cmd',
      fetchFileList: 'fetchFileList',
      instance: 'instance',
    };
  }

  static types(): { [key: string]: any } {
    return {
      cmd: 'string',
      fetchFileList: { 'type': 'array', 'itemType': 'string' },
      instance: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.fetchFileList)) {
      $dara.Model.validateArray(this.fetchFileList);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeOfflineDiagnosisResponseBodyData extends $dara.Model {
  commands?: InvokeOfflineDiagnosisResponseBodyDataCommands[];
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      commands: 'commands',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      commands: { 'type': 'array', 'itemType': InvokeOfflineDiagnosisResponseBodyDataCommands },
      taskId: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.commands)) {
      $dara.Model.validateArray(this.commands);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeOfflineDiagnosisResponseBody extends $dara.Model {
  code?: string;
  data?: InvokeOfflineDiagnosisResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: InvokeOfflineDiagnosisResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

