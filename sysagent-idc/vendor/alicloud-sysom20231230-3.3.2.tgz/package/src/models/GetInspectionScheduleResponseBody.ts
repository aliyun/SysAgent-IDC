// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetInspectionScheduleResponseBodyData extends $dara.Model {
  completedAt?: string;
  createdAt?: string;
  cronExpr?: string;
  enabled?: boolean;
  fireCount?: number;
  fireTime?: string;
  id?: string;
  inspectionType?: string;
  lastFireAt?: string;
  lastRunId?: string;
  lastStatus?: string;
  minSeverity?: string;
  name?: string;
  nextFireAt?: string;
  notifyDestinations?: number[];
  scheduleType?: string;
  source?: string;
  target?: any;
  timezone?: string;
  uid?: string;
  updatedAt?: string;
  static names(): { [key: string]: string } {
    return {
      completedAt: 'completedAt',
      createdAt: 'createdAt',
      cronExpr: 'cronExpr',
      enabled: 'enabled',
      fireCount: 'fireCount',
      fireTime: 'fireTime',
      id: 'id',
      inspectionType: 'inspectionType',
      lastFireAt: 'lastFireAt',
      lastRunId: 'lastRunId',
      lastStatus: 'lastStatus',
      minSeverity: 'minSeverity',
      name: 'name',
      nextFireAt: 'nextFireAt',
      notifyDestinations: 'notifyDestinations',
      scheduleType: 'scheduleType',
      source: 'source',
      target: 'target',
      timezone: 'timezone',
      uid: 'uid',
      updatedAt: 'updatedAt',
    };
  }

  static types(): { [key: string]: any } {
    return {
      completedAt: 'string',
      createdAt: 'string',
      cronExpr: 'string',
      enabled: 'boolean',
      fireCount: 'number',
      fireTime: 'string',
      id: 'string',
      inspectionType: 'string',
      lastFireAt: 'string',
      lastRunId: 'string',
      lastStatus: 'string',
      minSeverity: 'string',
      name: 'string',
      nextFireAt: 'string',
      notifyDestinations: { 'type': 'array', 'itemType': 'number' },
      scheduleType: 'string',
      source: 'string',
      target: 'any',
      timezone: 'string',
      uid: 'string',
      updatedAt: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.notifyDestinations)) {
      $dara.Model.validateArray(this.notifyDestinations);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetInspectionScheduleResponseBody extends $dara.Model {
  code?: string;
  data?: GetInspectionScheduleResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetInspectionScheduleResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

