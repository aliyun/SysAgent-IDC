// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ResetInspectionItemThresholdRequest extends $dara.Model {
  inspectionType?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  itemNames?: string[];
  static names(): { [key: string]: string } {
    return {
      inspectionType: 'inspectionType',
      itemNames: 'itemNames',
    };
  }

  static types(): { [key: string]: any } {
    return {
      inspectionType: 'string',
      itemNames: { 'type': 'array', 'itemType': 'string' },
    };
  }

  validate() {
    if(Array.isArray(this.itemNames)) {
      $dara.Model.validateArray(this.itemNames);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

