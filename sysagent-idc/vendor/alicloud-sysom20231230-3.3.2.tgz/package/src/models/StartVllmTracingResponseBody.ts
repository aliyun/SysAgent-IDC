// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class StartVllmTracingResponseBodyData extends $dara.Model {
  ossFile?: string;
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      ossFile: 'ossFile',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      ossFile: 'string',
      taskId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class StartVllmTracingResponseBody extends $dara.Model {
  code?: string;
  data?: StartVllmTracingResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: StartVllmTracingResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

