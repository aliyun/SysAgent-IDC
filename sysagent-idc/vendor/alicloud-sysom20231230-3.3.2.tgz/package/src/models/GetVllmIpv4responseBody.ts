// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetVllmIpv4ResponseBodyDataTimeRange extends $dara.Model {
  endTime?: number;
  endTimeMs?: number;
  startTime?: number;
  startTimeMs?: number;
  static names(): { [key: string]: string } {
    return {
      endTime: 'endTime',
      endTimeMs: 'endTimeMs',
      startTime: 'startTime',
      startTimeMs: 'startTimeMs',
    };
  }

  static types(): { [key: string]: any } {
    return {
      endTime: 'number',
      endTimeMs: 'number',
      startTime: 'number',
      startTimeMs: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetVllmIpv4ResponseBodyData extends $dara.Model {
  count?: number;
  ipv4List?: string[];
  timeRange?: GetVllmIpv4ResponseBodyDataTimeRange;
  static names(): { [key: string]: string } {
    return {
      count: 'count',
      ipv4List: 'ipv4List',
      timeRange: 'timeRange',
    };
  }

  static types(): { [key: string]: any } {
    return {
      count: 'number',
      ipv4List: { 'type': 'array', 'itemType': 'string' },
      timeRange: GetVllmIpv4ResponseBodyDataTimeRange,
    };
  }

  validate() {
    if(Array.isArray(this.ipv4List)) {
      $dara.Model.validateArray(this.ipv4List);
    }
    if(this.timeRange && typeof (this.timeRange as any).validate === 'function') {
      (this.timeRange as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetVllmIpv4ResponseBody extends $dara.Model {
  code?: string;
  data?: GetVllmIpv4ResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetVllmIpv4ResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

