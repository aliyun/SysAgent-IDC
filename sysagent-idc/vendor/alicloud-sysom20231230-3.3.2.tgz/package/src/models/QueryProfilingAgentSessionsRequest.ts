// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class QueryProfilingAgentSessionsRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @example
   * aid-xxx
   */
  analysisId?: string;
  /**
   * @example
   * sess-xxx
   */
  sessionId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      analysisId: 'analysis_id',
      sessionId: 'session_id',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      analysisId: 'string',
      sessionId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

