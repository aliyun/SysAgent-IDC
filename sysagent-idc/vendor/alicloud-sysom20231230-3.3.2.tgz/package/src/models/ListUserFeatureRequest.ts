// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListUserFeatureRequest extends $dara.Model {
  xDebugId?: string;
  feature?: string;
  maxResults?: number;
  nextToken?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      feature: 'feature',
      maxResults: 'maxResults',
      nextToken: 'nextToken',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      feature: 'string',
      maxResults: 'number',
      nextToken: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

