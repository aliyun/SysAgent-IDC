// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ResetInspectionItemThresholdResponseBodyData extends $dara.Model {
  effectiveThresholds?: number[];
  itemName?: string;
  source?: string;
  updatedAt?: string;
  userThresholds?: number[];
  static names(): { [key: string]: string } {
    return {
      effectiveThresholds: 'effectiveThresholds',
      itemName: 'itemName',
      source: 'source',
      updatedAt: 'updatedAt',
      userThresholds: 'userThresholds',
    };
  }

  static types(): { [key: string]: any } {
    return {
      effectiveThresholds: { 'type': 'array', 'itemType': 'number' },
      itemName: 'string',
      source: 'string',
      updatedAt: 'string',
      userThresholds: { 'type': 'array', 'itemType': 'number' },
    };
  }

  validate() {
    if(Array.isArray(this.effectiveThresholds)) {
      $dara.Model.validateArray(this.effectiveThresholds);
    }
    if(Array.isArray(this.userThresholds)) {
      $dara.Model.validateArray(this.userThresholds);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ResetInspectionItemThresholdResponseBody extends $dara.Model {
  code?: string;
  data?: ResetInspectionItemThresholdResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ResetInspectionItemThresholdResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

