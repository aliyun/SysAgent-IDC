// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListInspectionSchedulesRequest extends $dara.Model {
  current?: number;
  enabled?: boolean;
  /**
   * @example
   * 每日凌晨
   */
  name?: string;
  pageSize?: number;
  scheduleType?: string;
  static names(): { [key: string]: string } {
    return {
      current: 'current',
      enabled: 'enabled',
      name: 'name',
      pageSize: 'pageSize',
      scheduleType: 'scheduleType',
    };
  }

  static types(): { [key: string]: any } {
    return {
      current: 'number',
      enabled: 'boolean',
      name: 'string',
      pageSize: 'number',
      scheduleType: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

