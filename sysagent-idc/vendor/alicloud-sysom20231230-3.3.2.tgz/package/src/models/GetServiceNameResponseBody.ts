// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetServiceNameResponseBodyDataTimeRange extends $dara.Model {
  endTime?: number;
  endTimeMs?: number;
  startTime?: number;
  startTimeMs?: number;
  static names(): { [key: string]: string } {
    return {
      endTime: 'endTime',
      endTimeMs: 'endTimeMs',
      startTime: 'startTime',
      startTimeMs: 'startTimeMs',
    };
  }

  static types(): { [key: string]: any } {
    return {
      endTime: 'number',
      endTimeMs: 'number',
      startTime: 'number',
      startTimeMs: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetServiceNameResponseBodyData extends $dara.Model {
  count?: number;
  serviceNames?: string[];
  timeRange?: GetServiceNameResponseBodyDataTimeRange;
  static names(): { [key: string]: string } {
    return {
      count: 'count',
      serviceNames: 'serviceNames',
      timeRange: 'timeRange',
    };
  }

  static types(): { [key: string]: any } {
    return {
      count: 'number',
      serviceNames: { 'type': 'array', 'itemType': 'string' },
      timeRange: GetServiceNameResponseBodyDataTimeRange,
    };
  }

  validate() {
    if(Array.isArray(this.serviceNames)) {
      $dara.Model.validateArray(this.serviceNames);
    }
    if(this.timeRange && typeof (this.timeRange as any).validate === 'function') {
      (this.timeRange as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetServiceNameResponseBody extends $dara.Model {
  /**
   * @example
   * 200
   */
  code?: string;
  data?: GetServiceNameResponseBodyData;
  maxResults?: number;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 你好，世界！
   */
  message?: string;
  nextToken?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetServiceNameResponseBodyData,
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

