// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetVllmModelNameResponseBodyDataTimeRange extends $dara.Model {
  endTime?: number;
  endTimeMs?: number;
  startTime?: number;
  startTimeMs?: number;
  static names(): { [key: string]: string } {
    return {
      endTime: 'endTime',
      endTimeMs: 'endTimeMs',
      startTime: 'startTime',
      startTimeMs: 'startTimeMs',
    };
  }

  static types(): { [key: string]: any } {
    return {
      endTime: 'number',
      endTimeMs: 'number',
      startTime: 'number',
      startTimeMs: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetVllmModelNameResponseBodyData extends $dara.Model {
  count?: number;
  modelNames?: string[];
  timeRange?: GetVllmModelNameResponseBodyDataTimeRange;
  static names(): { [key: string]: string } {
    return {
      count: 'count',
      modelNames: 'modelNames',
      timeRange: 'timeRange',
    };
  }

  static types(): { [key: string]: any } {
    return {
      count: 'number',
      modelNames: { 'type': 'array', 'itemType': 'string' },
      timeRange: GetVllmModelNameResponseBodyDataTimeRange,
    };
  }

  validate() {
    if(Array.isArray(this.modelNames)) {
      $dara.Model.validateArray(this.modelNames);
    }
    if(this.timeRange && typeof (this.timeRange as any).validate === 'function') {
      (this.timeRange as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetVllmModelNameResponseBody extends $dara.Model {
  code?: string;
  data?: GetVllmModelNameResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetVllmModelNameResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

