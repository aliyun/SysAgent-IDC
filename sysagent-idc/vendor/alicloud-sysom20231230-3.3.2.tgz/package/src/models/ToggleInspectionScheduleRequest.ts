// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ToggleInspectionScheduleRequest extends $dara.Model {
  enabled?: boolean;
  /**
   * @example
   * insp-sched-2f1c9d4e-6b7a-4c31-9a52-0e8f7d6c5b4a
   */
  id?: string;
  static names(): { [key: string]: string } {
    return {
      enabled: 'enabled',
      id: 'id',
    };
  }

  static types(): { [key: string]: any } {
    return {
      enabled: 'boolean',
      id: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

