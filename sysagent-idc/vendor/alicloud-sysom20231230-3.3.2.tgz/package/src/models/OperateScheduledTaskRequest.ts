// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class OperateScheduledTaskRequest extends $dara.Model {
  agentCode?: string;
  cronExp?: string;
  destinationId?: number;
  enable?: boolean;
  id?: number;
  inspectionId?: string;
  name?: string;
  /**
   * @remarks
   * This parameter is required.
   */
  operation?: string;
  prompt?: string;
  taskType?: string;
  static names(): { [key: string]: string } {
    return {
      agentCode: 'agentCode',
      cronExp: 'cronExp',
      destinationId: 'destinationId',
      enable: 'enable',
      id: 'id',
      inspectionId: 'inspectionId',
      name: 'name',
      operation: 'operation',
      prompt: 'prompt',
      taskType: 'taskType',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentCode: 'string',
      cronExp: 'string',
      destinationId: 'number',
      enable: 'boolean',
      id: 'number',
      inspectionId: 'string',
      name: 'string',
      operation: 'string',
      prompt: 'string',
      taskType: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

