// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class StartVllmTracingRequest extends $dara.Model {
  xDebugId?: string;
  endTime?: number;
  ipv4?: string[];
  modelName?: string;
  region?: string;
  serviceName?: string;
  startTime?: number;
  traceId?: string;
  workspace?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      endTime: 'endTime',
      ipv4: 'ipv4',
      modelName: 'modelName',
      region: 'region',
      serviceName: 'serviceName',
      startTime: 'startTime',
      traceId: 'traceId',
      workspace: 'workspace',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      endTime: 'number',
      ipv4: { 'type': 'array', 'itemType': 'string' },
      modelName: 'string',
      region: 'string',
      serviceName: 'string',
      startTime: 'number',
      traceId: 'string',
      workspace: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.ipv4)) {
      $dara.Model.validateArray(this.ipv4);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

