// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ToggleInspectionScheduleResponseBodyData extends $dara.Model {
  enabled?: boolean;
  id?: string;
  static names(): { [key: string]: string } {
    return {
      enabled: 'enabled',
      id: 'id',
    };
  }

  static types(): { [key: string]: any } {
    return {
      enabled: 'boolean',
      id: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ToggleInspectionScheduleResponseBody extends $dara.Model {
  code?: string;
  data?: ToggleInspectionScheduleResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ToggleInspectionScheduleResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

