// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListAgentOptimizationTasksResponseBodyDataTasks extends $dara.Model {
  region?: string;
  sessionId?: string;
  status?: string;
  subStatus?: string;
  submitTime?: string;
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      region: 'region',
      sessionId: 'sessionId',
      status: 'status',
      subStatus: 'subStatus',
      submitTime: 'submitTime',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      region: 'string',
      sessionId: 'string',
      status: 'string',
      subStatus: 'string',
      submitTime: 'string',
      taskId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListAgentOptimizationTasksResponseBodyData extends $dara.Model {
  tasks?: ListAgentOptimizationTasksResponseBodyDataTasks[];
  total?: number;
  static names(): { [key: string]: string } {
    return {
      tasks: 'tasks',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      tasks: { 'type': 'array', 'itemType': ListAgentOptimizationTasksResponseBodyDataTasks },
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.tasks)) {
      $dara.Model.validateArray(this.tasks);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListAgentOptimizationTasksResponseBody extends $dara.Model {
  code?: string;
  data?: ListAgentOptimizationTasksResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: ListAgentOptimizationTasksResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

