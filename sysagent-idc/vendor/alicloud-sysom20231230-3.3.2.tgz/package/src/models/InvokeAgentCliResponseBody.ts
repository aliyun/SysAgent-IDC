// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class InvokeAgentCliResponseBodyDataAgentFindings extends $dara.Model {
  category?: string;
  detail?: string;
  severity?: string;
  title?: string;
  static names(): { [key: string]: string } {
    return {
      category: 'category',
      detail: 'detail',
      severity: 'severity',
      title: 'title',
    };
  }

  static types(): { [key: string]: any } {
    return {
      category: 'string',
      detail: 'string',
      severity: 'string',
      title: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyDataAgentNextSteps extends $dara.Model {
  command?: string;
  kind?: string;
  label?: string;
  reason?: string;
  url?: string;
  static names(): { [key: string]: string } {
    return {
      command: 'command',
      kind: 'kind',
      label: 'label',
      reason: 'reason',
      url: 'url',
    };
  }

  static types(): { [key: string]: any } {
    return {
      command: 'string',
      kind: 'string',
      label: 'string',
      reason: 'string',
      url: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyDataAgent extends $dara.Model {
  findings?: InvokeAgentCliResponseBodyDataAgentFindings[];
  nextSteps?: InvokeAgentCliResponseBodyDataAgentNextSteps[];
  sessionId?: string;
  status?: string;
  summary?: string;
  static names(): { [key: string]: string } {
    return {
      findings: 'findings',
      nextSteps: 'nextSteps',
      sessionId: 'sessionId',
      status: 'status',
      summary: 'summary',
    };
  }

  static types(): { [key: string]: any } {
    return {
      findings: { 'type': 'array', 'itemType': InvokeAgentCliResponseBodyDataAgentFindings },
      nextSteps: { 'type': 'array', 'itemType': InvokeAgentCliResponseBodyDataAgentNextSteps },
      sessionId: 'string',
      status: 'string',
      summary: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.findings)) {
      $dara.Model.validateArray(this.findings);
    }
    if(Array.isArray(this.nextSteps)) {
      $dara.Model.validateArray(this.nextSteps);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyDataError extends $dara.Model {
  code?: string;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      message: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyDataSysTask extends $dara.Model {
  status?: string;
  taskId?: string;
  static names(): { [key: string]: string } {
    return {
      status: 'status',
      taskId: 'taskId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      status: 'string',
      taskId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyDataSys extends $dara.Model {
  task?: InvokeAgentCliResponseBodyDataSysTask;
  static names(): { [key: string]: string } {
    return {
      task: 'task',
    };
  }

  static types(): { [key: string]: any } {
    return {
      task: InvokeAgentCliResponseBodyDataSysTask,
    };
  }

  validate() {
    if(this.task && typeof (this.task as any).validate === 'function') {
      (this.task as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBodyData extends $dara.Model {
  agent?: InvokeAgentCliResponseBodyDataAgent;
  data?: string;
  error?: InvokeAgentCliResponseBodyDataError;
  ok?: boolean;
  sys?: InvokeAgentCliResponseBodyDataSys;
  static names(): { [key: string]: string } {
    return {
      agent: 'agent',
      data: 'data',
      error: 'error',
      ok: 'ok',
      sys: 'sys',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agent: InvokeAgentCliResponseBodyDataAgent,
      data: 'string',
      error: InvokeAgentCliResponseBodyDataError,
      ok: 'boolean',
      sys: InvokeAgentCliResponseBodyDataSys,
    };
  }

  validate() {
    if(this.agent && typeof (this.agent as any).validate === 'function') {
      (this.agent as any).validate();
    }
    if(this.error && typeof (this.error as any).validate === 'function') {
      (this.error as any).validate();
    }
    if(this.sys && typeof (this.sys as any).validate === 'function') {
      (this.sys as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class InvokeAgentCliResponseBody extends $dara.Model {
  code?: string;
  data?: InvokeAgentCliResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: InvokeAgentCliResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

