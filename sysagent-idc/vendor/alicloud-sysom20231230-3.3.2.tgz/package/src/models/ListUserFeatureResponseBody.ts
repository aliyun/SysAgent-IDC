// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListUserFeatureResponseBodyData extends $dara.Model {
  configName?: string;
  configValue?: string;
  static names(): { [key: string]: string } {
    return {
      configName: 'configName',
      configValue: 'configValue',
    };
  }

  static types(): { [key: string]: any } {
    return {
      configName: 'string',
      configValue: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListUserFeatureResponseBody extends $dara.Model {
  code?: string;
  data?: ListUserFeatureResponseBodyData[];
  maxResults?: number;
  message?: string;
  nextToken?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListUserFeatureResponseBodyData },
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

