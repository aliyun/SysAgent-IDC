// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateHostInspectionUploadUrlResponseBodyRequiredHeaders extends $dara.Model {
  contentType?: string;
  static names(): { [key: string]: string } {
    return {
      contentType: 'contentType',
    };
  }

  static types(): { [key: string]: any } {
    return {
      contentType: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CreateHostInspectionUploadUrlResponseBody extends $dara.Model {
  /**
   * @example
   * 2026-11-10T06:15:00Z
   */
  expiresAt?: string;
  inspectionId?: string;
  /**
   * @example
   * 33554432
   */
  maxBytes?: number;
  /**
   * @example
   * PUT
   */
  method?: string;
  objectKey?: string;
  requiredHeaders?: CreateHostInspectionUploadUrlResponseBodyRequiredHeaders;
  uploadUrl?: string;
  static names(): { [key: string]: string } {
    return {
      expiresAt: 'expiresAt',
      inspectionId: 'inspectionId',
      maxBytes: 'maxBytes',
      method: 'method',
      objectKey: 'objectKey',
      requiredHeaders: 'requiredHeaders',
      uploadUrl: 'uploadUrl',
    };
  }

  static types(): { [key: string]: any } {
    return {
      expiresAt: 'string',
      inspectionId: 'string',
      maxBytes: 'number',
      method: 'string',
      objectKey: 'string',
      requiredHeaders: CreateHostInspectionUploadUrlResponseBodyRequiredHeaders,
      uploadUrl: 'string',
    };
  }

  validate() {
    if(this.requiredHeaders && typeof (this.requiredHeaders as any).validate === 'function') {
      (this.requiredHeaders as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

