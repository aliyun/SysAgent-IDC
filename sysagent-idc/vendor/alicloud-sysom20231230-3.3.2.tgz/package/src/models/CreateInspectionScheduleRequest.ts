// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateInspectionScheduleRequestTarget extends $dara.Model {
  /**
   * @example
   * i-bp1abcdefghij
   */
  instance?: string;
  instanceScope?: string;
  instances?: string[];
  items?: string[];
  metricSource?: string;
  /**
   * @example
   * cn-hangzhou
   */
  region?: string;
  scopeType?: string;
  serviceScope?: string;
  services?: string[];
  static names(): { [key: string]: string } {
    return {
      instance: 'instance',
      instanceScope: 'instanceScope',
      instances: 'instances',
      items: 'items',
      metricSource: 'metricSource',
      region: 'region',
      scopeType: 'scopeType',
      serviceScope: 'serviceScope',
      services: 'services',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instance: 'string',
      instanceScope: 'string',
      instances: { 'type': 'array', 'itemType': 'string' },
      items: { 'type': 'array', 'itemType': 'string' },
      metricSource: 'string',
      region: 'string',
      scopeType: 'string',
      serviceScope: 'string',
      services: { 'type': 'array', 'itemType': 'string' },
    };
  }

  validate() {
    if(Array.isArray(this.instances)) {
      $dara.Model.validateArray(this.instances);
    }
    if(Array.isArray(this.items)) {
      $dara.Model.validateArray(this.items);
    }
    if(Array.isArray(this.services)) {
      $dara.Model.validateArray(this.services);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class CreateInspectionScheduleRequest extends $dara.Model {
  /**
   * @example
   * 0 3 * * *
   */
  cronExpr?: string;
  enabled?: boolean;
  /**
   * @example
   * 2026-08-21T03:00:00+08:00
   */
  fireTime?: string;
  inspectionType?: string;
  minSeverity?: string;
  /**
   * @example
   * 每日凌晨全量巡检
   */
  name?: string;
  notifyDestinations?: number[];
  scheduleType?: string;
  source?: string;
  target?: CreateInspectionScheduleRequestTarget;
  static names(): { [key: string]: string } {
    return {
      cronExpr: 'cronExpr',
      enabled: 'enabled',
      fireTime: 'fireTime',
      inspectionType: 'inspectionType',
      minSeverity: 'minSeverity',
      name: 'name',
      notifyDestinations: 'notifyDestinations',
      scheduleType: 'scheduleType',
      source: 'source',
      target: 'target',
    };
  }

  static types(): { [key: string]: any } {
    return {
      cronExpr: 'string',
      enabled: 'boolean',
      fireTime: 'string',
      inspectionType: 'string',
      minSeverity: 'string',
      name: 'string',
      notifyDestinations: { 'type': 'array', 'itemType': 'number' },
      scheduleType: 'string',
      source: 'string',
      target: CreateInspectionScheduleRequestTarget,
    };
  }

  validate() {
    if(Array.isArray(this.notifyDestinations)) {
      $dara.Model.validateArray(this.notifyDestinations);
    }
    if(this.target && typeof (this.target as any).validate === 'function') {
      (this.target as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

