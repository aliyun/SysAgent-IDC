// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListScheduledTasksResponseBodyData extends $dara.Model {
  agentCode?: string;
  createdAt?: string;
  cronExp?: string;
  destinationId?: number;
  enable?: boolean;
  id?: number;
  inspectionId?: string;
  lastRunAt?: string;
  name?: string;
  nextRunAt?: string;
  prompt?: string;
  taskType?: string;
  updatedAt?: string;
  static names(): { [key: string]: string } {
    return {
      agentCode: 'agentCode',
      createdAt: 'createdAt',
      cronExp: 'cronExp',
      destinationId: 'destinationId',
      enable: 'enable',
      id: 'id',
      inspectionId: 'inspectionId',
      lastRunAt: 'lastRunAt',
      name: 'name',
      nextRunAt: 'nextRunAt',
      prompt: 'prompt',
      taskType: 'taskType',
      updatedAt: 'updatedAt',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentCode: 'string',
      createdAt: 'string',
      cronExp: 'string',
      destinationId: 'number',
      enable: 'boolean',
      id: 'number',
      inspectionId: 'string',
      lastRunAt: 'string',
      name: 'string',
      nextRunAt: 'string',
      prompt: 'string',
      taskType: 'string',
      updatedAt: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListScheduledTasksResponseBody extends $dara.Model {
  code?: string;
  data?: ListScheduledTasksResponseBodyData[];
  maxResults?: number;
  message?: string;
  nextToken?: string;
  requestId?: string;
  templates?: any;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
      requestId: 'requestId',
      templates: 'templates',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListScheduledTasksResponseBodyData },
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
      requestId: 'string',
      templates: 'any',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

