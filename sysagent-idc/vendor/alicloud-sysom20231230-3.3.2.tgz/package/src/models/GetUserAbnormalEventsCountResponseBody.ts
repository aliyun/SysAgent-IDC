// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetUserAbnormalEventsCountResponseBodyData extends $dara.Model {
  eventList?: string[];
  type?: string;
  value?: string;
  static names(): { [key: string]: string } {
    return {
      eventList: 'eventList',
      type: 'type',
      value: 'value',
    };
  }

  static types(): { [key: string]: any } {
    return {
      eventList: { 'type': 'array', 'itemType': 'string' },
      type: 'string',
      value: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.eventList)) {
      $dara.Model.validateArray(this.eventList);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetUserAbnormalEventsCountResponseBody extends $dara.Model {
  code?: string;
  data?: GetUserAbnormalEventsCountResponseBodyData[];
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': GetUserAbnormalEventsCountResponseBodyData },
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

