// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateFileUploadRequest extends $dara.Model {
  /**
   * @example
   * application/gzip
   */
  contentType?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * training.log.gz
   */
  filename?: string;
  sessionId?: string;
  size?: number;
  static names(): { [key: string]: string } {
    return {
      contentType: 'contentType',
      filename: 'filename',
      sessionId: 'sessionId',
      size: 'size',
    };
  }

  static types(): { [key: string]: any } {
    return {
      contentType: 'string',
      filename: 'string',
      sessionId: 'string',
      size: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

