// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CreateUserFeedbackRequest extends $dara.Model {
  /**
   * @remarks
   * This parameter is required.
   */
  content?: string;
  /**
   * @remarks
   * 可选，最多 6 张。当前账号已上传的 PNG/JPEG/WebP 截图，每张最多 10 MiB。不是 URL。
   */
  screenshots?: string[];
  static names(): { [key: string]: string } {
    return {
      content: 'content',
      screenshots: 'screenshots',
    };
  }

  static types(): { [key: string]: any } {
    return {
      content: 'string',
      screenshots: { 'type': 'array', 'itemType': 'string' },
    };
  }

  validate() {
    if(Array.isArray(this.screenshots)) {
      $dara.Model.validateArray(this.screenshots);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

