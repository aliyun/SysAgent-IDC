// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetInspectionScheduleRequest extends $dara.Model {
  /**
   * @example
   * insp-sched-2f1c9d4e-6b7a-4c31-9a52-0e8f7d6c5b4a
   */
  id?: string;
  static names(): { [key: string]: string } {
    return {
      id: 'id',
    };
  }

  static types(): { [key: string]: any } {
    return {
      id: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

