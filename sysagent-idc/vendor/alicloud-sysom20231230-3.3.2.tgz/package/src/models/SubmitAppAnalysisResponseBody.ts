// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class SubmitAppAnalysisResponseBodyData extends $dara.Model {
  analysisId?: string;
  graph?: any;
  summary?: any;
  static names(): { [key: string]: string } {
    return {
      analysisId: 'analysisId',
      graph: 'graph',
      summary: 'summary',
    };
  }

  static types(): { [key: string]: any } {
    return {
      analysisId: 'string',
      graph: 'any',
      summary: 'any',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class SubmitAppAnalysisResponseBody extends $dara.Model {
  code?: number;
  data?: SubmitAppAnalysisResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'number',
      data: SubmitAppAnalysisResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

