// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CompleteFileUploadRequest extends $dara.Model {
  sessionId?: string;
  /**
   * @remarks
   * This parameter is required.
   * 
   * @example
   * 3
   */
  totalParts?: number;
  static names(): { [key: string]: string } {
    return {
      sessionId: 'sessionId',
      totalParts: 'totalParts',
    };
  }

  static types(): { [key: string]: any } {
    return {
      sessionId: 'string',
      totalParts: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

