// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class DeleteInspectionScheduleRequest extends $dara.Model {
  id?: string;
  static names(): { [key: string]: string } {
    return {
      id: 'id',
    };
  }

  static types(): { [key: string]: any } {
    return {
      id: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

