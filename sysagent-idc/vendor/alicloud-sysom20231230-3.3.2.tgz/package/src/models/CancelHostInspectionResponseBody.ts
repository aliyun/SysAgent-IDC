// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class CancelHostInspectionResponseBody extends $dara.Model {
  inspectionId?: string;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      inspectionId: 'inspectionId',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      inspectionId: 'string',
      status: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

