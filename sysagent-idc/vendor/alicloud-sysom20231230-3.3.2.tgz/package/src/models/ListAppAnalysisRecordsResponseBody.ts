// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListAppAnalysisRecordsResponseBodyData extends $dara.Model {
  analysisId?: string;
  /**
   * @remarks
   * JSON格式的分析结果字符串
   */
  analysisResult?: string;
  analysisTime?: string;
  /**
   * @remarks
   * JSON格式的分析参数字符串
   */
  arguments?: string;
  failedLog?: string;
  failedLogI18n?: string;
  id?: number;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      analysisId: 'analysisId',
      analysisResult: 'analysisResult',
      analysisTime: 'analysisTime',
      arguments: 'arguments',
      failedLog: 'failedLog',
      failedLogI18n: 'failedLog_i18n',
      id: 'id',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      analysisId: 'string',
      analysisResult: 'string',
      analysisTime: 'string',
      arguments: 'string',
      failedLog: 'string',
      failedLogI18n: 'string',
      id: 'number',
      status: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class ListAppAnalysisRecordsResponseBody extends $dara.Model {
  code?: string;
  /**
   * @remarks
   * 应用热点分析记录数组
   */
  data?: ListAppAnalysisRecordsResponseBodyData[];
  maxResults?: number;
  message?: string;
  nextToken?: string;
  requestId?: string;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      maxResults: 'maxResults',
      message: 'message',
      nextToken: 'nextToken',
      requestId: 'requestId',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': ListAppAnalysisRecordsResponseBodyData },
      maxResults: 'number',
      message: 'string',
      nextToken: 'string',
      requestId: 'string',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

