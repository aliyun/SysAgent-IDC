// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentDiagnosisListResponseBodyDataList extends $dara.Model {
  agentName?: string;
  createdAt?: string;
  finishedAt?: string;
  healthScore?: number;
  instance?: string;
  status?: string;
  subStatus?: string;
  taskId?: string;
  timeRangeEnd?: string;
  timeRangeStart?: string;
  totalIssues?: number;
  unresolvedCount?: number;
  static names(): { [key: string]: string } {
    return {
      agentName: 'agentName',
      createdAt: 'createdAt',
      finishedAt: 'finishedAt',
      healthScore: 'healthScore',
      instance: 'instance',
      status: 'status',
      subStatus: 'subStatus',
      taskId: 'taskId',
      timeRangeEnd: 'timeRangeEnd',
      timeRangeStart: 'timeRangeStart',
      totalIssues: 'totalIssues',
      unresolvedCount: 'unresolvedCount',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentName: 'string',
      createdAt: 'string',
      finishedAt: 'string',
      healthScore: 'number',
      instance: 'string',
      status: 'string',
      subStatus: 'string',
      taskId: 'string',
      timeRangeEnd: 'string',
      timeRangeStart: 'string',
      totalIssues: 'number',
      unresolvedCount: 'number',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisListResponseBodyData extends $dara.Model {
  list?: GetAgentDiagnosisListResponseBodyDataList[];
  page?: number;
  pageSize?: number;
  total?: number;
  static names(): { [key: string]: string } {
    return {
      list: 'list',
      page: 'page',
      pageSize: 'pageSize',
      total: 'total',
    };
  }

  static types(): { [key: string]: any } {
    return {
      list: { 'type': 'array', 'itemType': GetAgentDiagnosisListResponseBodyDataList },
      page: 'number',
      pageSize: 'number',
      total: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.list)) {
      $dara.Model.validateArray(this.list);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentDiagnosisListResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentDiagnosisListResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentDiagnosisListResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

