// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentTokenTimeseriesResponseBodyDataSeries extends $dara.Model {
  data?: number[][];
  name?: string;
  static names(): { [key: string]: string } {
    return {
      data: 'data',
      name: 'name',
    };
  }

  static types(): { [key: string]: any } {
    return {
      data: { 'type': 'array', 'itemType': { 'type': 'array', 'itemType': 'number' } },
      name: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentTokenTimeseriesResponseBodyData extends $dara.Model {
  interval?: string;
  series?: GetAgentTokenTimeseriesResponseBodyDataSeries[];
  static names(): { [key: string]: string } {
    return {
      interval: 'interval',
      series: 'series',
    };
  }

  static types(): { [key: string]: any } {
    return {
      interval: 'string',
      series: { 'type': 'array', 'itemType': GetAgentTokenTimeseriesResponseBodyDataSeries },
    };
  }

  validate() {
    if(Array.isArray(this.series)) {
      $dara.Model.validateArray(this.series);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentTokenTimeseriesResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentTokenTimeseriesResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentTokenTimeseriesResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

