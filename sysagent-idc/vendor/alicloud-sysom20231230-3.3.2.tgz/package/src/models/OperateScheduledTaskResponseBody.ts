// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class OperateScheduledTaskResponseBodyData extends $dara.Model {
  agentCode?: string;
  createdAt?: string;
  cronExp?: string;
  destinationId?: number;
  enable?: boolean;
  id?: number;
  inspectionId?: string;
  lastRunAt?: string;
  name?: string;
  nextRunAt?: string;
  prompt?: string;
  updatedAt?: string;
  static names(): { [key: string]: string } {
    return {
      agentCode: 'agentCode',
      createdAt: 'createdAt',
      cronExp: 'cronExp',
      destinationId: 'destinationId',
      enable: 'enable',
      id: 'id',
      inspectionId: 'inspectionId',
      lastRunAt: 'lastRunAt',
      name: 'name',
      nextRunAt: 'nextRunAt',
      prompt: 'prompt',
      updatedAt: 'updatedAt',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agentCode: 'string',
      createdAt: 'string',
      cronExp: 'string',
      destinationId: 'number',
      enable: 'boolean',
      id: 'number',
      inspectionId: 'string',
      lastRunAt: 'string',
      name: 'string',
      nextRunAt: 'string',
      prompt: 'string',
      updatedAt: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class OperateScheduledTaskResponseBody extends $dara.Model {
  code?: string;
  data?: OperateScheduledTaskResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: OperateScheduledTaskResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

