// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetClusterK8sNodeLabelResponseBodyData extends $dara.Model {
  instance?: string;
  labels?: string[][];
  nodeName?: string;
  static names(): { [key: string]: string } {
    return {
      instance: 'instance',
      labels: 'labels',
      nodeName: 'nodeName',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instance: 'string',
      labels: { 'type': 'array', 'itemType': { 'type': 'array', 'itemType': 'string' } },
      nodeName: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.labels)) {
      $dara.Model.validateArray(this.labels);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetClusterK8sNodeLabelResponseBody extends $dara.Model {
  code?: string;
  data?: GetClusterK8sNodeLabelResponseBodyData[];
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: { 'type': 'array', 'itemType': GetClusterK8sNodeLabelResponseBodyData },
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.data)) {
      $dara.Model.validateArray(this.data);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

