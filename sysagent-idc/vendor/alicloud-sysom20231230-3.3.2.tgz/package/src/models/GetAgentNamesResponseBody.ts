// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetAgentNamesResponseBodyData extends $dara.Model {
  agents?: string[];
  count?: number;
  static names(): { [key: string]: string } {
    return {
      agents: 'agents',
      count: 'count',
    };
  }

  static types(): { [key: string]: any } {
    return {
      agents: { 'type': 'array', 'itemType': 'string' },
      count: 'number',
    };
  }

  validate() {
    if(Array.isArray(this.agents)) {
      $dara.Model.validateArray(this.agents);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GetAgentNamesResponseBody extends $dara.Model {
  code?: string;
  data?: GetAgentNamesResponseBodyData;
  message?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GetAgentNamesResponseBodyData,
      message: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

