// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GetHotSpotUniqListRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * The end time.
   * 
   * This parameter is required.
   * 
   * @example
   * 1735010351000
   */
  begEnd?: number;
  /**
   * @remarks
   * The start time.
   * 
   * This parameter is required.
   * 
   * @example
   * 1735008551000
   */
  begStart?: number;
  /**
   * @remarks
   * The instance ID.
   * 
   * This parameter is required.
   * 
   * @example
   * i-bp1g2i0siirefgwnnnvy
   */
  instance?: string;
  /**
   * @remarks
   * The process ID.
   * 
   * @example
   * 12345
   */
  pid?: number;
  /**
   * @remarks
   * The table name.
   * 
   * @example
   * prof_on
   */
  table?: string;
  /**
   * @remarks
   * The identifier flag.
   * 
   * This parameter is required.
   * 
   * @example
   * The default value must be "flag", which specifies the field to query
   */
  uniq?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      begEnd: 'beg_end',
      begStart: 'beg_start',
      instance: 'instance',
      pid: 'pid',
      table: 'table',
      uniq: 'uniq',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      begEnd: 'number',
      begStart: 'number',
      instance: 'string',
      pid: 'number',
      table: 'string',
      uniq: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

