// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class GenerateInspectionHumanReportResponseBodyData extends $dara.Model {
  humanReport?: string;
  humanReportSource?: string;
  static names(): { [key: string]: string } {
    return {
      humanReport: 'humanReport',
      humanReportSource: 'humanReportSource',
    };
  }

  static types(): { [key: string]: any } {
    return {
      humanReport: 'string',
      humanReportSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class GenerateInspectionHumanReportResponseBody extends $dara.Model {
  code?: string;
  data?: GenerateInspectionHumanReportResponseBodyData;
  message?: string;
  requestId?: string;
  static names(): { [key: string]: string } {
    return {
      code: 'code',
      data: 'data',
      message: 'message',
      requestId: 'requestId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      code: 'string',
      data: GenerateInspectionHumanReportResponseBodyData,
      message: 'string',
      requestId: 'string',
    };
  }

  validate() {
    if(this.data && typeof (this.data as any).validate === 'function') {
      (this.data as any).validate();
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

