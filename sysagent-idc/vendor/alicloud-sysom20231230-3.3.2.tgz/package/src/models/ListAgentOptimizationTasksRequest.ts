// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListAgentOptimizationTasksRequest extends $dara.Model {
  xDebugId?: string;
  current?: number;
  pageSize?: number;
  /**
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      current: 'current',
      pageSize: 'pageSize',
      regionId: 'regionId',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      current: 'number',
      pageSize: 'number',
      regionId: 'string',
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

