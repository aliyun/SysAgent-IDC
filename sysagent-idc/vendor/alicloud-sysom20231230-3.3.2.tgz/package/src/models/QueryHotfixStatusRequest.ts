// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class QueryHotfixStatusRequestInstances extends $dara.Model {
  /**
   * @remarks
   * The instance ID.
   * 
   * This parameter is required.
   * 
   * @example
   * i-bp1example
   */
  instanceId?: string;
  /**
   * @remarks
   * The region ID.
   * 
   * This parameter is required.
   * 
   * @example
   * cn-hangzhou
   */
  regionId?: string;
  static names(): { [key: string]: string } {
    return {
      instanceId: 'instanceId',
      regionId: 'regionId',
    };
  }

  static types(): { [key: string]: any } {
    return {
      instanceId: 'string',
      regionId: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

export class QueryHotfixStatusRequest extends $dara.Model {
  xDebugId?: string;
  /**
   * @remarks
   * CVE ID
   * 
   * This parameter is required.
   * 
   * @example
   * CVE-2026-12345
   */
  cveId?: string;
  /**
   * @remarks
   * The target instances.
   * 
   * This parameter is required.
   */
  instances?: QueryHotfixStatusRequestInstances[];
  xSysomInvokeSource?: string;
  static names(): { [key: string]: string } {
    return {
      xDebugId: 'X-Debug-Id',
      cveId: 'cveId',
      instances: 'instances',
      xSysomInvokeSource: 'x-sysom-invoke-source',
    };
  }

  static types(): { [key: string]: any } {
    return {
      xDebugId: 'string',
      cveId: 'string',
      instances: { 'type': 'array', 'itemType': QueryHotfixStatusRequestInstances },
      xSysomInvokeSource: 'string',
    };
  }

  validate() {
    if(Array.isArray(this.instances)) {
      $dara.Model.validateArray(this.instances);
    }
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

