// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


export class ListHostInspectionsRequest extends $dara.Model {
  current?: number;
  deviceId?: string;
  maxResults?: number;
  nextToken?: string;
  pageSize?: number;
  status?: string;
  static names(): { [key: string]: string } {
    return {
      current: 'current',
      deviceId: 'deviceId',
      maxResults: 'maxResults',
      nextToken: 'nextToken',
      pageSize: 'pageSize',
      status: 'status',
    };
  }

  static types(): { [key: string]: any } {
    return {
      current: 'number',
      deviceId: 'string',
      maxResults: 'number',
      nextToken: 'string',
      pageSize: 'number',
      status: 'string',
    };
  }

  validate() {
    super.validate();
  }

  constructor(map?: { [key: string]: any }) {
    super(map);
  }
}

