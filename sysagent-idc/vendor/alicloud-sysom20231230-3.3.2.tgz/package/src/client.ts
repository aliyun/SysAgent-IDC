// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';
import GatewayClient from '@alicloud/gateway-pop';
import OpenApi from '@alicloud/openapi-core';
import { OpenApiUtil, $OpenApiUtil }from '@alicloud/openapi-core';
import { WebSocketUtils }from '@alicloud/openapi-core';


import * as $_model from './models/model';
export * from './models/model';

export default class Client extends OpenApi {

  constructor(config: $OpenApiUtil.Config) {
    super(config);
    this._productId = "SysOM";
    let gatewayClient = new GatewayClient();
    this._spi = gatewayClient;
    this._endpointRule = "regional";
    this.checkConfig(config);
    this._endpoint = this.getEndpoint("sysom", this._regionId, this._endpointRule, this._network, this._suffix, this._endpointMap, this._endpoint);
  }


  getEndpoint(productId: string, regionId: string, endpointRule: string, network: string, suffix: string, endpointMap: {[key: string ]: string}, endpoint: string): string {
    if (!$dara.isNull(endpoint)) {
      return endpoint;
    }

    if (!$dara.isNull(endpointMap) && !$dara.isNull(endpointMap[regionId])) {
      return endpointMap[regionId];
    }

    return OpenApiUtil.getEndpointRules(productId, regionId, endpointRule, network, suffix);
  }

  /**
   * Authorizes SysOM to diagnose ECS instances under the current account. You must call this operation to authorize diagnostics on a specific ECS instance before you can call the InvokeDiagnosis operation to initiate diagnostics on it.
   * 
   * @remarks
   * >Notice: The diagnostics feature requires a service-linked role to be created under the Resource Access Management (RAM) user. Invoking this operation automatically checks whether the service-linked role exists and creates it if it does not. The RAM user that invokes this operation must have the ram:CreateServiceLinkedRole permission.</notice>
   * Note the following when you invoke this operation to authorize SysOM to diagnose ECS instances:
   * - Each authorization is valid for 7 days. After 7 days, the authorization expires and you must invoke this operation again to re-authorize.
   * - If the SysOM service-linked role (AliyunServiceRoleForSysom) does not exist when you invoke this operation, automatic creation is performed. The Resource Access Management (RAM) user that invokes this operation must have the `ram:CreateServiceLinkedRole` permission.
   * - When you invoke this operation to authorize diagnostics on a specific instance, the label `sysom:diagnosis` is automatically associated with the target ECS instance. SysOM only allows diagnostics on instances that have this label.
   * 
   * @param request - AuthDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns AuthDiagnosisResponse
   */
  async authDiagnosisWithOptions(request: $_model.AuthDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.AuthDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.autoCreateRole)) {
      body["autoCreateRole"] = request.autoCreateRole;
    }

    if (!$dara.isNull(request.autoInstallAgent)) {
      body["autoInstallAgent"] = request.autoInstallAgent;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "AuthDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/diagnosis/auth`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.AuthDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.AuthDiagnosisResponse({}));
  }

  /**
   * Authorizes SysOM to diagnose ECS instances under the current account. You must call this operation to authorize diagnostics on a specific ECS instance before you can call the InvokeDiagnosis operation to initiate diagnostics on it.
   * 
   * @remarks
   * >Notice: The diagnostics feature requires a service-linked role to be created under the Resource Access Management (RAM) user. Invoking this operation automatically checks whether the service-linked role exists and creates it if it does not. The RAM user that invokes this operation must have the ram:CreateServiceLinkedRole permission.</notice>
   * Note the following when you invoke this operation to authorize SysOM to diagnose ECS instances:
   * - Each authorization is valid for 7 days. After 7 days, the authorization expires and you must invoke this operation again to re-authorize.
   * - If the SysOM service-linked role (AliyunServiceRoleForSysom) does not exist when you invoke this operation, automatic creation is performed. The Resource Access Management (RAM) user that invokes this operation must have the `ram:CreateServiceLinkedRole` permission.
   * - When you invoke this operation to authorize diagnostics on a specific instance, the label `sysom:diagnosis` is automatically associated with the target ECS instance. SysOM only allows diagnostics on instances that have this label.
   * 
   * @param request - AuthDiagnosisRequest
   * @returns AuthDiagnosisResponse
   */
  async authDiagnosis(request: $_model.AuthDiagnosisRequest): Promise<$_model.AuthDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.authDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * 将诊断子操作与一个子诊断绑定
   * 
   * @param request - BindDiagnosisSubOperationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns BindDiagnosisSubOperationResponse
   */
  async bindDiagnosisSubOperationWithOptions(request: $_model.BindDiagnosisSubOperationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.BindDiagnosisSubOperationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.operationId)) {
      body["operationId"] = request.operationId;
    }

    if (!$dara.isNull(request.taskId)) {
      body["taskId"] = request.taskId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "BindDiagnosisSubOperation",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/diagnosis-fastapi/suboperation/bindDiagnosisSubOperation`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.BindDiagnosisSubOperationResponse>(await this.callApi(params, req, runtime), new $_model.BindDiagnosisSubOperationResponse({}));
  }

  /**
   * 将诊断子操作与一个子诊断绑定
   * 
   * @param request - BindDiagnosisSubOperationRequest
   * @returns BindDiagnosisSubOperationResponse
   */
  async bindDiagnosisSubOperation(request: $_model.BindDiagnosisSubOperationRequest): Promise<$_model.BindDiagnosisSubOperationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.bindDiagnosisSubOperationWithOptions(request, headers, runtime);
  }

  /**
   * 取消主机巡检任务
   * 
   * @remarks
   * 仅 created/uploaded/queued/downloading/validating 可取消；取消不删除报告，已建单时尽力把报告置为 Failed。
   * 
   * @param request - CancelHostInspectionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CancelHostInspectionResponse
   */
  async cancelHostInspectionWithOptions(request: $_model.CancelHostInspectionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CancelHostInspectionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionId)) {
      query["inspectionId"] = request.inspectionId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "CancelHostInspection",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/cancelHostInspection`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CancelHostInspectionResponse>(await this.callApi(params, req, runtime), new $_model.CancelHostInspectionResponse({}));
  }

  /**
   * 取消主机巡检任务
   * 
   * @remarks
   * 仅 created/uploaded/queued/downloading/validating 可取消；取消不删除报告，已建单时尽力把报告置为 Failed。
   * 
   * @param request - CancelHostInspectionRequest
   * @returns CancelHostInspectionResponse
   */
  async cancelHostInspection(request: $_model.CancelHostInspectionRequest): Promise<$_model.CancelHostInspectionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.cancelHostInspectionWithOptions(request, headers, runtime);
  }

  /**
   * Checks whether resources such as clusters and nodes support the current configuration.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - CheckAgentConfigSupportedRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CheckAgentConfigSupportedResponse
   */
  async checkAgentConfigSupportedWithOptions(request: $_model.CheckAgentConfigSupportedRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CheckAgentConfigSupportedResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.checkType)) {
      query["checkType"] = request.checkType;
    }

    if (!$dara.isNull(request.clusters)) {
      query["clusters"] = request.clusters;
    }

    if (!$dara.isNull(request.configId)) {
      query["configId"] = request.configId;
    }

    if (!$dara.isNull(request.content)) {
      query["content"] = request.content;
    }

    if (!$dara.isNull(request.instances)) {
      query["instances"] = request.instances;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "CheckAgentConfigSupported",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/checkAgentConfigSupported`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CheckAgentConfigSupportedResponse>(await this.callApi(params, req, runtime), new $_model.CheckAgentConfigSupportedResponse({}));
  }

  /**
   * Checks whether resources such as clusters and nodes support the current configuration.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - CheckAgentConfigSupportedRequest
   * @returns CheckAgentConfigSupportedResponse
   */
  async checkAgentConfigSupported(request: $_model.CheckAgentConfigSupportedRequest): Promise<$_model.CheckAgentConfigSupportedResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.checkAgentConfigSupportedWithOptions(request, headers, runtime);
  }

  /**
   * Checks whether target instances are supported by SysOM.
   * 
   * @remarks
   * The instance list returned by this operation contains only instances that are already managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - CheckInstanceSupportRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CheckInstanceSupportResponse
   */
  async checkInstanceSupportWithOptions(request: $_model.CheckInstanceSupportRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CheckInstanceSupportResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CheckInstanceSupport",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/supportInstanceList/checkInstanceSupport`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CheckInstanceSupportResponse>(await this.callApi(params, req, runtime), new $_model.CheckInstanceSupportResponse({}));
  }

  /**
   * Checks whether target instances are supported by SysOM.
   * 
   * @remarks
   * The instance list returned by this operation contains only instances that are already managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - CheckInstanceSupportRequest
   * @returns CheckInstanceSupportResponse
   */
  async checkInstanceSupport(request: $_model.CheckInstanceSupportRequest): Promise<$_model.CheckInstanceSupportResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.checkInstanceSupportWithOptions(request, headers, runtime);
  }

  /**
   * 合并 SuperBox 附件分片并落库，返回附件元信息与 analysisId
   * 
   * @param request - CompleteFileUploadRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CompleteFileUploadResponse
   */
  async completeFileUploadWithOptions(fileId: string, request: $_model.CompleteFileUploadRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CompleteFileUploadResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.sessionId)) {
      body["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.totalParts)) {
      body["totalParts"] = request.totalParts;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CompleteFileUpload",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiObservAgent/files/uploads/${$dara.URL.percentEncode(fileId)}/complete`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CompleteFileUploadResponse>(await this.callApi(params, req, runtime), new $_model.CompleteFileUploadResponse({}));
  }

  /**
   * 合并 SuperBox 附件分片并落库，返回附件元信息与 analysisId
   * 
   * @param request - CompleteFileUploadRequest
   * @returns CompleteFileUploadResponse
   */
  async completeFileUpload(fileId: string, request: $_model.CompleteFileUploadRequest): Promise<$_model.CompleteFileUploadResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.completeFileUploadWithOptions(fileId, request, headers, runtime);
  }

  /**
   * 建立 IDC Connector 到云端 Relay 的 WebSocket 长连接通道
   * 
   * @param request - ConnectIdcChannelRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ConnectIdcChannelResponse
   */
  async connectIdcChannelWithOptions(request: $_model.ConnectIdcChannelRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ConnectIdcChannelResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.connectorName)) {
      query["connectorName"] = request.connectorName;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ConnectIdcChannel",
      version: "2023-12-30",
      protocol: "wss",
      pathname: `/api/v1/idc/channel`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
      websocketSubProtocol: "general",
    });
    let res = new $_model.ConnectIdcChannelResponse({ });
    let tmp = await this.callApi(params, req, runtime);
    if (!$dara.isNull(tmp["webSocketClient"])) {
      res.webSocketClient = WebSocketUtils.createWebSocketClient(tmp["webSocketClient"]);
    }

    return res;
  }

  /**
   * 建立 IDC Connector 到云端 Relay 的 WebSocket 长连接通道
   * 
   * @param request - ConnectIdcChannelRequest
   * @returns ConnectIdcChannelResponse
   */
  async connectIdcChannel(request: $_model.ConnectIdcChannelRequest): Promise<$_model.ConnectIdcChannelResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.connectIdcChannelWithOptions(request, headers, runtime);
  }

  /**
   * Invokes the CPU high agent streaming SSE interface.
   * 
   * @param request - CpuHighAgentStreamResponseRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CpuHighAgentStreamResponseResponse
   */
  async *cpuHighAgentStreamResponseWithSSE(request: $_model.CpuHighAgentStreamResponseRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): AsyncGenerator<$_model.CpuHighAgentStreamResponseResponse, any, unknown> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.llmParamString)) {
      body["llmParamString"] = request.llmParamString;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CpuHighAgentStreamResponse",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/highCpuAgent/streamResponse`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    let sseResp = await this.callSSEApi(params, req, runtime);

    for await (let resp of sseResp) {
      if (!$dara.isNull(resp.event) && !$dara.isNull(resp.event.data)) {
        let data = JSON.parse(resp.event.data);
        yield $dara.cast<$_model.CpuHighAgentStreamResponseResponse>({
          statusCode: resp.statusCode,
          headers: resp.headers,
          id: resp.event.id,
          event: resp.event.event,
          body: data,
        }, new $_model.CpuHighAgentStreamResponseResponse({}));
      }

    }
  }

  /**
   * Invokes the CPU high agent streaming SSE interface.
   * 
   * @param request - CpuHighAgentStreamResponseRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CpuHighAgentStreamResponseResponse
   */
  async cpuHighAgentStreamResponseWithOptions(request: $_model.CpuHighAgentStreamResponseRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CpuHighAgentStreamResponseResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.llmParamString)) {
      body["llmParamString"] = request.llmParamString;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CpuHighAgentStreamResponse",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/highCpuAgent/streamResponse`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CpuHighAgentStreamResponseResponse>(await this.callApi(params, req, runtime), new $_model.CpuHighAgentStreamResponseResponse({}));
  }

  /**
   * Invokes the CPU high agent streaming SSE interface.
   * 
   * @param request - CpuHighAgentStreamResponseRequest
   * @returns CpuHighAgentStreamResponseResponse
   */
  async cpuHighAgentStreamResponse(request: $_model.CpuHighAgentStreamResponseRequest): Promise<$_model.CpuHighAgentStreamResponseResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.cpuHighAgentStreamResponseWithOptions(request, headers, runtime);
  }

  /**
   * Creates a component configuration.
   * 
   * @param request - CreateAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateAgentConfigResponse
   */
  async createAgentConfigWithOptions(request: $_model.CreateAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.configName)) {
      body["configName"] = request.configName;
    }

    if (!$dara.isNull(request.content)) {
      body["content"] = request.content;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/createAgentConfig`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.CreateAgentConfigResponse({}));
  }

  /**
   * Creates a component configuration.
   * 
   * @param request - CreateAgentConfigRequest
   * @returns CreateAgentConfigResponse
   */
  async createAgentConfig(request: $_model.CreateAgentConfigRequest): Promise<$_model.CreateAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * 发起 Agent 诊断任务
   * 
   * @param request - CreateAgentDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateAgentDiagnosisResponse
   */
  async createAgentDiagnosisWithOptions(request: $_model.CreateAgentDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateAgentDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentName)) {
      query["agentName"] = request.agentName;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateAgentDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/createAgentDiagnosis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateAgentDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.CreateAgentDiagnosisResponse({}));
  }

  /**
   * 发起 Agent 诊断任务
   * 
   * @param request - CreateAgentDiagnosisRequest
   * @returns CreateAgentDiagnosisResponse
   */
  async createAgentDiagnosis(request: $_model.CreateAgentDiagnosisRequest): Promise<$_model.CreateAgentDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createAgentDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * Creates a contact for alert notifications.
   * 
   * @param request - CreateAlertDestinationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateAlertDestinationResponse
   */
  async createAlertDestinationWithOptions(request: $_model.CreateAlertDestinationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateAlertDestinationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.appId)) {
      body["app_id"] = request.appId;
    }

    if (!$dara.isNull(request.appSecret)) {
      body["app_secret"] = request.appSecret;
    }

    if (!$dara.isNull(request.groupId)) {
      body["group_id"] = request.groupId;
    }

    if (!$dara.isNull(request.imbot)) {
      body["imbot"] = request.imbot;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.source)) {
      body["source"] = request.source;
    }

    if (!$dara.isNull(request.target)) {
      body["target"] = request.target;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateAlertDestination",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/createDestination`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateAlertDestinationResponse>(await this.callApi(params, req, runtime), new $_model.CreateAlertDestinationResponse({}));
  }

  /**
   * Creates a contact for alert notifications.
   * 
   * @param request - CreateAlertDestinationRequest
   * @returns CreateAlertDestinationResponse
   */
  async createAlertDestination(request: $_model.CreateAlertDestinationRequest): Promise<$_model.CreateAlertDestinationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createAlertDestinationWithOptions(request, headers, runtime);
  }

  /**
   * Creates an alert push policy.
   * 
   * @param request - CreateAlertStrategyRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateAlertStrategyResponse
   */
  async createAlertStrategyWithOptions(request: $_model.CreateAlertStrategyRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateAlertStrategyResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.k8sLabel)) {
      body["k8sLabel"] = request.k8sLabel;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.strategy)) {
      body["strategy"] = request.strategy;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateAlertStrategy",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/createStrategy`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateAlertStrategyResponse>(await this.callApi(params, req, runtime), new $_model.CreateAlertStrategyResponse({}));
  }

  /**
   * Creates an alert push policy.
   * 
   * @param request - CreateAlertStrategyRequest
   * @returns CreateAlertStrategyResponse
   */
  async createAlertStrategy(request: $_model.CreateAlertStrategyRequest): Promise<$_model.CreateAlertStrategyResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createAlertStrategyWithOptions(request, headers, runtime);
  }

  /**
   * Creates a VPC endpoint connection for a cluster.
   * 
   * @remarks
   * - Use this operation together with the call_sseapi operation in the aliyun-tea-openapi-inner package.
   * - Populate the parameters based on the input parameters of the general LLM service, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned string to a dictionary before use. Refer to the response format of the general LLM service.
   * 
   * @param request - CreateClusterVpcEndpointConnectionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateClusterVpcEndpointConnectionResponse
   */
  async createClusterVpcEndpointConnectionWithOptions(request: $_model.CreateClusterVpcEndpointConnectionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateClusterVpcEndpointConnectionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.clusterId)) {
      body["clusterId"] = request.clusterId;
    }

    if (!$dara.isNull(request.dryRun)) {
      body["dryRun"] = request.dryRun;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateClusterVpcEndpointConnection",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/k8sProxy/access/createClusterVpcEndpointConnection`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateClusterVpcEndpointConnectionResponse>(await this.callApi(params, req, runtime), new $_model.CreateClusterVpcEndpointConnectionResponse({}));
  }

  /**
   * Creates a VPC endpoint connection for a cluster.
   * 
   * @remarks
   * - Use this operation together with the call_sseapi operation in the aliyun-tea-openapi-inner package.
   * - Populate the parameters based on the input parameters of the general LLM service, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned string to a dictionary before use. Refer to the response format of the general LLM service.
   * 
   * @param request - CreateClusterVpcEndpointConnectionRequest
   * @returns CreateClusterVpcEndpointConnectionResponse
   */
  async createClusterVpcEndpointConnection(request: $_model.CreateClusterVpcEndpointConnectionRequest): Promise<$_model.CreateClusterVpcEndpointConnectionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createClusterVpcEndpointConnectionWithOptions(request, headers, runtime);
  }

  /**
   * Creates a Copilot session.
   * 
   * @remarks
   * - This operation only creates a session. It does not send messages or trigger agent execution.
   * - After the session is created, use the returned sessionId to call GenerateCopilotStreamResponse to send messages.
   * - The session ID is generated by the server and cannot be specified by the caller.
   * - Each successful call creates an independent session. This operation does not provide client-side idempotency parameters. Repeated calls may create multiple sessions.
   * 
   * @param request - CreateCopilotSessionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateCopilotSessionResponse
   */
  async createCopilotSessionWithOptions(request: $_model.CreateCopilotSessionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateCopilotSessionResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateCopilotSession",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/sessions`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateCopilotSessionResponse>(await this.callApi(params, req, runtime), new $_model.CreateCopilotSessionResponse({}));
  }

  /**
   * Creates a Copilot session.
   * 
   * @remarks
   * - This operation only creates a session. It does not send messages or trigger agent execution.
   * - After the session is created, use the returned sessionId to call GenerateCopilotStreamResponse to send messages.
   * - The session ID is generated by the server and cannot be specified by the caller.
   * - Each successful call creates an independent session. This operation does not provide client-side idempotency parameters. Repeated calls may create multiple sessions.
   * 
   * @param request - CreateCopilotSessionRequest
   * @returns CreateCopilotSessionResponse
   */
  async createCopilotSession(request: $_model.CreateCopilotSessionRequest): Promise<$_model.CreateCopilotSessionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createCopilotSessionWithOptions(request, headers, runtime);
  }

  /**
   * 创建ECS模型凭据兑换挑战
   * 
   * @remarks
   * 为ECS实例证明创建一次性、短时有效的模型凭据兑换挑战。
   * 
   * @param request - CreateEcsModelChallengeRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateEcsModelChallengeResponse
   */
  async createEcsModelChallengeWithOptions(request: $_model.CreateEcsModelChallengeRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateEcsModelChallengeResponse> {
    request.validate();
    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateEcsModelChallenge",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/identity/ecs-model/challenge`,
      method: "POST",
      authType: "Anonymous",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateEcsModelChallengeResponse>(await this.doROARequest(params.action, params.version, params.protocol, params.method, params.authType, params.pathname, params.bodyType, req, runtime), new $_model.CreateEcsModelChallengeResponse({}));
  }

  /**
   * 创建ECS模型凭据兑换挑战
   * 
   * @remarks
   * 为ECS实例证明创建一次性、短时有效的模型凭据兑换挑战。
   * 
   * @param request - CreateEcsModelChallengeRequest
   * @returns CreateEcsModelChallengeResponse
   */
  async createEcsModelChallenge(request: $_model.CreateEcsModelChallengeRequest): Promise<$_model.CreateEcsModelChallengeResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createEcsModelChallengeWithOptions(request, headers, runtime);
  }

  /**
   * 初始化 SuperBox 附件分片上传，返回 fileId 与分片参数
   * 
   * @param request - CreateFileUploadRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateFileUploadResponse
   */
  async createFileUploadWithOptions(request: $_model.CreateFileUploadRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateFileUploadResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.contentType)) {
      body["contentType"] = request.contentType;
    }

    if (!$dara.isNull(request.filename)) {
      body["filename"] = request.filename;
    }

    if (!$dara.isNull(request.sessionId)) {
      body["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.size)) {
      body["size"] = request.size;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateFileUpload",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiObservAgent/files/uploads`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateFileUploadResponse>(await this.callApi(params, req, runtime), new $_model.CreateFileUploadResponse({}));
  }

  /**
   * 初始化 SuperBox 附件分片上传，返回 fileId 与分片参数
   * 
   * @param request - CreateFileUploadRequest
   * @returns CreateFileUploadResponse
   */
  async createFileUpload(request: $_model.CreateFileUploadRequest): Promise<$_model.CreateFileUploadResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createFileUploadWithOptions(request, headers, runtime);
  }

  /**
   * 申请主机巡检快照的公网上传链接
   * 
   * @remarks
   * 服务端生成 inspectionId 与 objectKey 并调用 sysom_openapi 签发单 key、单 method、短 TTL 的预签名 PUT URL，同时落一条 created 任务；不返回任何 STS 凭证。
   * 
   * @param request - CreateHostInspectionUploadUrlRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateHostInspectionUploadUrlResponse
   */
  async createHostInspectionUploadUrlWithOptions(request: $_model.CreateHostInspectionUploadUrlRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateHostInspectionUploadUrlResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.arch)) {
      body["arch"] = request.arch;
    }

    if (!$dara.isNull(request.contentType)) {
      body["contentType"] = request.contentType;
    }

    if (!$dara.isNull(request.deviceId)) {
      body["deviceId"] = request.deviceId;
    }

    if (!$dara.isNull(request.expiresIn)) {
      body["expiresIn"] = request.expiresIn;
    }

    if (!$dara.isNull(request.hostname)) {
      body["hostname"] = request.hostname;
    }

    if (!$dara.isNull(request.machineId)) {
      body["machineId"] = request.machineId;
    }

    if (!$dara.isNull(request.os)) {
      body["os"] = request.os;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateHostInspectionUploadUrl",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/createHostInspectionUploadUrl`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateHostInspectionUploadUrlResponse>(await this.callApi(params, req, runtime), new $_model.CreateHostInspectionUploadUrlResponse({}));
  }

  /**
   * 申请主机巡检快照的公网上传链接
   * 
   * @remarks
   * 服务端生成 inspectionId 与 objectKey 并调用 sysom_openapi 签发单 key、单 method、短 TTL 的预签名 PUT URL，同时落一条 created 任务；不返回任何 STS 凭证。
   * 
   * @param request - CreateHostInspectionUploadUrlRequest
   * @returns CreateHostInspectionUploadUrlResponse
   */
  async createHostInspectionUploadUrl(request: $_model.CreateHostInspectionUploadUrlRequest): Promise<$_model.CreateHostInspectionUploadUrlResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createHostInspectionUploadUrlWithOptions(request, headers, runtime);
  }

  /**
   * 创建定时巡检计划
   * 
   * @param request - CreateInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateInspectionScheduleResponse
   */
  async createInspectionScheduleWithOptions(request: $_model.CreateInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateInspectionScheduleResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cronExpr)) {
      body["cronExpr"] = request.cronExpr;
    }

    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.fireTime)) {
      body["fireTime"] = request.fireTime;
    }

    if (!$dara.isNull(request.inspectionType)) {
      body["inspectionType"] = request.inspectionType;
    }

    if (!$dara.isNull(request.minSeverity)) {
      body["minSeverity"] = request.minSeverity;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.notifyDestinations)) {
      body["notifyDestinations"] = request.notifyDestinations;
    }

    if (!$dara.isNull(request.scheduleType)) {
      body["scheduleType"] = request.scheduleType;
    }

    if (!$dara.isNull(request.source)) {
      body["source"] = request.source;
    }

    if (!$dara.isNull(request.target)) {
      body["target"] = request.target;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/createInspectionSchedule`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.CreateInspectionScheduleResponse({}));
  }

  /**
   * 创建定时巡检计划
   * 
   * @param request - CreateInspectionScheduleRequest
   * @returns CreateInspectionScheduleResponse
   */
  async createInspectionSchedule(request: $_model.CreateInspectionScheduleRequest): Promise<$_model.CreateInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * Creates a SysOM instance inspection.
   * 
   * @param request - CreateInstanceInspectionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateInstanceInspectionResponse
   */
  async createInstanceInspectionWithOptions(request: $_model.CreateInstanceInspectionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateInstanceInspectionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.items)) {
      body["items"] = request.items;
    }

    if (!$dara.isNull(request.metricSource)) {
      body["metricSource"] = request.metricSource;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    if (!$dara.isNull(request.source)) {
      body["source"] = request.source;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateInstanceInspection",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/createInstanceInspection`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateInstanceInspectionResponse>(await this.callApi(params, req, runtime), new $_model.CreateInstanceInspectionResponse({}));
  }

  /**
   * Creates a SysOM instance inspection.
   * 
   * @param request - CreateInstanceInspectionRequest
   * @returns CreateInstanceInspectionResponse
   */
  async createInstanceInspection(request: $_model.CreateInstanceInspectionRequest): Promise<$_model.CreateInstanceInspectionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createInstanceInspectionWithOptions(request, headers, runtime);
  }

  /**
   * 提交用户问题反馈与建议
   * 
   * @param request - CreateUserFeedbackRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateUserFeedbackResponse
   */
  async createUserFeedbackWithOptions(request: $_model.CreateUserFeedbackRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateUserFeedbackResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.content)) {
      body["content"] = request.content;
    }

    if (!$dara.isNull(request.screenshots)) {
      body["screenshots"] = request.screenshots;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateUserFeedback",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/feedbacks`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateUserFeedbackResponse>(await this.callApi(params, req, runtime), new $_model.CreateUserFeedbackResponse({}));
  }

  /**
   * 提交用户问题反馈与建议
   * 
   * @param request - CreateUserFeedbackRequest
   * @returns CreateUserFeedbackResponse
   */
  async createUserFeedback(request: $_model.CreateUserFeedbackRequest): Promise<$_model.CreateUserFeedbackResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createUserFeedbackWithOptions(request, headers, runtime);
  }

  /**
   * Creates an intelligent breakdown diagnostic node to diagnose the vmcore or dmesg log file specified in the input parameters.
   * 
   * @param request - CreateVmcoreDiagnosisTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns CreateVmcoreDiagnosisTaskResponse
   */
  async createVmcoreDiagnosisTaskWithOptions(request: $_model.CreateVmcoreDiagnosisTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.CreateVmcoreDiagnosisTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.debuginfoCommonUrl)) {
      body["debuginfoCommonUrl"] = request.debuginfoCommonUrl;
    }

    if (!$dara.isNull(request.debuginfoUrl)) {
      body["debuginfoUrl"] = request.debuginfoUrl;
    }

    if (!$dara.isNull(request.dmesgUrl)) {
      body["dmesgUrl"] = request.dmesgUrl;
    }

    if (!$dara.isNull(request.taskType)) {
      body["taskType"] = request.taskType;
    }

    if (!$dara.isNull(request.vmcoreUrl)) {
      body["vmcoreUrl"] = request.vmcoreUrl;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "CreateVmcoreDiagnosisTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/crashAgent/diagnosis/createDiagnosisTask`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.CreateVmcoreDiagnosisTaskResponse>(await this.callApi(params, req, runtime), new $_model.CreateVmcoreDiagnosisTaskResponse({}));
  }

  /**
   * Creates an intelligent breakdown diagnostic node to diagnose the vmcore or dmesg log file specified in the input parameters.
   * 
   * @param request - CreateVmcoreDiagnosisTaskRequest
   * @returns CreateVmcoreDiagnosisTaskResponse
   */
  async createVmcoreDiagnosisTask(request: $_model.CreateVmcoreDiagnosisTaskRequest): Promise<$_model.CreateVmcoreDiagnosisTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.createVmcoreDiagnosisTaskWithOptions(request, headers, runtime);
  }

  /**
   * Deletes a component configuration.
   * 
   * @param request - DeleteAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DeleteAgentConfigResponse
   */
  async deleteAgentConfigWithOptions(request: $_model.DeleteAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DeleteAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.configId)) {
      query["configId"] = request.configId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DeleteAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/deleteAgentConfig`,
      method: "DELETE",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DeleteAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.DeleteAgentConfigResponse({}));
  }

  /**
   * Deletes a component configuration.
   * 
   * @param request - DeleteAgentConfigRequest
   * @returns DeleteAgentConfigResponse
   */
  async deleteAgentConfig(request: $_model.DeleteAgentConfigRequest): Promise<$_model.DeleteAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.deleteAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * Deletes an alert contact.
   * 
   * @param request - DeleteAlertDestinationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DeleteAlertDestinationResponse
   */
  async deleteAlertDestinationWithOptions(request: $_model.DeleteAlertDestinationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DeleteAlertDestinationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DeleteAlertDestination",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/deleteDestination`,
      method: "DELETE",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DeleteAlertDestinationResponse>(await this.callApi(params, req, runtime), new $_model.DeleteAlertDestinationResponse({}));
  }

  /**
   * Deletes an alert contact.
   * 
   * @param request - DeleteAlertDestinationRequest
   * @returns DeleteAlertDestinationResponse
   */
  async deleteAlertDestination(request: $_model.DeleteAlertDestinationRequest): Promise<$_model.DeleteAlertDestinationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.deleteAlertDestinationWithOptions(request, headers, runtime);
  }

  /**
   * Deletes an alert policy for push alerting.
   * 
   * @param request - DeleteAlertStrategyRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DeleteAlertStrategyResponse
   */
  async deleteAlertStrategyWithOptions(request: $_model.DeleteAlertStrategyRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DeleteAlertStrategyResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DeleteAlertStrategy",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/deleteStrategy`,
      method: "DELETE",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DeleteAlertStrategyResponse>(await this.callApi(params, req, runtime), new $_model.DeleteAlertStrategyResponse({}));
  }

  /**
   * Deletes an alert policy for push alerting.
   * 
   * @param request - DeleteAlertStrategyRequest
   * @returns DeleteAlertStrategyResponse
   */
  async deleteAlertStrategy(request: $_model.DeleteAlertStrategyRequest): Promise<$_model.DeleteAlertStrategyResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.deleteAlertStrategyWithOptions(request, headers, runtime);
  }

  /**
   * Deletes a specified Copilot session.
   * 
   * @remarks
   * - You can delete only the sessions of the current user.
   * - You cannot delete a session that has an ongoing execution. Call the GenerateCopilotStreamResponse operation and send action=stop to stop the execution before you delete the session.
   * - After a session is deleted, you can no longer retrieve the session or its history by calling the session query operation.
   * - An error is returned if the session does not exist or does not belong to the current user. Success is not guaranteed if you repeatedly delete the same session.
   * - Deleting a session does not roll back executed operations or delete the scheduled task that created the session.
   * 
   * @param request - DeleteCopilotSessionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DeleteCopilotSessionResponse
   */
  async deleteCopilotSessionWithOptions(request: $_model.DeleteCopilotSessionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DeleteCopilotSessionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.sessionId)) {
      query["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DeleteCopilotSession",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/delete-session`,
      method: "DELETE",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DeleteCopilotSessionResponse>(await this.callApi(params, req, runtime), new $_model.DeleteCopilotSessionResponse({}));
  }

  /**
   * Deletes a specified Copilot session.
   * 
   * @remarks
   * - You can delete only the sessions of the current user.
   * - You cannot delete a session that has an ongoing execution. Call the GenerateCopilotStreamResponse operation and send action=stop to stop the execution before you delete the session.
   * - After a session is deleted, you can no longer retrieve the session or its history by calling the session query operation.
   * - An error is returned if the session does not exist or does not belong to the current user. Success is not guaranteed if you repeatedly delete the same session.
   * - Deleting a session does not roll back executed operations or delete the scheduled task that created the session.
   * 
   * @param request - DeleteCopilotSessionRequest
   * @returns DeleteCopilotSessionResponse
   */
  async deleteCopilotSession(request: $_model.DeleteCopilotSessionRequest): Promise<$_model.DeleteCopilotSessionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.deleteCopilotSessionWithOptions(request, headers, runtime);
  }

  /**
   * 删除定时巡检计划
   * 
   * @param request - DeleteInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DeleteInspectionScheduleResponse
   */
  async deleteInspectionScheduleWithOptions(request: $_model.DeleteInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DeleteInspectionScheduleResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DeleteInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/deleteInspectionSchedule`,
      method: "DELETE",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DeleteInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.DeleteInspectionScheduleResponse({}));
  }

  /**
   * 删除定时巡检计划
   * 
   * @param request - DeleteInspectionScheduleRequest
   * @returns DeleteInspectionScheduleResponse
   */
  async deleteInspectionSchedule(request: $_model.DeleteInspectionScheduleRequest): Promise<$_model.DeleteInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.deleteInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * Queries metric data.
   * 
   * @remarks
   * The instance list returned by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - DescribeMetricListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns DescribeMetricListResponse
   */
  async describeMetricListWithOptions(request: $_model.DescribeMetricListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.DescribeMetricListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.metricName)) {
      query["metricName"] = request.metricName;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "DescribeMetricList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/get/describeMetricList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.DescribeMetricListResponse>(await this.callApi(params, req, runtime), new $_model.DescribeMetricListResponse({}));
  }

  /**
   * Queries metric data.
   * 
   * @remarks
   * The instance list returned by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - DescribeMetricListRequest
   * @returns DescribeMetricListResponse
   */
  async describeMetricList(request: $_model.DescribeMetricListRequest): Promise<$_model.DescribeMetricListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.describeMetricListWithOptions(request, headers, runtime);
  }

  /**
   * 兑换ECS受限模型STS
   * 
   * @remarks
   * 使用绑定一次性挑战的ECS实例证明兑换900秒受限模型STS。
   * 
   * @param request - ExchangeEcsModelCredentialsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ExchangeEcsModelCredentialsResponse
   */
  async exchangeEcsModelCredentialsWithOptions(request: $_model.ExchangeEcsModelCredentialsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ExchangeEcsModelCredentialsResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.challengeId)) {
      body["challengeId"] = request.challengeId;
    }

    if (!$dara.isNull(request.pkcs7Base64)) {
      body["pkcs7Base64"] = request.pkcs7Base64;
    }

    if (!$dara.isNull(request.signedDocumentBase64)) {
      body["signedDocumentBase64"] = request.signedDocumentBase64;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "ExchangeEcsModelCredentials",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/identity/ecs-model/credentials`,
      method: "POST",
      authType: "Anonymous",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ExchangeEcsModelCredentialsResponse>(await this.doROARequest(params.action, params.version, params.protocol, params.method, params.authType, params.pathname, params.bodyType, req, runtime), new $_model.ExchangeEcsModelCredentialsResponse({}));
  }

  /**
   * 兑换ECS受限模型STS
   * 
   * @remarks
   * 使用绑定一次性挑战的ECS实例证明兑换900秒受限模型STS。
   * 
   * @param request - ExchangeEcsModelCredentialsRequest
   * @returns ExchangeEcsModelCredentialsResponse
   */
  async exchangeEcsModelCredentials(request: $_model.ExchangeEcsModelCredentialsRequest): Promise<$_model.ExchangeEcsModelCredentialsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.exchangeEcsModelCredentialsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the response result from the Copilot service.
   * 
   * @remarks
   * - Populate parameters according to the standard LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned data from a string to a dict before use. Refer to the standard LLM service response format.
   * 
   * @param request - GenerateCopilotResponseRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GenerateCopilotResponseResponse
   */
  async generateCopilotResponseWithOptions(request: $_model.GenerateCopilotResponseRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GenerateCopilotResponseResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.llmParamString)) {
      body["llmParamString"] = request.llmParamString;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GenerateCopilotResponse",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/generate_copilot_response`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GenerateCopilotResponseResponse>(await this.callApi(params, req, runtime), new $_model.GenerateCopilotResponseResponse({}));
  }

  /**
   * Retrieves the response result from the Copilot service.
   * 
   * @remarks
   * - Populate parameters according to the standard LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned data from a string to a dict before use. Refer to the standard LLM service response format.
   * 
   * @param request - GenerateCopilotResponseRequest
   * @returns GenerateCopilotResponseResponse
   */
  async generateCopilotResponse(request: $_model.GenerateCopilotResponseRequest): Promise<$_model.GenerateCopilotResponseResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.generateCopilotResponseWithOptions(request, headers, runtime);
  }

  /**
   * Provides a streaming SSE interface for the OS Copilot service.
   * 
   * @remarks
   * - Use this operation together with the call_sseapi interface in the aliyun-tea-openapi-inner package.
   * - Populate the parameters based on the standard LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned string data to a dict before use. Refer to the standard LLM service response format.
   * 
   * @param request - GenerateCopilotStreamResponseRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GenerateCopilotStreamResponseResponse
   */
  async *generateCopilotStreamResponseWithSSE(request: $_model.GenerateCopilotStreamResponseRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): AsyncGenerator<$_model.GenerateCopilotStreamResponseResponse, any, unknown> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.llmParamString)) {
      body["llmParamString"] = request.llmParamString;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GenerateCopilotStreamResponse",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/generate_copilot_stream_response`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    let sseResp = await this.callSSEApi(params, req, runtime);

    for await (let resp of sseResp) {
      if (!$dara.isNull(resp.event) && !$dara.isNull(resp.event.data)) {
        let data = JSON.parse(resp.event.data);
        yield $dara.cast<$_model.GenerateCopilotStreamResponseResponse>({
          statusCode: resp.statusCode,
          headers: resp.headers,
          id: resp.event.id,
          event: resp.event.event,
          body: data,
        }, new $_model.GenerateCopilotStreamResponseResponse({}));
      }

    }
  }

  /**
   * Provides a streaming SSE interface for the OS Copilot service.
   * 
   * @remarks
   * - Use this operation together with the call_sseapi interface in the aliyun-tea-openapi-inner package.
   * - Populate the parameters based on the standard LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned string data to a dict before use. Refer to the standard LLM service response format.
   * 
   * @param request - GenerateCopilotStreamResponseRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GenerateCopilotStreamResponseResponse
   */
  async generateCopilotStreamResponseWithOptions(request: $_model.GenerateCopilotStreamResponseRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GenerateCopilotStreamResponseResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.llmParamString)) {
      body["llmParamString"] = request.llmParamString;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GenerateCopilotStreamResponse",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/generate_copilot_stream_response`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GenerateCopilotStreamResponseResponse>(await this.callApi(params, req, runtime), new $_model.GenerateCopilotStreamResponseResponse({}));
  }

  /**
   * Provides a streaming SSE interface for the OS Copilot service.
   * 
   * @remarks
   * - Use this operation together with the call_sseapi interface in the aliyun-tea-openapi-inner package.
   * - Populate the parameters based on the standard LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned string data to a dict before use. Refer to the standard LLM service response format.
   * 
   * @param request - GenerateCopilotStreamResponseRequest
   * @returns GenerateCopilotStreamResponseResponse
   */
  async generateCopilotStreamResponse(request: $_model.GenerateCopilotStreamResponseRequest): Promise<$_model.GenerateCopilotStreamResponseResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.generateCopilotStreamResponseWithOptions(request, headers, runtime);
  }

  /**
   * 为巡检报告按需生成人类可读结论
   * 
   * @param request - GenerateInspectionHumanReportRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GenerateInspectionHumanReportResponse
   */
  async generateInspectionHumanReportWithOptions(request: $_model.GenerateInspectionHumanReportRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GenerateInspectionHumanReportResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.reportId)) {
      body["reportId"] = request.reportId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GenerateInspectionHumanReport",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/generateInspectionHumanReport`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GenerateInspectionHumanReportResponse>(await this.callApi(params, req, runtime), new $_model.GenerateInspectionHumanReportResponse({}));
  }

  /**
   * 为巡检报告按需生成人类可读结论
   * 
   * @param request - GenerateInspectionHumanReportRequest
   * @returns GenerateInspectionHumanReportResponse
   */
  async generateInspectionHumanReport(request: $_model.GenerateInspectionHumanReportRequest): Promise<$_model.GenerateInspectionHumanReportResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.generateInspectionHumanReportWithOptions(request, headers, runtime);
  }

  /**
   * Queries AI Infra analysis results.
   * 
   * @param request - GetAIQueryResultRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAIQueryResultResponse
   */
  async getAIQueryResultWithOptions(request: $_model.GetAIQueryResultRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAIQueryResultResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.analysisId)) {
      body["analysisId"] = request.analysisId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAIQueryResult",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/app_observ/aiAnalysis/query_result`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAIQueryResultResponse>(await this.callApi(params, req, runtime), new $_model.GetAIQueryResultResponse({}));
  }

  /**
   * Queries AI Infra analysis results.
   * 
   * @param request - GetAIQueryResultRequest
   * @returns GetAIQueryResultResponse
   */
  async getAIQueryResult(request: $_model.GetAIQueryResultRequest): Promise<$_model.GetAIQueryResultResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAIQueryResultWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the number of unprocessed (undiagnosed) abnormal events at different severity levels for a node or pod.
   * 
   * @param request - GetAbnormalEventsCountRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAbnormalEventsCountResponse
   */
  async getAbnormalEventsCountWithOptions(request: $_model.GetAbnormalEventsCountRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAbnormalEventsCountResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.level)) {
      query["level"] = request.level;
    }

    if (!$dara.isNull(request.namespace)) {
      query["namespace"] = request.namespace;
    }

    if (!$dara.isNull(request.pod)) {
      query["pod"] = request.pod;
    }

    if (!$dara.isNull(request.showPod)) {
      query["showPod"] = request.showPod;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAbnormalEventsCount",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/abnormaly_events_count`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAbnormalEventsCountResponse>(await this.callApi(params, req, runtime), new $_model.GetAbnormalEventsCountResponse({}));
  }

  /**
   * Retrieves the number of unprocessed (undiagnosed) abnormal events at different severity levels for a node or pod.
   * 
   * @param request - GetAbnormalEventsCountRequest
   * @returns GetAbnormalEventsCountResponse
   */
  async getAbnormalEventsCount(request: $_model.GetAbnormalEventsCountRequest): Promise<$_model.GetAbnormalEventsCountResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAbnormalEventsCountWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the details of a specific component.
   * 
   * @param request - GetAgentRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentResponse
   */
  async getAgentWithOptions(request: $_model.GetAgentRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgent",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/get_agent`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentResponse({}));
  }

  /**
   * Retrieves the details of a specific component.
   * 
   * @param request - GetAgentRequest
   * @returns GetAgentResponse
   */
  async getAgent(request: $_model.GetAgentRequest): Promise<$_model.GetAgentResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the component configuration.
   * 
   * @param request - GetAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentConfigResponse
   */
  async getAgentConfigWithOptions(request: $_model.GetAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.configId)) {
      query["configId"] = request.configId;
    }

    if (!$dara.isNull(request.configName)) {
      query["configName"] = request.configName;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/getAgentConfig`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentConfigResponse({}));
  }

  /**
   * Retrieves the component configuration.
   * 
   * @param request - GetAgentConfigRequest
   * @returns GetAgentConfigResponse
   */
  async getAgentConfig(request: $_model.GetAgentConfigRequest): Promise<$_model.GetAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * 获取会话详情
   * 
   * @param request - GetAgentConversationDetailRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentConversationDetailResponse
   */
  async getAgentConversationDetailWithOptions(request: $_model.GetAgentConversationDetailRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentConversationDetailResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.conversationId)) {
      query["conversationId"] = request.conversationId;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentConversationDetail",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentConversationDetail`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentConversationDetailResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentConversationDetailResponse({}));
  }

  /**
   * 获取会话详情
   * 
   * @param request - GetAgentConversationDetailRequest
   * @returns GetAgentConversationDetailResponse
   */
  async getAgentConversationDetail(request: $_model.GetAgentConversationDetailRequest): Promise<$_model.GetAgentConversationDetailResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentConversationDetailWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 诊断详情
   * 
   * @param request - GetAgentDiagnosisDetailRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentDiagnosisDetailResponse
   */
  async getAgentDiagnosisDetailWithOptions(request: $_model.GetAgentDiagnosisDetailRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentDiagnosisDetailResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.interruptionType)) {
      query["interruptionType"] = request.interruptionType;
    }

    if (!$dara.isNull(request.page)) {
      query["page"] = request.page;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.resolved)) {
      query["resolved"] = request.resolved;
    }

    if (!$dara.isNull(request.severity)) {
      query["severity"] = request.severity;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentDiagnosisDetail",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentDiagnosisDetail`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentDiagnosisDetailResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentDiagnosisDetailResponse({}));
  }

  /**
   * 获取 Agent 诊断详情
   * 
   * @param request - GetAgentDiagnosisDetailRequest
   * @returns GetAgentDiagnosisDetailResponse
   */
  async getAgentDiagnosisDetail(request: $_model.GetAgentDiagnosisDetailRequest): Promise<$_model.GetAgentDiagnosisDetailResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentDiagnosisDetailWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 诊断列表
   * 
   * @param request - GetAgentDiagnosisListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentDiagnosisListResponse
   */
  async getAgentDiagnosisListWithOptions(request: $_model.GetAgentDiagnosisListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentDiagnosisListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.page)) {
      query["page"] = request.page;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentDiagnosisList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentDiagnosisList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentDiagnosisListResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentDiagnosisListResponse({}));
  }

  /**
   * 获取 Agent 诊断列表
   * 
   * @param request - GetAgentDiagnosisListRequest
   * @returns GetAgentDiagnosisListResponse
   */
  async getAgentDiagnosisList(request: $_model.GetAgentDiagnosisListRequest): Promise<$_model.GetAgentDiagnosisListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentDiagnosisListWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 实例列表
   * 
   * @param request - GetAgentInstancesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentInstancesResponse
   */
  async getAgentInstancesWithOptions(request: $_model.GetAgentInstancesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentInstancesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentInstances",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentInstances`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentInstancesResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentInstancesResponse({}));
  }

  /**
   * 获取 Agent 实例列表
   * 
   * @param request - GetAgentInstancesRequest
   * @returns GetAgentInstancesResponse
   */
  async getAgentInstances(request: $_model.GetAgentInstancesRequest): Promise<$_model.GetAgentInstancesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentInstancesWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 列表
   * 
   * @param request - GetAgentListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentListResponse
   */
  async getAgentListWithOptions(request: $_model.GetAgentListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentListResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentListResponse({}));
  }

  /**
   * 获取 Agent 列表
   * 
   * @param request - GetAgentListRequest
   * @returns GetAgentListResponse
   */
  async getAgentList(request: $_model.GetAgentListRequest): Promise<$_model.GetAgentListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentListWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 名称列表
   * 
   * @param request - GetAgentNamesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentNamesResponse
   */
  async getAgentNamesWithOptions(request: $_model.GetAgentNamesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentNamesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentNames",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentNames`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentNamesResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentNamesResponse({}));
  }

  /**
   * 获取 Agent 名称列表
   * 
   * @param request - GetAgentNamesRequest
   * @returns GetAgentNamesResponse
   */
  async getAgentNames(request: $_model.GetAgentNamesRequest): Promise<$_model.GetAgentNamesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentNamesWithOptions(request, headers, runtime);
  }

  /**
   * 查询 Agent 优化分析任务详情
   * 
   * @param request - GetAgentOptimizationTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentOptimizationTaskResponse
   */
  async getAgentOptimizationTaskWithOptions(request: $_model.GetAgentOptimizationTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentOptimizationTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentOptimizationTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentOptimizationTask`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentOptimizationTaskResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentOptimizationTaskResponse({}));
  }

  /**
   * 查询 Agent 优化分析任务详情
   * 
   * @param request - GetAgentOptimizationTaskRequest
   * @returns GetAgentOptimizationTaskResponse
   */
  async getAgentOptimizationTask(request: $_model.GetAgentOptimizationTaskRequest): Promise<$_model.GetAgentOptimizationTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentOptimizationTaskWithOptions(request, headers, runtime);
  }

  /**
   * 获取会话详情
   * 
   * @param request - GetAgentSessionDetailRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentSessionDetailResponse
   */
  async getAgentSessionDetailWithOptions(request: $_model.GetAgentSessionDetailRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentSessionDetailResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.sessionId)) {
      query["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentSessionDetail",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentSessionDetail`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentSessionDetailResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentSessionDetailResponse({}));
  }

  /**
   * 获取会话详情
   * 
   * @param request - GetAgentSessionDetailRequest
   * @returns GetAgentSessionDetailResponse
   */
  async getAgentSessionDetail(request: $_model.GetAgentSessionDetailRequest): Promise<$_model.GetAgentSessionDetailResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentSessionDetailWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent 会话列表
   * 
   * @param request - GetAgentSessionListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentSessionListResponse
   */
  async getAgentSessionListWithOptions(request: $_model.GetAgentSessionListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentSessionListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentName)) {
      query["agentName"] = request.agentName;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.page)) {
      query["page"] = request.page;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pid)) {
      query["pid"] = request.pid;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentSessionList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentSessionList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentSessionListResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentSessionListResponse({}));
  }

  /**
   * 获取 Agent 会话列表
   * 
   * @param request - GetAgentSessionListRequest
   * @returns GetAgentSessionListResponse
   */
  async getAgentSessionList(request: $_model.GetAgentSessionListRequest): Promise<$_model.GetAgentSessionListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentSessionListWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the execution status of an agent installation task.
   * 
   * @param request - GetAgentTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentTaskResponse
   */
  async getAgentTaskWithOptions(request: $_model.GetAgentTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["task_id"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/get_agent_task`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentTaskResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentTaskResponse({}));
  }

  /**
   * Retrieves the execution status of an agent installation task.
   * 
   * @param request - GetAgentTaskRequest
   * @returns GetAgentTaskResponse
   */
  async getAgentTask(request: $_model.GetAgentTaskRequest): Promise<$_model.GetAgentTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentTaskWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent Token 概览数据
   * 
   * @param request - GetAgentTokenOverviewRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentTokenOverviewResponse
   */
  async getAgentTokenOverviewWithOptions(request: $_model.GetAgentTokenOverviewRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentTokenOverviewResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentName)) {
      query["agentName"] = request.agentName;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pid)) {
      query["pid"] = request.pid;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentTokenOverview",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentTokenOverview`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentTokenOverviewResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentTokenOverviewResponse({}));
  }

  /**
   * 获取 Agent Token 概览数据
   * 
   * @param request - GetAgentTokenOverviewRequest
   * @returns GetAgentTokenOverviewResponse
   */
  async getAgentTokenOverview(request: $_model.GetAgentTokenOverviewRequest): Promise<$_model.GetAgentTokenOverviewResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentTokenOverviewWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Agent Token 时序数据
   * 
   * @param request - GetAgentTokenTimeseriesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAgentTokenTimeseriesResponse
   */
  async getAgentTokenTimeseriesWithOptions(request: $_model.GetAgentTokenTimeseriesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAgentTokenTimeseriesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentName)) {
      query["agentName"] = request.agentName;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.groupBy)) {
      query["groupBy"] = request.groupBy;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pid)) {
      query["pid"] = request.pid;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAgentTokenTimeseries",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAgentTokenTimeseries`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAgentTokenTimeseriesResponse>(await this.callApi(params, req, runtime), new $_model.GetAgentTokenTimeseriesResponse({}));
  }

  /**
   * 获取 Agent Token 时序数据
   * 
   * @param request - GetAgentTokenTimeseriesRequest
   * @returns GetAgentTokenTimeseriesResponse
   */
  async getAgentTokenTimeseries(request: $_model.GetAgentTokenTimeseriesRequest): Promise<$_model.GetAgentTokenTimeseriesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAgentTokenTimeseriesWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. Therefore, when you call this operation, the diagnosis may still be in progress. You can check the `data.status` field in the response to determine the status. If `data.status` is `Success`, the diagnosis is successful, and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetAifgResultRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAifgResultResponse
   */
  async getAifgResultWithOptions(request: $_model.GetAifgResultRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAifgResultResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAifgResult",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAifgResult`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAifgResultResponse>(await this.callApi(params, req, runtime), new $_model.GetAifgResultResponse({}));
  }

  /**
   * Retrieves the diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. Therefore, when you call this operation, the diagnosis may still be in progress. You can check the `data.status` field in the response to determine the status. If `data.status` is `Success`, the diagnosis is successful, and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetAifgResultRequest
   * @returns GetAifgResultResponse
   */
  async getAifgResult(request: $_model.GetAifgResultRequest): Promise<$_model.GetAifgResultResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAifgResultWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the URL for diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. Therefore, when you call this operation, the diagnosis may still be in progress. You can check the `data.status` field in the response to determine the status. If `data.status` is `Success`, the diagnosis is successful, and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetAifgUrlRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAifgUrlResponse
   */
  async getAifgUrlWithOptions(request: $_model.GetAifgUrlRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAifgUrlResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAifgUrl",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getAifgUrl`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAifgUrlResponse>(await this.callApi(params, req, runtime), new $_model.GetAifgUrlResponse({}));
  }

  /**
   * Retrieves the URL for diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. Therefore, when you call this operation, the diagnosis may still be in progress. You can check the `data.status` field in the response to determine the status. If `data.status` is `Success`, the diagnosis is successful, and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetAifgUrlRequest
   * @returns GetAifgUrlResponse
   */
  async getAifgUrl(request: $_model.GetAifgUrlRequest): Promise<$_model.GetAifgUrlResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAifgUrlWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the information of a specified alert contact.
   * 
   * @param request - GetAlertDestinationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAlertDestinationResponse
   */
  async getAlertDestinationWithOptions(request: $_model.GetAlertDestinationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAlertDestinationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAlertDestination",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/getDestination`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAlertDestinationResponse>(await this.callApi(params, req, runtime), new $_model.GetAlertDestinationResponse({}));
  }

  /**
   * Retrieves the information of a specified alert contact.
   * 
   * @param request - GetAlertDestinationRequest
   * @returns GetAlertDestinationResponse
   */
  async getAlertDestination(request: $_model.GetAlertDestinationRequest): Promise<$_model.GetAlertDestinationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAlertDestinationWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a user alert based on the policy ID.
   * 
   * @param request - GetAlertStrategyRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetAlertStrategyResponse
   */
  async getAlertStrategyWithOptions(request: $_model.GetAlertStrategyRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetAlertStrategyResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetAlertStrategy",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/getStrategy`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetAlertStrategyResponse>(await this.callApi(params, req, runtime), new $_model.GetAlertStrategyResponse({}));
  }

  /**
   * Retrieves a user alert based on the policy ID.
   * 
   * @param request - GetAlertStrategyRequest
   * @returns GetAlertStrategyResponse
   */
  async getAlertStrategy(request: $_model.GetAlertStrategyRequest): Promise<$_model.GetAlertStrategyResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getAlertStrategyWithOptions(request, headers, runtime);
  }

  /**
   * 获取集群分数整体分布情况
   * 
   * @param request - GetClusterHealthCountRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetClusterHealthCountResponse
   */
  async getClusterHealthCountWithOptions(request: $_model.GetClusterHealthCountRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetClusterHealthCountResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetClusterHealthCount",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/clusterHealthApi/getClusterHealthCount`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetClusterHealthCountResponse>(await this.callApi(params, req, runtime), new $_model.GetClusterHealthCountResponse({}));
  }

  /**
   * 获取集群分数整体分布情况
   * 
   * @param request - GetClusterHealthCountRequest
   * @returns GetClusterHealthCountResponse
   */
  async getClusterHealthCount(request: $_model.GetClusterHealthCountRequest): Promise<$_model.GetClusterHealthCountResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getClusterHealthCountWithOptions(request, headers, runtime);
  }

  /**
   * 获取集群的 K8s 元数据信息
   * 
   * @param request - GetClusterK8sInfoRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetClusterK8sInfoResponse
   */
  async getClusterK8sInfoWithOptions(request: $_model.GetClusterK8sInfoRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetClusterK8sInfoResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["clusterId"] = request.clusterId;
    }

    if (!$dara.isNull(request.infoType)) {
      query["infoType"] = request.infoType;
    }

    if (!$dara.isNull(request.labelSelector)) {
      query["labelSelector"] = request.labelSelector;
    }

    if (!$dara.isNull(request.namespace)) {
      query["namespace"] = request.namespace;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetClusterK8sInfo",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/k8sProxy/access/k8sInfo`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetClusterK8sInfoResponse>(await this.callApi(params, req, runtime), new $_model.GetClusterK8sInfoResponse({}));
  }

  /**
   * 获取集群的 K8s 元数据信息
   * 
   * @param request - GetClusterK8sInfoRequest
   * @returns GetClusterK8sInfoResponse
   */
  async getClusterK8sInfo(request: $_model.GetClusterK8sInfoRequest): Promise<$_model.GetClusterK8sInfoResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getClusterK8sInfoWithOptions(request, headers, runtime);
  }

  /**
   * 查询k8s集群节点标签
   * 
   * @param request - GetClusterK8sNodeLabelRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetClusterK8sNodeLabelResponse
   */
  async getClusterK8sNodeLabelWithOptions(request: $_model.GetClusterK8sNodeLabelRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetClusterK8sNodeLabelResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["clusterId"] = request.clusterId;
    }

    if (!$dara.isNull(request.filter)) {
      query["filter"] = request.filter;
    }

    if (!$dara.isNull(request.instances)) {
      query["instances"] = request.instances;
    }

    if (!$dara.isNull(request.mode)) {
      query["mode"] = request.mode;
    }

    if (!$dara.isNull(request.nodeNames)) {
      query["nodeNames"] = request.nodeNames;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetClusterK8sNodeLabel",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/k8sProxy/access/k8sNodeLabels`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetClusterK8sNodeLabelResponse>(await this.callApi(params, req, runtime), new $_model.GetClusterK8sNodeLabelResponse({}));
  }

  /**
   * 查询k8s集群节点标签
   * 
   * @param request - GetClusterK8sNodeLabelRequest
   * @returns GetClusterK8sNodeLabelResponse
   */
  async getClusterK8sNodeLabel(request: $_model.GetClusterK8sNodeLabelRequest): Promise<$_model.GetClusterK8sNodeLabelResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getClusterK8sNodeLabelWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves configuration information by configuration name.
   * 
   * @param request - GetConfigByNameRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetConfigByNameResponse
   */
  async getConfigByNameWithOptions(request: $_model.GetConfigByNameRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetConfigByNameResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.configName)) {
      query["configName"] = request.configName;
    }

    if (!$dara.isNull(request.configType)) {
      query["configType"] = request.configType;
    }

    if (!$dara.isNull(request.entityId)) {
      query["entityId"] = request.entityId;
    }

    if (!$dara.isNull(request.useGlobalUid)) {
      query["useGlobalUid"] = request.useGlobalUid;
    }

    if (!$dara.isNull(request.versionId)) {
      query["versionId"] = request.versionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetConfigByName",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/configManage/config/getConfigByName`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetConfigByNameResponse>(await this.callApi(params, req, runtime), new $_model.GetConfigByNameResponse({}));
  }

  /**
   * Retrieves configuration information by configuration name.
   * 
   * @param request - GetConfigByNameRequest
   * @returns GetConfigByNameResponse
   */
  async getConfigByName(request: $_model.GetConfigByNameRequest): Promise<$_model.GetConfigByNameResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getConfigByNameWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the historical chat records of Copilot.
   * 
   * @param request - GetCopilotHistoryRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetCopilotHistoryResponse
   */
  async getCopilotHistoryWithOptions(request: $_model.GetCopilotHistoryRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetCopilotHistoryResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.count)) {
      body["count"] = request.count;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetCopilotHistory",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/get_copilot_history`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetCopilotHistoryResponse>(await this.callApi(params, req, runtime), new $_model.GetCopilotHistoryResponse({}));
  }

  /**
   * Retrieves the historical chat records of Copilot.
   * 
   * @param request - GetCopilotHistoryRequest
   * @returns GetCopilotHistoryResponse
   */
  async getCopilotHistory(request: $_model.GetCopilotHistoryRequest): Promise<$_model.GetCopilotHistoryResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getCopilotHistoryWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the Copilot session and execution status.
   * 
   * @remarks
   * - You can query only the sessions of the current user, one session at a time.
   * - Returns the session details and an execution summary, but does not return chat content. To query historical messages and events, call ListCopilotSessionMessages.
   * - The status of the session indicates whether it is archived. To determine whether an execution is in progress, read activeTurn.
   * - lastTurn indicates the most recent execution turn, which may not have ended. During execution, activeTurn and lastTurn can point to the same execution turn.
   * - An error is returned if the session does not exist, has been deleted, or does not belong to the current user.
   * 
   * @param request - GetCopilotSessionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetCopilotSessionResponse
   */
  async getCopilotSessionWithOptions(sessionId: string, request: $_model.GetCopilotSessionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetCopilotSessionResponse> {
    request.validate();
    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
    });
    let params = new $OpenApiUtil.Params({
      action: "GetCopilotSession",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/sessions/${$dara.URL.percentEncode(sessionId)}`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetCopilotSessionResponse>(await this.callApi(params, req, runtime), new $_model.GetCopilotSessionResponse({}));
  }

  /**
   * Retrieves the Copilot session and execution status.
   * 
   * @remarks
   * - You can query only the sessions of the current user, one session at a time.
   * - Returns the session details and an execution summary, but does not return chat content. To query historical messages and events, call ListCopilotSessionMessages.
   * - The status of the session indicates whether it is archived. To determine whether an execution is in progress, read activeTurn.
   * - lastTurn indicates the most recent execution turn, which may not have ended. During execution, activeTurn and lastTurn can point to the same execution turn.
   * - An error is returned if the session does not exist, has been deleted, or does not belong to the current user.
   * 
   * @param request - GetCopilotSessionRequest
   * @returns GetCopilotSessionResponse
   */
  async getCopilotSession(sessionId: string, request: $_model.GetCopilotSessionRequest): Promise<$_model.GetCopilotSessionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getCopilotSessionWithOptions(sessionId, request, headers, runtime);
  }

  /**
   * Queries hotfixes and compatible packages for CVEs.
   * 
   * @remarks
   * Queries published hotfixes in batches by CVE ID. You can filter the results by full kernel version number.
   * 
   * @param request - GetCveHotfixRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetCveHotfixResponse
   */
  async getCveHotfixWithOptions(request: $_model.GetCveHotfixRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetCveHotfixResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cveIds)) {
      body["cveIds"] = request.cveIds;
    }

    if (!$dara.isNull(request.kernelVersions)) {
      body["kernelVersions"] = request.kernelVersions;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetCveHotfix",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/hotfixManager/hotfixes/cve`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetCveHotfixResponse>(await this.callApi(params, req, runtime), new $_model.GetCveHotfixResponse({}));
  }

  /**
   * Queries hotfixes and compatible packages for CVEs.
   * 
   * @remarks
   * Queries published hotfixes in batches by CVE ID. You can filter the results by full kernel version number.
   * 
   * @param request - GetCveHotfixRequest
   * @returns GetCveHotfixResponse
   */
  async getCveHotfix(request: $_model.GetCveHotfixRequest): Promise<$_model.GetCveHotfixResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getCveHotfixWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. When you call this operation, the diagnosis may still be running. You can check the `data.status` field in the response to determine the status. When `data.status == Success`, the diagnosis is complete and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetDiagnosisResultRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetDiagnosisResultResponse
   */
  async getDiagnosisResultWithOptions(request: $_model.GetDiagnosisResultRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetDiagnosisResultResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["task_id"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetDiagnosisResult",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/diagnosis/get_diagnosis_results`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetDiagnosisResultResponse>(await this.callApi(params, req, runtime), new $_model.GetDiagnosisResultResponse({}));
  }

  /**
   * Retrieves diagnostic results.
   * 
   * @remarks
   * The diagnostic process is asynchronous. When you call this operation, the diagnosis may still be running. You can check the `data.status` field in the response to determine the status. When `data.status == Success`, the diagnosis is complete and you can read the diagnostic results from `data.result`.
   * 
   * @param request - GetDiagnosisResultRequest
   * @returns GetDiagnosisResultResponse
   */
  async getDiagnosisResult(request: $_model.GetDiagnosisResultRequest): Promise<$_model.GetDiagnosisResultResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getDiagnosisResultWithOptions(request, headers, runtime);
  }

  /**
   * 获取诊断子操作
   * 
   * @param request - GetDiagnosisSubOperationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetDiagnosisSubOperationResponse
   */
  async getDiagnosisSubOperationWithOptions(request: $_model.GetDiagnosisSubOperationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetDiagnosisSubOperationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.operationId)) {
      query["operationId"] = request.operationId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetDiagnosisSubOperation",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/diagnosis-fastapi/suboperation/getDiagnosisSubOperation`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetDiagnosisSubOperationResponse>(await this.callApi(params, req, runtime), new $_model.GetDiagnosisSubOperationResponse({}));
  }

  /**
   * 获取诊断子操作
   * 
   * @param request - GetDiagnosisSubOperationRequest
   * @returns GetDiagnosisSubOperationResponse
   */
  async getDiagnosisSubOperation(request: $_model.GetDiagnosisSubOperationRequest): Promise<$_model.GetDiagnosisSubOperationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getDiagnosisSubOperationWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of parameters for a GPU cluster.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - GetGpuClusterArgsOptionsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetGpuClusterArgsOptionsResponse
   */
  async getGpuClusterArgsOptionsWithOptions(request: $_model.GetGpuClusterArgsOptionsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetGpuClusterArgsOptionsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.filterType)) {
      query["filterType"] = request.filterType;
    }

    if (!$dara.isNull(request.filterValues)) {
      query["filterValues"] = request.filterValues;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetGpuClusterArgsOptions",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiTopology/topology/listClusterTopologyOptions`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetGpuClusterArgsOptionsResponse>(await this.callApi(params, req, runtime), new $_model.GetGpuClusterArgsOptionsResponse({}));
  }

  /**
   * Retrieves the list of parameters for a GPU cluster.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - GetGpuClusterArgsOptionsRequest
   * @returns GetGpuClusterArgsOptionsResponse
   */
  async getGpuClusterArgsOptions(request: $_model.GetGpuClusterArgsOptionsRequest): Promise<$_model.GetGpuClusterArgsOptionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getGpuClusterArgsOptionsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of GPU cluster alerts.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on it without user intervention.
   * 
   * @param request - GetGpuClusterListAlarmRecordRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetGpuClusterListAlarmRecordResponse
   */
  async getGpuClusterListAlarmRecordWithOptions(request: $_model.GetGpuClusterListAlarmRecordRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetGpuClusterListAlarmRecordResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.alarmCluster)) {
      query["alarmCluster"] = request.alarmCluster;
    }

    if (!$dara.isNull(request.alarmExtInfo)) {
      query["alarmExtInfo"] = request.alarmExtInfo;
    }

    if (!$dara.isNull(request.alarmTask)) {
      query["alarmTask"] = request.alarmTask;
    }

    if (!$dara.isNull(request.alarmTime)) {
      query["alarmTime"] = request.alarmTime;
    }

    if (!$dara.isNull(request.alarmType)) {
      query["alarmType"] = request.alarmType;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetGpuClusterListAlarmRecord",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiTopology/topology/listAlarmRecord`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetGpuClusterListAlarmRecordResponse>(await this.callApi(params, req, runtime), new $_model.GetGpuClusterListAlarmRecordResponse({}));
  }

  /**
   * Retrieves the list of GPU cluster alerts.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on it without user intervention.
   * 
   * @param request - GetGpuClusterListAlarmRecordRequest
   * @returns GetGpuClusterListAlarmRecordResponse
   */
  async getGpuClusterListAlarmRecord(request: $_model.GetGpuClusterListAlarmRecordRequest): Promise<$_model.GetGpuClusterListAlarmRecordResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getGpuClusterListAlarmRecordWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the topology of a GPU cluster.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is initially managed, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - GetGpuClusterTopologyRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetGpuClusterTopologyResponse
   */
  async getGpuClusterTopologyWithOptions(request: $_model.GetGpuClusterTopologyRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetGpuClusterTopologyResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.channelId)) {
      query["channelId"] = request.channelId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["clusterId"] = request.clusterId;
    }

    if (!$dara.isNull(request.communicationId)) {
      query["communicationId"] = request.communicationId;
    }

    if (!$dara.isNull(request.instanceIdList)) {
      query["instanceIdList"] = request.instanceIdList;
    }

    if (!$dara.isNull(request.podList)) {
      query["podList"] = request.podList;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.taskIdList)) {
      query["taskIdList"] = request.taskIdList;
    }

    if (!$dara.isNull(request.topoType)) {
      query["topoType"] = request.topoType;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetGpuClusterTopology",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiTopology/topology/clusterTopology`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetGpuClusterTopologyResponse>(await this.callApi(params, req, runtime), new $_model.GetGpuClusterTopologyResponse({}));
  }

  /**
   * Retrieves the topology of a GPU cluster.
   * 
   * @remarks
   * After you install the component for the target ACK cluster:
   * 1. When the cluster is initially managed, the component is installed on all ECS instances currently in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - GetGpuClusterTopologyRequest
   * @returns GetGpuClusterTopologyResponse
   */
  async getGpuClusterTopology(request: $_model.GetGpuClusterTopologyRequest): Promise<$_model.GetGpuClusterTopologyResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getGpuClusterTopologyWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the health status distribution of nodes or pods over a specified time period.
   * 
   * @param request - GetHealthPercentageRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHealthPercentageResponse
   */
  async getHealthPercentageWithOptions(request: $_model.GetHealthPercentageRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHealthPercentageResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHealthPercentage",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/health_percentage`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHealthPercentageResponse>(await this.callApi(params, req, runtime), new $_model.GetHealthPercentageResponse({}));
  }

  /**
   * Retrieves the health status distribution of nodes or pods over a specified time period.
   * 
   * @param request - GetHealthPercentageRequest
   * @returns GetHealthPercentageResponse
   */
  async getHealthPercentage(request: $_model.GetHealthPercentageRequest): Promise<$_model.GetHealthPercentageResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHealthPercentageWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the number of nodes or node Pods in a cluster.
   * 
   * @param request - GetHostCountRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHostCountResponse
   */
  async getHostCountWithOptions(request: $_model.GetHostCountRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHostCountResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHostCount",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/host_count`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHostCountResponse>(await this.callApi(params, req, runtime), new $_model.GetHostCountResponse({}));
  }

  /**
   * Retrieves the number of nodes or node Pods in a cluster.
   * 
   * @param request - GetHostCountRequest
   * @returns GetHostCountResponse
   */
  async getHostCount(request: $_model.GetHostCountRequest): Promise<$_model.GetHostCountResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHostCountWithOptions(request, headers, runtime);
  }

  /**
   * 查询单个主机巡检任务状态
   * 
   * @remarks
   * 只返回任务元信息、阶段、进度与报告标识，不返回对象正文、签名 URL 与堆栈。
   * 
   * @param request - GetHostInspectionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHostInspectionResponse
   */
  async getHostInspectionWithOptions(request: $_model.GetHostInspectionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHostInspectionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionId)) {
      query["inspectionId"] = request.inspectionId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHostInspection",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/getHostInspection`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHostInspectionResponse>(await this.callApi(params, req, runtime), new $_model.GetHostInspectionResponse({}));
  }

  /**
   * 查询单个主机巡检任务状态
   * 
   * @remarks
   * 只返回任务元信息、阶段、进度与报告标识，不返回对象正文、签名 URL 与堆栈。
   * 
   * @param request - GetHostInspectionRequest
   * @returns GetHostInspectionResponse
   */
  async getHostInspection(request: $_model.GetHostInspectionRequest): Promise<$_model.GetHostInspectionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHostInspectionWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of a specific field under an instance.
   * 
   * @param request - GetHotSpotUniqListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotSpotUniqListResponse
   */
  async getHotSpotUniqListWithOptions(request: $_model.GetHotSpotUniqListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotSpotUniqListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.begEnd)) {
      body["beg_end"] = request.begEnd;
    }

    if (!$dara.isNull(request.begStart)) {
      body["beg_start"] = request.begStart;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pid)) {
      body["pid"] = request.pid;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    if (!$dara.isNull(request.uniq)) {
      body["uniq"] = request.uniq;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotSpotUniqList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/livetrace_proxy/hotspot_uniq_list`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotSpotUniqListResponse>(await this.callApi(params, req, runtime), new $_model.GetHotSpotUniqListResponse({}));
  }

  /**
   * Retrieves the list of a specific field under an instance.
   * 
   * @param request - GetHotSpotUniqListRequest
   * @returns GetHotSpotUniqListResponse
   */
  async getHotSpotUniqList(request: $_model.GetHotSpotUniqListRequest): Promise<$_model.GetHotSpotUniqListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotSpotUniqListWithOptions(request, headers, runtime);
  }

  /**
   * Queries the status of an asynchronous CVE hotfix task.
   * 
   * @remarks
   * The hotfix task process is asynchronous. When you call this operation, the task may still be running. You can check the `data.status` field in the response to determine the task status. If `data.status` is `Success`, the task succeeded, and you can obtain the task result from the `data.result` field.
   * 
   * @param request - GetHotfixTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotfixTaskResponse
   */
  async getHotfixTaskWithOptions(request: $_model.GetHotfixTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotfixTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotfixTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/hotfix_manager/task/get`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotfixTaskResponse>(await this.callApi(params, req, runtime), new $_model.GetHotfixTaskResponse({}));
  }

  /**
   * Queries the status of an asynchronous CVE hotfix task.
   * 
   * @remarks
   * The hotfix task process is asynchronous. When you call this operation, the task may still be running. You can check the `data.status` field in the response to determine the task status. If `data.status` is `Success`, the task succeeded, and you can obtain the task result from the `data.result` field.
   * 
   * @param request - GetHotfixTaskRequest
   * @returns GetHotfixTaskResponse
   */
  async getHotfixTask(request: $_model.GetHotfixTaskRequest): Promise<$_model.GetHotfixTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotfixTaskWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves hot spot analysis results.
   * 
   * @param request - GetHotspotAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotspotAnalysisResponse
   */
  async getHotspotAnalysisWithOptions(request: $_model.GetHotspotAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotspotAnalysisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.appType)) {
      body["appType"] = request.appType;
    }

    if (!$dara.isNull(request.begEnd)) {
      body["beg_end"] = request.begEnd;
    }

    if (!$dara.isNull(request.begStart)) {
      body["beg_start"] = request.begStart;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pid)) {
      body["pid"] = request.pid;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotspotAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_hotspot_analysis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotspotAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.GetHotspotAnalysisResponse({}));
  }

  /**
   * Retrieves hot spot analysis results.
   * 
   * @param request - GetHotspotAnalysisRequest
   * @returns GetHotspotAnalysisResponse
   */
  async getHotspotAnalysis(request: $_model.GetHotspotAnalysisRequest): Promise<$_model.GetHotspotAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotspotAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the results of a hot spot comparison trace.
   * 
   * @param request - GetHotspotCompareRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotspotCompareResponse
   */
  async getHotspotCompareWithOptions(request: $_model.GetHotspotCompareRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotspotCompareResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.beg1End)) {
      body["beg1_end"] = request.beg1End;
    }

    if (!$dara.isNull(request.beg1Start)) {
      body["beg1_start"] = request.beg1Start;
    }

    if (!$dara.isNull(request.beg2End)) {
      body["beg2_end"] = request.beg2End;
    }

    if (!$dara.isNull(request.beg2Start)) {
      body["beg2_start"] = request.beg2Start;
    }

    if (!$dara.isNull(request.hotType)) {
      body["hot_type"] = request.hotType;
    }

    if (!$dara.isNull(request.instance1)) {
      body["instance1"] = request.instance1;
    }

    if (!$dara.isNull(request.instance2)) {
      body["instance2"] = request.instance2;
    }

    if (!$dara.isNull(request.pid1)) {
      body["pid1"] = request.pid1;
    }

    if (!$dara.isNull(request.pid2)) {
      body["pid2"] = request.pid2;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotspotCompare",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_hotspot_compare`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotspotCompareResponse>(await this.callApi(params, req, runtime), new $_model.GetHotspotCompareResponse({}));
  }

  /**
   * Retrieves the results of a hot spot comparison trace.
   * 
   * @param request - GetHotspotCompareRequest
   * @returns GetHotspotCompareResponse
   */
  async getHotspotCompare(request: $_model.GetHotspotCompareRequest): Promise<$_model.GetHotspotCompareResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotspotCompareWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of hot spot instances.
   * 
   * @param request - GetHotspotInstanceListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotspotInstanceListResponse
   */
  async getHotspotInstanceListWithOptions(request: $_model.GetHotspotInstanceListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotspotInstanceListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.begEnd)) {
      body["beg_end"] = request.begEnd;
    }

    if (!$dara.isNull(request.begStart)) {
      body["beg_start"] = request.begStart;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotspotInstanceList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_hotspot_instance_list`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotspotInstanceListResponse>(await this.callApi(params, req, runtime), new $_model.GetHotspotInstanceListResponse({}));
  }

  /**
   * Retrieves the list of hot spot instances.
   * 
   * @param request - GetHotspotInstanceListRequest
   * @returns GetHotspotInstanceListResponse
   */
  async getHotspotInstanceList(request: $_model.GetHotspotInstanceListRequest): Promise<$_model.GetHotspotInstanceListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotspotInstanceListWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the PID list of a specified instance.
   * 
   * @param request - GetHotspotPidListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotspotPidListResponse
   */
  async getHotspotPidListWithOptions(request: $_model.GetHotspotPidListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotspotPidListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.begEnd)) {
      body["beg_end"] = request.begEnd;
    }

    if (!$dara.isNull(request.begStart)) {
      body["beg_start"] = request.begStart;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotspotPidList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_hotspot_pid_list`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotspotPidListResponse>(await this.callApi(params, req, runtime), new $_model.GetHotspotPidListResponse({}));
  }

  /**
   * Retrieves the PID list of a specified instance.
   * 
   * @param request - GetHotspotPidListRequest
   * @returns GetHotspotPidListResponse
   */
  async getHotspotPidList(request: $_model.GetHotspotPidListRequest): Promise<$_model.GetHotspotPidListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotspotPidListWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves hot spot tracking results.
   * 
   * @param request - GetHotspotTrackingRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetHotspotTrackingResponse
   */
  async getHotspotTrackingWithOptions(request: $_model.GetHotspotTrackingRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetHotspotTrackingResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.begEnd)) {
      body["beg_end"] = request.begEnd;
    }

    if (!$dara.isNull(request.begStart)) {
      body["beg_start"] = request.begStart;
    }

    if (!$dara.isNull(request.hotType)) {
      body["hot_type"] = request.hotType;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pid)) {
      body["pid"] = request.pid;
    }

    if (!$dara.isNull(request.table)) {
      body["table"] = request.table;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetHotspotTracking",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_hotspot_tracking`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetHotspotTrackingResponse>(await this.callApi(params, req, runtime), new $_model.GetHotspotTrackingResponse({}));
  }

  /**
   * Retrieves hot spot tracking results.
   * 
   * @param request - GetHotspotTrackingRequest
   * @returns GetHotspotTrackingResponse
   */
  async getHotspotTracking(request: $_model.GetHotspotTrackingRequest): Promise<$_model.GetHotspotTrackingResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getHotspotTrackingWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a SysOM inspection report.
   * 
   * @param request - GetInspectionReportRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetInspectionReportResponse
   */
  async getInspectionReportWithOptions(request: $_model.GetInspectionReportRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetInspectionReportResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.reportId)) {
      query["reportId"] = request.reportId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetInspectionReport",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/getInspectionReport`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetInspectionReportResponse>(await this.callApi(params, req, runtime), new $_model.GetInspectionReportResponse({}));
  }

  /**
   * Retrieves a SysOM inspection report.
   * 
   * @param request - GetInspectionReportRequest
   * @returns GetInspectionReportResponse
   */
  async getInspectionReport(request: $_model.GetInspectionReportRequest): Promise<$_model.GetInspectionReportResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getInspectionReportWithOptions(request, headers, runtime);
  }

  /**
   * 查询定时巡检计划详情
   * 
   * @param request - GetInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetInspectionScheduleResponse
   */
  async getInspectionScheduleWithOptions(request: $_model.GetInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetInspectionScheduleResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/getInspectionSchedule`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.GetInspectionScheduleResponse({}));
  }

  /**
   * 查询定时巡检计划详情
   * 
   * @param request - GetInspectionScheduleRequest
   * @returns GetInspectionScheduleResponse
   */
  async getInspectionSchedule(request: $_model.GetInspectionScheduleRequest): Promise<$_model.GetInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the real-time health score of a cluster or node.
   * 
   * @param request - GetInstantScoreRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetInstantScoreResponse
   */
  async getInstantScoreWithOptions(request: $_model.GetInstantScoreRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetInstantScoreResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetInstantScore",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/instant/score`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetInstantScoreResponse>(await this.callApi(params, req, runtime), new $_model.GetInstantScoreResponse({}));
  }

  /**
   * Retrieves the real-time health score of a cluster or node.
   * 
   * @param request - GetInstantScoreRequest
   * @returns GetInstantScoreResponse
   */
  async getInstantScore(request: $_model.GetInstantScoreRequest): Promise<$_model.GetInstantScoreResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getInstantScoreWithOptions(request, headers, runtime);
  }

  /**
   * Queries the list of GPU clusters.
   * 
   * @remarks
   * After you install components for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the system installs components on all Elastic Compute Service (ECS) instances in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The Operating System console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the Operating System console automatically installs components without user intervention.
   * 
   * @param request - GetListGpuClusterRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetListGpuClusterResponse
   */
  async getListGpuClusterWithOptions(request: $_model.GetListGpuClusterRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetListGpuClusterResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.timeRegion)) {
      query["timeRegion"] = request.timeRegion;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetListGpuCluster",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiTopology/topology/listCluster`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetListGpuClusterResponse>(await this.callApi(params, req, runtime), new $_model.GetListGpuClusterResponse({}));
  }

  /**
   * Queries the list of GPU clusters.
   * 
   * @remarks
   * After you install components for the target ACK cluster:
   * 1. When the cluster is managed for the first time, the system installs components on all Elastic Compute Service (ECS) instances in the cluster. If the cluster has more than 50 nodes, only 50 nodes are installed in the first batch.
   * 2. The Operating System console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the Operating System console automatically installs components without user intervention.
   * 
   * @param request - GetListGpuClusterRequest
   * @returns GetListGpuClusterResponse
   */
  async getListGpuCluster(request: $_model.GetListGpuClusterRequest): Promise<$_model.GetListGpuClusterResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getListGpuClusterWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a list of AI Infra analysis records.
   * 
   * @param request - GetListRecordRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetListRecordResponse
   */
  async getListRecordWithOptions(request: $_model.GetListRecordRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetListRecordResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.analysisId)) {
      query["analysisId"] = request.analysisId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.customId)) {
      query["customId"] = request.customId;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetListRecord",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/app_observ/aiAnalysis/list_record`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetListRecordResponse>(await this.callApi(params, req, runtime), new $_model.GetListRecordResponse({}));
  }

  /**
   * Retrieves a list of AI Infra analysis records.
   * 
   * @param request - GetListRecordRequest
   * @returns GetListRecordResponse
   */
  async getListRecord(request: $_model.GetListRecordRequest): Promise<$_model.GetListRecordResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getListRecordWithOptions(request, headers, runtime);
  }

  /**
   * 获取用户纳管的节点健康情况
   * 
   * @param request - GetNodeHealthCountRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetNodeHealthCountResponse
   */
  async getNodeHealthCountWithOptions(request: $_model.GetNodeHealthCountRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetNodeHealthCountResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetNodeHealthCount",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/clusterHealthApi/getNodeHealthCount`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetNodeHealthCountResponse>(await this.callApi(params, req, runtime), new $_model.GetNodeHealthCountResponse({}));
  }

  /**
   * 获取用户纳管的节点健康情况
   * 
   * @param request - GetNodeHealthCountRequest
   * @returns GetNodeHealthCountResponse
   */
  async getNodeHealthCount(request: $_model.GetNodeHealthCountRequest): Promise<$_model.GetNodeHealthCountResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getNodeHealthCountWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the proportion of anomaly issues for nodes in a cluster or pods in a node within a specified time range.
   * 
   * @param request - GetProblemPercentageRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetProblemPercentageResponse
   */
  async getProblemPercentageWithOptions(request: $_model.GetProblemPercentageRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetProblemPercentageResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetProblemPercentage",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/problem_percentage`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetProblemPercentageResponse>(await this.callApi(params, req, runtime), new $_model.GetProblemPercentageResponse({}));
  }

  /**
   * Retrieves the proportion of anomaly issues for nodes in a cluster or pods in a node within a specified time range.
   * 
   * @param request - GetProblemPercentageRequest
   * @returns GetProblemPercentageResponse
   */
  async getProblemPercentage(request: $_model.GetProblemPercentageRequest): Promise<$_model.GetProblemPercentageResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getProblemPercentageWithOptions(request, headers, runtime);
  }

  /**
   * 获取 Profiling Agent 完整分析报告
   * 
   * @param request - GetProfilingAgentReportRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetProfilingAgentReportResponse
   */
  async getProfilingAgentReportWithOptions(sessionId: string, request: $_model.GetProfilingAgentReportRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetProfilingAgentReportResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetProfilingAgentReport",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiprofilingAgent/report/${$dara.URL.percentEncode(sessionId)}`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetProfilingAgentReportResponse>(await this.callApi(params, req, runtime), new $_model.GetProfilingAgentReportResponse({}));
  }

  /**
   * 获取 Profiling Agent 完整分析报告
   * 
   * @param request - GetProfilingAgentReportRequest
   * @returns GetProfilingAgentReportResponse
   */
  async getProfilingAgentReport(sessionId: string, request: $_model.GetProfilingAgentReportRequest): Promise<$_model.GetProfilingAgentReportResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getProfilingAgentReportWithOptions(sessionId, request, headers, runtime);
  }

  /**
   * 轮询 Profiling Agent 分析状态
   * 
   * @param request - GetProfilingAgentStatusRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetProfilingAgentStatusResponse
   */
  async getProfilingAgentStatusWithOptions(sessionId: string, request: $_model.GetProfilingAgentStatusRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetProfilingAgentStatusResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetProfilingAgentStatus",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiprofilingAgent/status/${$dara.URL.percentEncode(sessionId)}`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetProfilingAgentStatusResponse>(await this.callApi(params, req, runtime), new $_model.GetProfilingAgentStatusResponse({}));
  }

  /**
   * 轮询 Profiling Agent 分析状态
   * 
   * @param request - GetProfilingAgentStatusRequest
   * @returns GetProfilingAgentStatusResponse
   */
  async getProfilingAgentStatus(sessionId: string, request: $_model.GetProfilingAgentStatusRequest): Promise<$_model.GetProfilingAgentStatusResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getProfilingAgentStatusWithOptions(sessionId, request, headers, runtime);
  }

  /**
   * Retrieves the health score trend.
   * 
   * @param request - GetRangeScoreRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetRangeScoreResponse
   */
  async getRangeScoreWithOptions(request: $_model.GetRangeScoreRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetRangeScoreResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetRangeScore",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/score`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetRangeScoreResponse>(await this.callApi(params, req, runtime), new $_model.GetRangeScoreResponse({}));
  }

  /**
   * Retrieves the health score trend.
   * 
   * @param request - GetRangeScoreRequest
   * @returns GetRangeScoreResponse
   */
  async getRangeScore(request: $_model.GetRangeScoreRequest): Promise<$_model.GetRangeScoreResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getRangeScoreWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the real-time resource usage of a cluster or node.
   * 
   * @param request - GetResourcesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetResourcesResponse
   */
  async getResourcesWithOptions(request: $_model.GetResourcesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetResourcesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.type)) {
      query["type"] = request.type;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetResources",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/instant/resource`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetResourcesResponse>(await this.callApi(params, req, runtime), new $_model.GetResourcesResponse({}));
  }

  /**
   * Retrieves the real-time resource usage of a cluster or node.
   * 
   * @param request - GetResourcesRequest
   * @returns GetResourcesResponse
   */
  async getResources(request: $_model.GetResourcesRequest): Promise<$_model.GetResourcesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getResourcesWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the feature module configuration.
   * 
   * @remarks
   * This operation retrieves the service configuration status.
   * 
   * @param tmpReq - GetServiceFuncStatusRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetServiceFuncStatusResponse
   */
  async getServiceFuncStatusWithOptions(tmpReq: $_model.GetServiceFuncStatusRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetServiceFuncStatusResponse> {
    tmpReq.validate();
    let request = new $_model.GetServiceFuncStatusShrinkRequest({ });
    OpenApiUtil.convert(tmpReq, request);
    if (!$dara.isNull(tmpReq.params)) {
      request.paramsShrink = OpenApiUtil.arrayToStringWithSpecifiedStyle(tmpReq.params, "params", "json");
    }

    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.channel)) {
      query["channel"] = request.channel;
    }

    if (!$dara.isNull(request.paramsShrink)) {
      query["params"] = request.paramsShrink;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["service_name"] = request.serviceName;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetServiceFuncStatus",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/func-switch/get-service-func-status`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetServiceFuncStatusResponse>(await this.callApi(params, req, runtime), new $_model.GetServiceFuncStatusResponse({}));
  }

  /**
   * Retrieves the feature module configuration.
   * 
   * @remarks
   * This operation retrieves the service configuration status.
   * 
   * @param request - GetServiceFuncStatusRequest
   * @returns GetServiceFuncStatusResponse
   */
  async getServiceFuncStatus(request: $_model.GetServiceFuncStatusRequest): Promise<$_model.GetServiceFuncStatusResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getServiceFuncStatusWithOptions(request, headers, runtime);
  }

  /**
   * 获取诊断历史记录列表
   * 
   * @param request - GetServiceNameRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetServiceNameResponse
   */
  async getServiceNameWithOptions(request: $_model.GetServiceNameRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetServiceNameResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.workspace)) {
      query["workspace"] = request.workspace;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetServiceName",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getServiceName`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetServiceNameResponse>(await this.callApi(params, req, runtime), new $_model.GetServiceNameResponse({}));
  }

  /**
   * 获取诊断历史记录列表
   * 
   * @param request - GetServiceNameRequest
   * @returns GetServiceNameResponse
   */
  async getServiceName(request: $_model.GetServiceNameRequest): Promise<$_model.GetServiceNameResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getServiceNameWithOptions(request, headers, runtime);
  }

  /**
   * 获取用户不同等级异常事件统计
   * 
   * @param request - GetUserAbnormalEventsCountRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetUserAbnormalEventsCountResponse
   */
  async getUserAbnormalEventsCountWithOptions(request: $_model.GetUserAbnormalEventsCountRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetUserAbnormalEventsCountResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.level)) {
      query["level"] = request.level;
    }

    if (!$dara.isNull(request.namespace)) {
      query["namespace"] = request.namespace;
    }

    if (!$dara.isNull(request.pod)) {
      query["pod"] = request.pod;
    }

    if (!$dara.isNull(request.showPod)) {
      query["showPod"] = request.showPod;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetUserAbnormalEventsCount",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/clusterHealthApi/getUserAbnormalyEventsCount`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetUserAbnormalEventsCountResponse>(await this.callApi(params, req, runtime), new $_model.GetUserAbnormalEventsCountResponse({}));
  }

  /**
   * 获取用户不同等级异常事件统计
   * 
   * @param request - GetUserAbnormalEventsCountRequest
   * @returns GetUserAbnormalEventsCountResponse
   */
  async getUserAbnormalEventsCount(request: $_model.GetUserAbnormalEventsCountRequest): Promise<$_model.GetUserAbnormalEventsCountResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getUserAbnormalEventsCountWithOptions(request, headers, runtime);
  }

  /**
   * 获取用户异常分布情况
   * 
   * @param request - GetUserAbnormalyDistributionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetUserAbnormalyDistributionResponse
   */
  async getUserAbnormalyDistributionWithOptions(request: $_model.GetUserAbnormalyDistributionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetUserAbnormalyDistributionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetUserAbnormalyDistribution",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/clusterHealthApi/getUserAbnormalyDistribution`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetUserAbnormalyDistributionResponse>(await this.callApi(params, req, runtime), new $_model.GetUserAbnormalyDistributionResponse({}));
  }

  /**
   * 获取用户异常分布情况
   * 
   * @param request - GetUserAbnormalyDistributionRequest
   * @returns GetUserAbnormalyDistributionResponse
   */
  async getUserAbnormalyDistribution(request: $_model.GetUserAbnormalyDistributionRequest): Promise<$_model.GetUserAbnormalyDistributionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getUserAbnormalyDistributionWithOptions(request, headers, runtime);
  }

  /**
   * 获取实例标识列表
   * 
   * @param request - GetVllmIpv4Request
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetVllmIpv4Response
   */
  async getVllmIpv4WithOptions(request: $_model.GetVllmIpv4Request, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetVllmIpv4Response> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["serviceName"] = request.serviceName;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.workspace)) {
      query["workspace"] = request.workspace;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetVllmIpv4",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getVllmIpv4`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetVllmIpv4Response>(await this.callApi(params, req, runtime), new $_model.GetVllmIpv4Response({}));
  }

  /**
   * 获取实例标识列表
   * 
   * @param request - GetVllmIpv4Request
   * @returns GetVllmIpv4Response
   */
  async getVllmIpv4(request: $_model.GetVllmIpv4Request): Promise<$_model.GetVllmIpv4Response> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getVllmIpv4WithOptions(request, headers, runtime);
  }

  /**
   * 获取模型名称列表
   * 
   * @param request - GetVllmModelNameRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetVllmModelNameResponse
   */
  async getVllmModelNameWithOptions(request: $_model.GetVllmModelNameRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetVllmModelNameResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.endTime)) {
      query["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["serviceName"] = request.serviceName;
    }

    if (!$dara.isNull(request.startTime)) {
      query["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.workspace)) {
      query["workspace"] = request.workspace;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetVllmModelName",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getVllmModelName`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetVllmModelNameResponse>(await this.callApi(params, req, runtime), new $_model.GetVllmModelNameResponse({}));
  }

  /**
   * 获取模型名称列表
   * 
   * @param request - GetVllmModelNameRequest
   * @returns GetVllmModelNameResponse
   */
  async getVllmModelName(request: $_model.GetVllmModelNameRequest): Promise<$_model.GetVllmModelNameResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getVllmModelNameWithOptions(request, headers, runtime);
  }

  /**
   * AI Infra获取分析记录列表
   * 
   * @param request - GetVllmTracingResultRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetVllmTracingResultResponse
   */
  async getVllmTracingResultWithOptions(request: $_model.GetVllmTracingResultRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetVllmTracingResultResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetVllmTracingResult",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getVllmTracingResult`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetVllmTracingResultResponse>(await this.callApi(params, req, runtime), new $_model.GetVllmTracingResultResponse({}));
  }

  /**
   * AI Infra获取分析记录列表
   * 
   * @param request - GetVllmTracingResultRequest
   * @returns GetVllmTracingResultResponse
   */
  async getVllmTracingResult(request: $_model.GetVllmTracingResultRequest): Promise<$_model.GetVllmTracingResultResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getVllmTracingResultWithOptions(request, headers, runtime);
  }

  /**
   * Queries the execution status and diagnostic result of a diagnostic task by task ID.
   * 
   * @param request - GetVmcoreDiagnosisTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetVmcoreDiagnosisTaskResponse
   */
  async getVmcoreDiagnosisTaskWithOptions(request: $_model.GetVmcoreDiagnosisTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetVmcoreDiagnosisTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetVmcoreDiagnosisTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/crashAgent/diagnosis/queryTask`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetVmcoreDiagnosisTaskResponse>(await this.callApi(params, req, runtime), new $_model.GetVmcoreDiagnosisTaskResponse({}));
  }

  /**
   * Queries the execution status and diagnostic result of a diagnostic task by task ID.
   * 
   * @param request - GetVmcoreDiagnosisTaskRequest
   * @returns GetVmcoreDiagnosisTaskResponse
   */
  async getVmcoreDiagnosisTask(request: $_model.GetVmcoreDiagnosisTaskRequest): Promise<$_model.GetVmcoreDiagnosisTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getVmcoreDiagnosisTaskWithOptions(request, headers, runtime);
  }

  /**
   * 获取工作空间列表
   * 
   * @param request - GetWorkspaceRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns GetWorkspaceResponse
   */
  async getWorkspaceWithOptions(request: $_model.GetWorkspaceRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.GetWorkspaceResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "GetWorkspace",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/getWorkspace`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.GetWorkspaceResponse>(await this.callApi(params, req, runtime), new $_model.GetWorkspaceResponse({}));
  }

  /**
   * 获取工作空间列表
   * 
   * @param request - GetWorkspaceRequest
   * @returns GetWorkspaceResponse
   */
  async getWorkspace(request: $_model.GetWorkspaceRequest): Promise<$_model.GetWorkspaceResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.getWorkspaceWithOptions(request, headers, runtime);
  }

  /**
   * Initializes SysOM to ensure that the service-linked role exists.
   * 
   * @remarks
   * Some SysOM API operations require role assumption based on the `AliyunServiceRoleForSysom` service-linked role. Before using SysOM features, invoke this operation to perform initialization and ensure that the service-linked role has been created.
   * - `check_only`: If this parameter is set to True, only a check is performed to determine whether the service-linked role exists. The service-linked role is not created. If this parameter is set to False or left empty, automatic creation of the service-linked role is performed if it does not exist.
   * > 
   * > Note: When you call this operation to initialize the role, you agree to the user agreement of the operating system console by default. For more information, see [Operating system console overview](https://www.alibabacloud.com/help/en/alinux/product-overview/os-console-overview) and [Alibaba Cloud Service Trial Terms](https://terms.aliyun.com/legal-agreement/terms/suit_bu1_ali_cloud/suit_bu1_ali_cloud202001091714_51956.html).
   * 
   * @param request - InitialSysomRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InitialSysomResponse
   */
  async initialSysomWithOptions(request: $_model.InitialSysomRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InitialSysomResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.checkOnly)) {
      body["check_only"] = request.checkOnly;
    }

    if (!$dara.isNull(request.source)) {
      body["source"] = request.source;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InitialSysom",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/initial`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InitialSysomResponse>(await this.callApi(params, req, runtime), new $_model.InitialSysomResponse({}));
  }

  /**
   * Initializes SysOM to ensure that the service-linked role exists.
   * 
   * @remarks
   * Some SysOM API operations require role assumption based on the `AliyunServiceRoleForSysom` service-linked role. Before using SysOM features, invoke this operation to perform initialization and ensure that the service-linked role has been created.
   * - `check_only`: If this parameter is set to True, only a check is performed to determine whether the service-linked role exists. The service-linked role is not created. If this parameter is set to False or left empty, automatic creation of the service-linked role is performed if it does not exist.
   * > 
   * > Note: When you call this operation to initialize the role, you agree to the user agreement of the operating system console by default. For more information, see [Operating system console overview](https://www.alibabacloud.com/help/en/alinux/product-overview/os-console-overview) and [Alibaba Cloud Service Trial Terms](https://terms.aliyun.com/legal-agreement/terms/suit_bu1_ali_cloud/suit_bu1_ali_cloud202001091714_51956.html).
   * 
   * @param request - InitialSysomRequest
   * @returns InitialSysomResponse
   */
  async initialSysom(request: $_model.InitialSysomRequest): Promise<$_model.InitialSysomResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.initialSysomWithOptions(request, headers, runtime);
  }

  /**
   * Installs an agent on a specified instance.
   * 
   * @remarks
   * Calling this operation to install an agent is asynchronous. After you call this operation, a task_id is returned. You can use this ID to call the GetAgentTask operation to query the task execution status.
   * 
   * @param request - InstallAgentRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InstallAgentResponse
   */
  async installAgentWithOptions(request: $_model.InstallAgentRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InstallAgentResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.installType)) {
      body["install_type"] = request.installType;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InstallAgent",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/install_agent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InstallAgentResponse>(await this.callApi(params, req, runtime), new $_model.InstallAgentResponse({}));
  }

  /**
   * Installs an agent on a specified instance.
   * 
   * @remarks
   * Calling this operation to install an agent is asynchronous. After you call this operation, a task_id is returned. You can use this ID to call the GetAgentTask operation to query the task execution status.
   * 
   * @param request - InstallAgentRequest
   * @returns InstallAgentResponse
   */
  async installAgent(request: $_model.InstallAgentRequest): Promise<$_model.InstallAgentResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.installAgentWithOptions(request, headers, runtime);
  }

  /**
   * Installs a component on an ACK cluster.
   * 
   * @remarks
   * After you install a component on the target ACK cluster:
   * 1. First, when the cluster is managed for the first time, the component is installed on all existing ECS instances in the cluster. If the cluster contains more than 50 nodes, only 50 instances are included in the first batch.
   * 2. Then, the operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - InstallAgentForClusterRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InstallAgentForClusterResponse
   */
  async installAgentForClusterWithOptions(request: $_model.InstallAgentForClusterRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InstallAgentForClusterResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.clusterId)) {
      body["cluster_id"] = request.clusterId;
    }

    if (!$dara.isNull(request.configId)) {
      body["config_id"] = request.configId;
    }

    if (!$dara.isNull(request.grayscaleConfig)) {
      body["grayscale_config"] = request.grayscaleConfig;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InstallAgentForCluster",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/install_agent_by_cluster`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InstallAgentForClusterResponse>(await this.callApi(params, req, runtime), new $_model.InstallAgentForClusterResponse({}));
  }

  /**
   * Installs a component on an ACK cluster.
   * 
   * @remarks
   * After you install a component on the target ACK cluster:
   * 1. First, when the cluster is managed for the first time, the component is installed on all existing ECS instances in the cluster. If the cluster contains more than 50 nodes, only 50 instances are included in the first batch.
   * 2. Then, the operating system console periodically checks the scaling status of the managed cluster. When a new ECS instance is added to the cluster, the operating system console automatically installs the component on the instance without user intervention.
   * 
   * @param request - InstallAgentForClusterRequest
   * @returns InstallAgentForClusterResponse
   */
  async installAgentForCluster(request: $_model.InstallAgentForClusterRequest): Promise<$_model.InstallAgentForClusterResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.installAgentForClusterWithOptions(request, headers, runtime);
  }

  /**
   * Installs an agent on a specified instance.
   * 
   * @remarks
   * Installs an agent asynchronously. After you call this operation, a task ID is returned. You can use the task ID to call the GetAgentTask operation to query the execution status of the task.
   * 
   * @param request - InstallAgentWithTypeRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InstallAgentWithTypeResponse
   */
  async installAgentWithTypeWithOptions(request: $_model.InstallAgentWithTypeRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InstallAgentWithTypeResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.tag)) {
      body["Tag"] = request.tag;
    }

    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agentVersion"] = request.agentVersion;
    }

    if (!$dara.isNull(request.configId)) {
      body["configId"] = request.configId;
    }

    if (!$dara.isNull(request.instanceType)) {
      body["instanceType"] = request.instanceType;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InstallAgentWithType",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/installAgent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InstallAgentWithTypeResponse>(await this.callApi(params, req, runtime), new $_model.InstallAgentWithTypeResponse({}));
  }

  /**
   * Installs an agent on a specified instance.
   * 
   * @remarks
   * Installs an agent asynchronously. After you call this operation, a task ID is returned. You can use the task ID to call the GetAgentTask operation to query the execution status of the task.
   * 
   * @param request - InstallAgentWithTypeRequest
   * @returns InstallAgentWithTypeResponse
   */
  async installAgentWithType(request: $_model.InstallAgentWithTypeRequest): Promise<$_model.InstallAgentWithTypeResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.installAgentWithTypeWithOptions(request, headers, runtime);
  }

  /**
   * Installs CVE hotfixes asynchronously on the specified instances.
   * 
   * @remarks
   * Calling this operation to install hotfixes is asynchronous. After the operation is called, a task_id is returned. You can use this ID to call the GetHotfixTask operation to query the execution status of the task.
   * 
   * @param request - InstallHotfixRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InstallHotfixResponse
   */
  async installHotfixWithOptions(request: $_model.InstallHotfixRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InstallHotfixResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cveId)) {
      body["cveId"] = request.cveId;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InstallHotfix",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/hotfix_manager/hotfix/install`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InstallHotfixResponse>(await this.callApi(params, req, runtime), new $_model.InstallHotfixResponse({}));
  }

  /**
   * Installs CVE hotfixes asynchronously on the specified instances.
   * 
   * @remarks
   * Calling this operation to install hotfixes is asynchronous. After the operation is called, a task_id is returned. You can use this ID to call the GetHotfixTask operation to query the execution status of the task.
   * 
   * @param request - InstallHotfixRequest
   * @returns InstallHotfixResponse
   */
  async installHotfix(request: $_model.InstallHotfixRequest): Promise<$_model.InstallHotfixResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.installHotfixWithOptions(request, headers, runtime);
  }

  /**
   * 用于执行指定的诊断或系统操作，并返回结果。
   * 
   * @remarks
   * ## 请求说明
   * - 该 API 用于触发 SysOM 平台上的特定技能（如内存分析、IO 性能检查等），并接收执行结果。
   * - `actionId` 是必填项，它定义了要执行的具体动作。
   * - `target` 字段在进行深度诊断时是必需的，指定了目标实例的信息。
   * - `params` 可选，包含执行特定 action 所需的参数。
   * - 响应体采用 sysom_agent 信封 v4.0 格式封装，包含了详细的执行结果和建议。
   * - 注意请求头中 `Content-Type` 必须设置为 `application/json`。
   * 
   * @param request - InvokeAgentCliRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InvokeAgentCliResponse
   */
  async invokeAgentCliWithOptions(request: $_model.InvokeAgentCliRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InvokeAgentCliResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.actionId)) {
      body["actionId"] = request.actionId;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.target)) {
      body["target"] = request.target;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InvokeAgentCli",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/skills/run`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InvokeAgentCliResponse>(await this.callApi(params, req, runtime), new $_model.InvokeAgentCliResponse({}));
  }

  /**
   * 用于执行指定的诊断或系统操作，并返回结果。
   * 
   * @remarks
   * ## 请求说明
   * - 该 API 用于触发 SysOM 平台上的特定技能（如内存分析、IO 性能检查等），并接收执行结果。
   * - `actionId` 是必填项，它定义了要执行的具体动作。
   * - `target` 字段在进行深度诊断时是必需的，指定了目标实例的信息。
   * - `params` 可选，包含执行特定 action 所需的参数。
   * - 响应体采用 sysom_agent 信封 v4.0 格式封装，包含了详细的执行结果和建议。
   * - 注意请求头中 `Content-Type` 必须设置为 `application/json`。
   * 
   * @param request - InvokeAgentCliRequest
   * @returns InvokeAgentCliResponse
   */
  async invokeAgentCli(request: $_model.InvokeAgentCliRequest): Promise<$_model.InvokeAgentCliResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.invokeAgentCliWithOptions(request, headers, runtime);
  }

  /**
   * Initiates an anomaly diagnosis.
   * 
   * @param request - InvokeAnomalyDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InvokeAnomalyDiagnosisResponse
   */
  async invokeAnomalyDiagnosisWithOptions(request: $_model.InvokeAnomalyDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InvokeAnomalyDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.uuid)) {
      query["uuid"] = request.uuid;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "InvokeAnomalyDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/diagnosis/invoke_anomaly_diagnose`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InvokeAnomalyDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.InvokeAnomalyDiagnosisResponse({}));
  }

  /**
   * Initiates an anomaly diagnosis.
   * 
   * @param request - InvokeAnomalyDiagnosisRequest
   * @returns InvokeAnomalyDiagnosisResponse
   */
  async invokeAnomalyDiagnosis(request: $_model.InvokeAnomalyDiagnosisRequest): Promise<$_model.InvokeAnomalyDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.invokeAnomalyDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * Initiates a diagnostic task.
   * 
   * @remarks
   * The following requirements must be met to diagnose a target ECS instance:
   * - The target ECS instance status must be Running.
   * - Cloud Assistant must be installed on the target ECS instance. If it is not installed, refer to [Install the Cloud Assistant Agent](https://www.alibabacloud.com/help/en/ecs/user-guide/install-the-cloud-assistant-agent) for installation.
   * - You must invoke the AuthDiagnosis operation to authorize SysOM to diagnose the target ECS instance. If authorization is not granted, this operation directly fails.
   * - This operation depends on the SysOM service-linked role (AliyunServiceRoleForSysom) being created. This operation does not automatically create the service-linked role. If the service-linked role does not exist, first invoke AuthDiagnosis to associate the authorization. That operation creates the aforementioned service-linked role.
   * 
   * @param request - InvokeDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InvokeDiagnosisResponse
   */
  async invokeDiagnosisWithOptions(request: $_model.InvokeDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InvokeDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.channel)) {
      body["channel"] = request.channel;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.serviceName)) {
      body["service_name"] = request.serviceName;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InvokeDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/diagnosis/invoke_diagnosis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InvokeDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.InvokeDiagnosisResponse({}));
  }

  /**
   * Initiates a diagnostic task.
   * 
   * @remarks
   * The following requirements must be met to diagnose a target ECS instance:
   * - The target ECS instance status must be Running.
   * - Cloud Assistant must be installed on the target ECS instance. If it is not installed, refer to [Install the Cloud Assistant Agent](https://www.alibabacloud.com/help/en/ecs/user-guide/install-the-cloud-assistant-agent) for installation.
   * - You must invoke the AuthDiagnosis operation to authorize SysOM to diagnose the target ECS instance. If authorization is not granted, this operation directly fails.
   * - This operation depends on the SysOM service-linked role (AliyunServiceRoleForSysom) being created. This operation does not automatically create the service-linked role. If the service-linked role does not exist, first invoke AuthDiagnosis to associate the authorization. That operation creates the aforementioned service-linked role.
   * 
   * @param request - InvokeDiagnosisRequest
   * @returns InvokeDiagnosisResponse
   */
  async invokeDiagnosis(request: $_model.InvokeDiagnosisRequest): Promise<$_model.InvokeDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.invokeDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * 发起离线诊断
   * 
   * @param request - InvokeOfflineDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns InvokeOfflineDiagnosisResponse
   */
  async invokeOfflineDiagnosisWithOptions(request: $_model.InvokeOfflineDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.InvokeOfflineDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.serviceName)) {
      body["serviceName"] = request.serviceName;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "InvokeOfflineDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/offlineDiagnosis/invoke`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.InvokeOfflineDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.InvokeOfflineDiagnosisResponse({}));
  }

  /**
   * 发起离线诊断
   * 
   * @param request - InvokeOfflineDiagnosisRequest
   * @returns InvokeOfflineDiagnosisResponse
   */
  async invokeOfflineDiagnosis(request: $_model.InvokeOfflineDiagnosisRequest): Promise<$_model.InvokeOfflineDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.invokeOfflineDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves anomaly event information for a cluster, node, or pod within a specified time range.
   * 
   * @param request - ListAbnormalyEventsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAbnormalyEventsResponse
   */
  async listAbnormalyEventsWithOptions(request: $_model.ListAbnormalyEventsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAbnormalyEventsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.event)) {
      query["event"] = request.event;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.level)) {
      query["level"] = request.level;
    }

    if (!$dara.isNull(request.namespace)) {
      query["namespace"] = request.namespace;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pod)) {
      query["pod"] = request.pod;
    }

    if (!$dara.isNull(request.showPod)) {
      query["showPod"] = request.showPod;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAbnormalyEvents",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/abnormaly_events`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAbnormalyEventsResponse>(await this.callApi(params, req, runtime), new $_model.ListAbnormalyEventsResponse({}));
  }

  /**
   * Retrieves anomaly event information for a cluster, node, or pod within a specified time range.
   * 
   * @param request - ListAbnormalyEventsRequest
   * @returns ListAbnormalyEventsResponse
   */
  async listAbnormalyEvents(request: $_model.ListAbnormalyEventsRequest): Promise<$_model.ListAbnormalyEventsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAbnormalyEventsWithOptions(request, headers, runtime);
  }

  /**
   * Lists the installation records of an Agent.
   * 
   * @param request - ListAgentInstallRecordsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAgentInstallRecordsResponse
   */
  async listAgentInstallRecordsWithOptions(request: $_model.ListAgentInstallRecordsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAgentInstallRecordsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.instanceId)) {
      query["instance_id"] = request.instanceId;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["plugin_id"] = request.pluginId;
    }

    if (!$dara.isNull(request.pluginVersion)) {
      query["plugin_version"] = request.pluginVersion;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAgentInstallRecords",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/list_agent_install_list`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAgentInstallRecordsResponse>(await this.callApi(params, req, runtime), new $_model.ListAgentInstallRecordsResponse({}));
  }

  /**
   * Lists the installation records of an Agent.
   * 
   * @param request - ListAgentInstallRecordsRequest
   * @returns ListAgentInstallRecordsResponse
   */
  async listAgentInstallRecords(request: $_model.ListAgentInstallRecordsRequest): Promise<$_model.ListAgentInstallRecordsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAgentInstallRecordsWithOptions(request, headers, runtime);
  }

  /**
   * 分页查询 Agent 优化分析任务列表
   * 
   * @param request - ListAgentOptimizationTasksRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAgentOptimizationTasksResponse
   */
  async listAgentOptimizationTasksWithOptions(request: $_model.ListAgentOptimizationTasksRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAgentOptimizationTasksResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.regionId)) {
      query["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAgentOptimizationTasks",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/listAgentOptimizationTasks`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAgentOptimizationTasksResponse>(await this.callApi(params, req, runtime), new $_model.ListAgentOptimizationTasksResponse({}));
  }

  /**
   * 分页查询 Agent 优化分析任务列表
   * 
   * @param request - ListAgentOptimizationTasksRequest
   * @returns ListAgentOptimizationTasksResponse
   */
  async listAgentOptimizationTasks(request: $_model.ListAgentOptimizationTasksRequest): Promise<$_model.ListAgentOptimizationTasksResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAgentOptimizationTasksWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a list of Agents.
   * 
   * @param request - ListAgentsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAgentsResponse
   */
  async listAgentsWithOptions(request: $_model.ListAgentsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAgentsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.type)) {
      query["type"] = request.type;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAgents",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/list_agents`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAgentsResponse>(await this.callApi(params, req, runtime), new $_model.ListAgentsResponse({}));
  }

  /**
   * Retrieves a list of Agents.
   * 
   * @param request - ListAgentsRequest
   * @returns ListAgentsResponse
   */
  async listAgents(request: $_model.ListAgentsRequest): Promise<$_model.ListAgentsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAgentsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of diagnostic tasks.
   * 
   * @remarks
   * This operation retrieves the list of regions where the current user has machines managed by SysOM. If a user has ECS instances in a region but they are not managed by SysOM, the region will not appear in the API response.
   * 
   * @param request - ListAifgJobsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAifgJobsResponse
   */
  async listAifgJobsWithOptions(request: $_model.ListAifgJobsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAifgJobsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["serviceName"] = request.serviceName;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAifgJobs",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/listAifgJobs`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAifgJobsResponse>(await this.callApi(params, req, runtime), new $_model.ListAifgJobsResponse({}));
  }

  /**
   * Retrieves the list of diagnostic tasks.
   * 
   * @remarks
   * This operation retrieves the list of regions where the current user has machines managed by SysOM. If a user has ECS instances in a region but they are not managed by SysOM, the region will not appear in the API response.
   * 
   * @param request - ListAifgJobsRequest
   * @returns ListAifgJobsResponse
   */
  async listAifgJobs(request: $_model.ListAifgJobsRequest): Promise<$_model.ListAifgJobsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAifgJobsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a list of alert contacts.
   * 
   * @param request - ListAlertDestinationsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAlertDestinationsResponse
   */
  async listAlertDestinationsWithOptions(request: $_model.ListAlertDestinationsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAlertDestinationsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAlertDestinations",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/listDestinations`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAlertDestinationsResponse>(await this.callApi(params, req, runtime), new $_model.ListAlertDestinationsResponse({}));
  }

  /**
   * Retrieves a list of alert contacts.
   * 
   * @param request - ListAlertDestinationsRequest
   * @returns ListAlertDestinationsResponse
   */
  async listAlertDestinations(request: $_model.ListAlertDestinationsRequest): Promise<$_model.ListAlertDestinationsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAlertDestinationsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves all alert metrics.
   * 
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAlertItemsResponse
   */
  async listAlertItemsWithOptions(headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAlertItemsResponse> {
    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAlertItems",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/listItems`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAlertItemsResponse>(await this.callApi(params, req, runtime), new $_model.ListAlertItemsResponse({}));
  }

  /**
   * Retrieves all alert metrics.
   * @returns ListAlertItemsResponse
   */
  async listAlertItems(): Promise<$_model.ListAlertItemsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAlertItemsWithOptions(headers, runtime);
  }

  /**
   * Retrieves all alert policies for pushing alerts.
   * 
   * @param request - ListAlertStrategiesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAlertStrategiesResponse
   */
  async listAlertStrategiesWithOptions(request: $_model.ListAlertStrategiesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAlertStrategiesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAlertStrategies",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/listStrategies`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAlertStrategiesResponse>(await this.callApi(params, req, runtime), new $_model.ListAlertStrategiesResponse({}));
  }

  /**
   * Retrieves all alert policies for pushing alerts.
   * 
   * @param request - ListAlertStrategiesRequest
   * @returns ListAlertStrategiesResponse
   */
  async listAlertStrategies(request: $_model.ListAlertStrategiesRequest): Promise<$_model.ListAlertStrategiesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAlertStrategiesWithOptions(request, headers, runtime);
  }

  /**
   * Queries a list of managed and unmanaged instances along with their details.
   * 
   * @param request - ListAllInstancesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAllInstancesResponse
   */
  async listAllInstancesWithOptions(request: $_model.ListAllInstancesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAllInstancesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.filters)) {
      query["filters"] = request.filters;
    }

    if (!$dara.isNull(request.instanceType)) {
      query["instanceType"] = request.instanceType;
    }

    if (!$dara.isNull(request.managedType)) {
      query["managedType"] = request.managedType;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["pluginId"] = request.pluginId;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAllInstances",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/listAllInstances`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAllInstancesResponse>(await this.callApi(params, req, runtime), new $_model.ListAllInstancesResponse({}));
  }

  /**
   * Queries a list of managed and unmanaged instances along with their details.
   * 
   * @param request - ListAllInstancesRequest
   * @returns ListAllInstancesResponse
   */
  async listAllInstances(request: $_model.ListAllInstancesRequest): Promise<$_model.ListAllInstancesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAllInstancesWithOptions(request, headers, runtime);
  }

  /**
   * 查询应用热点分析记录
   * 
   * @param request - ListAppAnalysisRecordsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListAppAnalysisRecordsResponse
   */
  async listAppAnalysisRecordsWithOptions(request: $_model.ListAppAnalysisRecordsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListAppAnalysisRecordsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.analysisId)) {
      query["analysisId"] = request.analysisId;
    }

    if (!$dara.isNull(request.analysisTime)) {
      query["analysisTime"] = request.analysisTime;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.page)) {
      query["page"] = request.page;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListAppAnalysisRecords",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/app_observ/appAnalysis/list`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListAppAnalysisRecordsResponse>(await this.callApi(params, req, runtime), new $_model.ListAppAnalysisRecordsResponse({}));
  }

  /**
   * 查询应用热点分析记录
   * 
   * @param request - ListAppAnalysisRecordsRequest
   * @returns ListAppAnalysisRecordsResponse
   */
  async listAppAnalysisRecords(request: $_model.ListAppAnalysisRecordsRequest): Promise<$_model.ListAppAnalysisRecordsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listAppAnalysisRecordsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the installation records of cluster components.
   * 
   * @param request - ListClusterAgentInstallRecordsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListClusterAgentInstallRecordsResponse
   */
  async listClusterAgentInstallRecordsWithOptions(request: $_model.ListClusterAgentInstallRecordsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListClusterAgentInstallRecordsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentConfigId)) {
      query["agent_config_id"] = request.agentConfigId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["cluster_id"] = request.clusterId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["plugin_id"] = request.pluginId;
    }

    if (!$dara.isNull(request.pluginVersion)) {
      query["plugin_version"] = request.pluginVersion;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListClusterAgentInstallRecords",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/list_cluster_agent_install_list`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListClusterAgentInstallRecordsResponse>(await this.callApi(params, req, runtime), new $_model.ListClusterAgentInstallRecordsResponse({}));
  }

  /**
   * Retrieves the installation records of cluster components.
   * 
   * @param request - ListClusterAgentInstallRecordsRequest
   * @returns ListClusterAgentInstallRecordsResponse
   */
  async listClusterAgentInstallRecords(request: $_model.ListClusterAgentInstallRecordsRequest): Promise<$_model.ListClusterAgentInstallRecordsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listClusterAgentInstallRecordsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves all managed clusters for the current user.
   * 
   * @param request - ListClustersRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListClustersResponse
   */
  async listClustersWithOptions(request: $_model.ListClustersRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListClustersResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["cluster_id"] = request.clusterId;
    }

    if (!$dara.isNull(request.clusterStatus)) {
      query["cluster_status"] = request.clusterStatus;
    }

    if (!$dara.isNull(request.clusterType)) {
      query["cluster_type"] = request.clusterType;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListClusters",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/cluster/list_clusters`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListClustersResponse>(await this.callApi(params, req, runtime), new $_model.ListClustersResponse({}));
  }

  /**
   * Retrieves all managed clusters for the current user.
   * 
   * @param request - ListClustersRequest
   * @returns ListClustersResponse
   */
  async listClusters(request: $_model.ListClustersRequest): Promise<$_model.ListClustersResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listClustersWithOptions(request, headers, runtime);
  }

  /**
   * Performs a paged query on the persisted history messages and events in a specified session with paging.
   * 
   * @remarks
   * - You can query only the sessions of the current user.
   * - History is returned in the chronological order of events. A record may be a user message, a text chunk, a thinking event, or a tool calling (invoke) event, and does not necessarily correspond to a complete chat message.
   * 
   * @param request - ListCopilotSessionMessagesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListCopilotSessionMessagesResponse
   */
  async listCopilotSessionMessagesWithOptions(request: $_model.ListCopilotSessionMessagesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListCopilotSessionMessagesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.cursor)) {
      query["cursor"] = request.cursor;
    }

    if (!$dara.isNull(request.limit)) {
      query["limit"] = request.limit;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.offset)) {
      query["offset"] = request.offset;
    }

    if (!$dara.isNull(request.sessionId)) {
      query["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListCopilotSessionMessages",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/session-messages`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListCopilotSessionMessagesResponse>(await this.callApi(params, req, runtime), new $_model.ListCopilotSessionMessagesResponse({}));
  }

  /**
   * Performs a paged query on the persisted history messages and events in a specified session with paging.
   * 
   * @remarks
   * - You can query only the sessions of the current user.
   * - History is returned in the chronological order of events. A record may be a user message, a text chunk, a thinking event, or a tool calling (invoke) event, and does not necessarily correspond to a complete chat message.
   * 
   * @param request - ListCopilotSessionMessagesRequest
   * @returns ListCopilotSessionMessagesResponse
   */
  async listCopilotSessionMessages(request: $_model.ListCopilotSessionMessagesRequest): Promise<$_model.ListCopilotSessionMessagesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listCopilotSessionMessagesWithOptions(request, headers, runtime);
  }

  /**
   * Queries the sessions of the current user and supports filtering by session source or scheduled task.
   * 
   * @remarks
   * - Sessions are returned in descending order of update time. If the update time is the same, sessions are returned in descending order of session ID.
   * - If agentId is not specified, the aggregated session list of the current user is queried.
   * - Filter conditions take effect before pagination. When you change the filter conditions, you must clear nextToken and query the first page again.
   * - The status of a session indicates whether the session is archived. To determine whether a session has an active execution, read activeTurn.
   * - Each trigger of a scheduled task creates an independent session. You can use scheduledTask.taskId to associate the session with the task and use scheduledTask.runId to distinguish each trigger.
   * 
   * @param request - ListCopilotSessionsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListCopilotSessionsResponse
   */
  async listCopilotSessionsWithOptions(request: $_model.ListCopilotSessionsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListCopilotSessionsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.agentId)) {
      query["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.scheduledTaskId)) {
      query["scheduledTaskId"] = request.scheduledTaskId;
    }

    if (!$dara.isNull(request.sessionType)) {
      query["sessionType"] = request.sessionType;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListCopilotSessions",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/sessions`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListCopilotSessionsResponse>(await this.callApi(params, req, runtime), new $_model.ListCopilotSessionsResponse({}));
  }

  /**
   * Queries the sessions of the current user and supports filtering by session source or scheduled task.
   * 
   * @remarks
   * - Sessions are returned in descending order of update time. If the update time is the same, sessions are returned in descending order of session ID.
   * - If agentId is not specified, the aggregated session list of the current user is queried.
   * - Filter conditions take effect before pagination. When you change the filter conditions, you must clear nextToken and query the first page again.
   * - The status of a session indicates whether the session is archived. To determine whether a session has an active execution, read activeTurn.
   * - Each trigger of a scheduled task creates an independent session. You can use scheduledTask.taskId to associate the session with the task and use scheduledTask.runId to distinguish each trigger.
   * 
   * @param request - ListCopilotSessionsRequest
   * @returns ListCopilotSessionsResponse
   */
  async listCopilotSessions(request: $_model.ListCopilotSessionsRequest): Promise<$_model.ListCopilotSessionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listCopilotSessionsWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves a list of diagnostic history records.
   * 
   * @param request - ListDiagnosisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListDiagnosisResponse
   */
  async listDiagnosisWithOptions(request: $_model.ListDiagnosisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListDiagnosisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.params)) {
      query["params"] = request.params;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["service_name"] = request.serviceName;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListDiagnosis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/diagnosis/list_diagnosis`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListDiagnosisResponse>(await this.callApi(params, req, runtime), new $_model.ListDiagnosisResponse({}));
  }

  /**
   * Retrieves a list of diagnostic history records.
   * 
   * @param request - ListDiagnosisRequest
   * @returns ListDiagnosisResponse
   */
  async listDiagnosis(request: $_model.ListDiagnosisRequest): Promise<$_model.ListDiagnosisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listDiagnosisWithOptions(request, headers, runtime);
  }

  /**
   * 分页查询当前账号的主机巡检任务
   * 
   * @remarks
   * 默认按 createdAt 倒序；只返回当前账号的任务；deviceId 为弱过滤条件；status 支持逗号分隔多值。
   * 
   * @param request - ListHostInspectionsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListHostInspectionsResponse
   */
  async listHostInspectionsWithOptions(request: $_model.ListHostInspectionsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListHostInspectionsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.deviceId)) {
      query["deviceId"] = request.deviceId;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListHostInspections",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/listHostInspections`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListHostInspectionsResponse>(await this.callApi(params, req, runtime), new $_model.ListHostInspectionsResponse({}));
  }

  /**
   * 分页查询当前账号的主机巡检任务
   * 
   * @remarks
   * 默认按 createdAt 倒序；只返回当前账号的任务；deviceId 为弱过滤条件；status 支持逗号分隔多值。
   * 
   * @param request - ListHostInspectionsRequest
   * @returns ListHostInspectionsResponse
   */
  async listHostInspections(request: $_model.ListHostInspectionsRequest): Promise<$_model.ListHostInspectionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listHostInspectionsWithOptions(request, headers, runtime);
  }

  /**
   * 查询可自定义阈值的 ECS 巡检项及其生效阈值
   * 
   * @param request - ListInspectionItemThresholdsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInspectionItemThresholdsResponse
   */
  async listInspectionItemThresholdsWithOptions(request: $_model.ListInspectionItemThresholdsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInspectionItemThresholdsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionType)) {
      query["inspectionType"] = request.inspectionType;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInspectionItemThresholds",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/listItemThresholds`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInspectionItemThresholdsResponse>(await this.callApi(params, req, runtime), new $_model.ListInspectionItemThresholdsResponse({}));
  }

  /**
   * 查询可自定义阈值的 ECS 巡检项及其生效阈值
   * 
   * @param request - ListInspectionItemThresholdsRequest
   * @returns ListInspectionItemThresholdsResponse
   */
  async listInspectionItemThresholds(request: $_model.ListInspectionItemThresholdsRequest): Promise<$_model.ListInspectionItemThresholdsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInspectionItemThresholdsWithOptions(request, headers, runtime);
  }

  /**
   * 查询可用的巡检项列表
   * 
   * @param request - ListInspectionItemsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInspectionItemsResponse
   */
  async listInspectionItemsWithOptions(request: $_model.ListInspectionItemsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInspectionItemsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionType)) {
      query["inspectionType"] = request.inspectionType;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInspectionItems",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/listInspectionItems`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInspectionItemsResponse>(await this.callApi(params, req, runtime), new $_model.ListInspectionItemsResponse({}));
  }

  /**
   * 查询可用的巡检项列表
   * 
   * @param request - ListInspectionItemsRequest
   * @returns ListInspectionItemsResponse
   */
  async listInspectionItems(request: $_model.ListInspectionItemsRequest): Promise<$_model.ListInspectionItemsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInspectionItemsWithOptions(request, headers, runtime);
  }

  /**
   * 分页查询定时巡检计划的执行历史
   * 
   * @param request - ListInspectionScheduleRunsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInspectionScheduleRunsResponse
   */
  async listInspectionScheduleRunsWithOptions(request: $_model.ListInspectionScheduleRunsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInspectionScheduleRunsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.scheduleId)) {
      query["scheduleId"] = request.scheduleId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInspectionScheduleRuns",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/listInspectionScheduleRuns`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInspectionScheduleRunsResponse>(await this.callApi(params, req, runtime), new $_model.ListInspectionScheduleRunsResponse({}));
  }

  /**
   * 分页查询定时巡检计划的执行历史
   * 
   * @param request - ListInspectionScheduleRunsRequest
   * @returns ListInspectionScheduleRunsResponse
   */
  async listInspectionScheduleRuns(request: $_model.ListInspectionScheduleRunsRequest): Promise<$_model.ListInspectionScheduleRunsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInspectionScheduleRunsWithOptions(request, headers, runtime);
  }

  /**
   * 分页查询定时巡检计划列表
   * 
   * @param request - ListInspectionSchedulesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInspectionSchedulesResponse
   */
  async listInspectionSchedulesWithOptions(request: $_model.ListInspectionSchedulesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInspectionSchedulesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.enabled)) {
      query["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.scheduleType)) {
      query["scheduleType"] = request.scheduleType;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInspectionSchedules",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/listInspectionSchedules`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInspectionSchedulesResponse>(await this.callApi(params, req, runtime), new $_model.ListInspectionSchedulesResponse({}));
  }

  /**
   * 分页查询定时巡检计划列表
   * 
   * @param request - ListInspectionSchedulesRequest
   * @returns ListInspectionSchedulesResponse
   */
  async listInspectionSchedules(request: $_model.ListInspectionSchedulesRequest): Promise<$_model.ListInspectionSchedulesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInspectionSchedulesWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the health status list of cluster nodes or pods within a specified time range.
   * 
   * @param request - ListInstanceHealthRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstanceHealthResponse
   */
  async listInstanceHealthWithOptions(request: $_model.ListInstanceHealthRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstanceHealthResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstanceHealth",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/cluster_health/range/instance_health_list`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstanceHealthResponse>(await this.callApi(params, req, runtime), new $_model.ListInstanceHealthResponse({}));
  }

  /**
   * Retrieves the health status list of cluster nodes or pods within a specified time range.
   * 
   * @param request - ListInstanceHealthRequest
   * @returns ListInstanceHealthResponse
   */
  async listInstanceHealth(request: $_model.ListInstanceHealthRequest): Promise<$_model.ListInstanceHealthResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstanceHealthWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves all values of a specific type of instance information.
   * 
   * @param request - ListInstanceInfoRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstanceInfoResponse
   */
  async listInstanceInfoWithOptions(request: $_model.ListInstanceInfoRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstanceInfoResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.infoType)) {
      query["infoType"] = request.infoType;
    }

    if (!$dara.isNull(request.instanceType)) {
      query["instanceType"] = request.instanceType;
    }

    if (!$dara.isNull(request.managedType)) {
      query["managedType"] = request.managedType;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["pluginId"] = request.pluginId;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstanceInfo",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/listInstanceInfo`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstanceInfoResponse>(await this.callApi(params, req, runtime), new $_model.ListInstanceInfoResponse({}));
  }

  /**
   * Retrieves all values of a specific type of instance information.
   * 
   * @param request - ListInstanceInfoRequest
   * @returns ListInstanceInfoResponse
   */
  async listInstanceInfo(request: $_model.ListInstanceInfoRequest): Promise<$_model.ListInstanceInfoResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstanceInfoWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the instance status.
   * 
   * @remarks
   * Retrieves the list of machines managed by SysOM.
   * 
   * @param request - ListInstanceStatusRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstanceStatusResponse
   */
  async listInstanceStatusWithOptions(request: $_model.ListInstanceStatusRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstanceStatusResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstanceStatus",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/list_instance_status`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstanceStatusResponse>(await this.callApi(params, req, runtime), new $_model.ListInstanceStatusResponse({}));
  }

  /**
   * Retrieves the instance status.
   * 
   * @remarks
   * Retrieves the list of machines managed by SysOM.
   * 
   * @param request - ListInstanceStatusRequest
   * @returns ListInstanceStatusResponse
   */
  async listInstanceStatus(request: $_model.ListInstanceStatusRequest): Promise<$_model.ListInstanceStatusResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstanceStatusWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of managed instances.
   * 
   * @remarks
   * This operation retrieves the list of instances that are already managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListInstancesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstancesResponse
   */
  async listInstancesWithOptions(request: $_model.ListInstancesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstancesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["cluster_id"] = request.clusterId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.status)) {
      query["status"] = request.status;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstances",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/list_instances`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstancesResponse>(await this.callApi(params, req, runtime), new $_model.ListInstancesResponse({}));
  }

  /**
   * Retrieves the list of managed instances.
   * 
   * @remarks
   * This operation retrieves the list of instances that are already managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListInstancesRequest
   * @returns ListInstancesResponse
   */
  async listInstances(request: $_model.ListInstancesRequest): Promise<$_model.ListInstancesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstancesWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves ECS information lists for instances, such as tag lists and public IP address lists.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListInstancesEcsInfoListRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstancesEcsInfoListResponse
   */
  async listInstancesEcsInfoListWithOptions(request: $_model.ListInstancesEcsInfoListRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstancesEcsInfoListResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.infoType)) {
      query["info_type"] = request.infoType;
    }

    if (!$dara.isNull(request.instanceId)) {
      query["instance_id"] = request.instanceId;
    }

    if (!$dara.isNull(request.managedType)) {
      query["managed_type"] = request.managedType;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["plugin_id"] = request.pluginId;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstancesEcsInfoList",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/listInstancesEcsInfoList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstancesEcsInfoListResponse>(await this.callApi(params, req, runtime), new $_model.ListInstancesEcsInfoListResponse({}));
  }

  /**
   * Retrieves ECS information lists for instances, such as tag lists and public IP address lists.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListInstancesEcsInfoListRequest
   * @returns ListInstancesEcsInfoListResponse
   */
  async listInstancesEcsInfoList(request: $_model.ListInstancesEcsInfoListRequest): Promise<$_model.ListInstancesEcsInfoListResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstancesEcsInfoListWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves information about managed and unmanaged instances, including ECS information.
   * 
   * @remarks
   * The instance list returned by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param tmpReq - ListInstancesWithEcsInfoRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListInstancesWithEcsInfoResponse
   */
  async listInstancesWithEcsInfoWithOptions(tmpReq: $_model.ListInstancesWithEcsInfoRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListInstancesWithEcsInfoResponse> {
    tmpReq.validate();
    let request = new $_model.ListInstancesWithEcsInfoShrinkRequest({ });
    OpenApiUtil.convert(tmpReq, request);
    if (!$dara.isNull(tmpReq.instanceTag)) {
      request.instanceTagShrink = OpenApiUtil.arrayToStringWithSpecifiedStyle(tmpReq.instanceTag, "instance_tag", "json");
    }

    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.healthStatus)) {
      query["health_status"] = request.healthStatus;
    }

    if (!$dara.isNull(request.instanceId)) {
      query["instance_id"] = request.instanceId;
    }

    if (!$dara.isNull(request.instanceIdName)) {
      query["instance_id_name"] = request.instanceIdName;
    }

    if (!$dara.isNull(request.instanceName)) {
      query["instance_name"] = request.instanceName;
    }

    if (!$dara.isNull(request.instanceTagShrink)) {
      query["instance_tag"] = request.instanceTagShrink;
    }

    if (!$dara.isNull(request.isManaged)) {
      query["is_managed"] = request.isManaged;
    }

    if (!$dara.isNull(request.osName)) {
      query["os_name"] = request.osName;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.privateIp)) {
      query["private_ip"] = request.privateIp;
    }

    if (!$dara.isNull(request.publicIp)) {
      query["public_ip"] = request.publicIp;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.resourceGroupId)) {
      query["resource_group_id"] = request.resourceGroupId;
    }

    if (!$dara.isNull(request.resourceGroupIdName)) {
      query["resource_group_id_name"] = request.resourceGroupIdName;
    }

    if (!$dara.isNull(request.resourceGroupName)) {
      query["resource_group_name"] = request.resourceGroupName;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListInstancesWithEcsInfo",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/listInstancesWithEcsInfo`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListInstancesWithEcsInfoResponse>(await this.callApi(params, req, runtime), new $_model.ListInstancesWithEcsInfoResponse({}));
  }

  /**
   * Retrieves information about managed and unmanaged instances, including ECS information.
   * 
   * @remarks
   * The instance list returned by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListInstancesWithEcsInfoRequest
   * @returns ListInstancesWithEcsInfoResponse
   */
  async listInstancesWithEcsInfo(request: $_model.ListInstancesWithEcsInfoRequest): Promise<$_model.ListInstancesWithEcsInfoResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listInstancesWithEcsInfoWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of instances for plug-in installation, update, or uninstallation.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListPluginsInstancesRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListPluginsInstancesResponse
   */
  async listPluginsInstancesWithOptions(request: $_model.ListPluginsInstancesRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListPluginsInstancesResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.instanceIdName)) {
      query["instance_id_name"] = request.instanceIdName;
    }

    if (!$dara.isNull(request.instanceTag)) {
      query["instance_tag"] = request.instanceTag;
    }

    if (!$dara.isNull(request.operationType)) {
      query["operation_type"] = request.operationType;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.pluginId)) {
      query["plugin_id"] = request.pluginId;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListPluginsInstances",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/listPluginsInstances`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListPluginsInstancesResponse>(await this.callApi(params, req, runtime), new $_model.ListPluginsInstancesResponse({}));
  }

  /**
   * Retrieves the list of instances for plug-in installation, update, or uninstallation.
   * 
   * @remarks
   * The instance list retrieved by this operation contains only machines that are managed by SysOM. If an ECS instance exists but is not managed by SysOM, it does not appear in the list.
   * 
   * @param request - ListPluginsInstancesRequest
   * @returns ListPluginsInstancesResponse
   */
  async listPluginsInstances(request: $_model.ListPluginsInstancesRequest): Promise<$_model.ListPluginsInstancesResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listPluginsInstancesWithOptions(request, headers, runtime);
  }

  /**
   * Retrieves the list of pods in a cluster or instance.
   * 
   * @param request - ListPodsOfInstanceRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListPodsOfInstanceResponse
   */
  async listPodsOfInstanceWithOptions(request: $_model.ListPodsOfInstanceRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListPodsOfInstanceResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.clusterId)) {
      query["cluster_id"] = request.clusterId;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListPodsOfInstance",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/list_pod_of_instance`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListPodsOfInstanceResponse>(await this.callApi(params, req, runtime), new $_model.ListPodsOfInstanceResponse({}));
  }

  /**
   * Retrieves the list of pods in a cluster or instance.
   * 
   * @param request - ListPodsOfInstanceRequest
   * @returns ListPodsOfInstanceResponse
   */
  async listPodsOfInstance(request: $_model.ListPodsOfInstanceRequest): Promise<$_model.ListPodsOfInstanceResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listPodsOfInstanceWithOptions(request, headers, runtime);
  }

  /**
   * Lists all regions with managed instances.
   * 
   * @remarks
   * This operation retrieves the list of regions where the current user has instances managed by SysOM. If you have ECS instances in a region but they are not managed by SysOM, the region is not included in the response.
   * 
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListRegionsResponse
   */
  async listRegionsWithOptions(headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListRegionsResponse> {
    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
    });
    let params = new $OpenApiUtil.Params({
      action: "ListRegions",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/instance/list_regions`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListRegionsResponse>(await this.callApi(params, req, runtime), new $_model.ListRegionsResponse({}));
  }

  /**
   * Lists all regions with managed instances.
   * 
   * @remarks
   * This operation retrieves the list of regions where the current user has instances managed by SysOM. If you have ECS instances in a region but they are not managed by SysOM, the region is not included in the response.
   * @returns ListRegionsResponse
   */
  async listRegions(): Promise<$_model.ListRegionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listRegionsWithOptions(headers, runtime);
  }

  /**
   * 查询定时任务历次执行的 session 列表
   * 
   * @param request - ListScheduledTaskSessionsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListScheduledTaskSessionsResponse
   */
  async listScheduledTaskSessionsWithOptions(request: $_model.ListScheduledTaskSessionsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListScheduledTaskSessionsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.taskId)) {
      query["taskId"] = request.taskId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListScheduledTaskSessions",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/imGateway/listScheduledTaskSessions`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListScheduledTaskSessionsResponse>(await this.callApi(params, req, runtime), new $_model.ListScheduledTaskSessionsResponse({}));
  }

  /**
   * 查询定时任务历次执行的 session 列表
   * 
   * @param request - ListScheduledTaskSessionsRequest
   * @returns ListScheduledTaskSessionsResponse
   */
  async listScheduledTaskSessions(request: $_model.ListScheduledTaskSessionsRequest): Promise<$_model.ListScheduledTaskSessionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listScheduledTaskSessionsWithOptions(request, headers, runtime);
  }

  /**
   * 查询定时任务
   * 
   * @param request - ListScheduledTasksRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListScheduledTasksResponse
   */
  async listScheduledTasksWithOptions(request: $_model.ListScheduledTasksRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListScheduledTasksResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.enable)) {
      query["enable"] = request.enable;
    }

    if (!$dara.isNull(request.id)) {
      query["id"] = request.id;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.name)) {
      query["name"] = request.name;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListScheduledTasks",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/imGateway/listScheduledTasks`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListScheduledTasksResponse>(await this.callApi(params, req, runtime), new $_model.ListScheduledTasksResponse({}));
  }

  /**
   * 查询定时任务
   * 
   * @param request - ListScheduledTasksRequest
   * @returns ListScheduledTasksResponse
   */
  async listScheduledTasks(request: $_model.ListScheduledTasksRequest): Promise<$_model.ListScheduledTasksResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listScheduledTasksWithOptions(request, headers, runtime);
  }

  /**
   * 获取用户异常事件列表和分布情况
   * 
   * @param request - ListUserAbnormalyEventsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListUserAbnormalyEventsResponse
   */
  async listUserAbnormalyEventsWithOptions(request: $_model.ListUserAbnormalyEventsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListUserAbnormalyEventsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.cluster)) {
      query["cluster"] = request.cluster;
    }

    if (!$dara.isNull(request.current)) {
      query["current"] = request.current;
    }

    if (!$dara.isNull(request.end)) {
      query["end"] = request.end;
    }

    if (!$dara.isNull(request.event)) {
      query["event"] = request.event;
    }

    if (!$dara.isNull(request.instance)) {
      query["instance"] = request.instance;
    }

    if (!$dara.isNull(request.level)) {
      query["level"] = request.level;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.start)) {
      query["start"] = request.start;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListUserAbnormalyEvents",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/clusterHealthApi/listUserAbnormalyEvents`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListUserAbnormalyEventsResponse>(await this.callApi(params, req, runtime), new $_model.ListUserAbnormalyEventsResponse({}));
  }

  /**
   * 获取用户异常事件列表和分布情况
   * 
   * @param request - ListUserAbnormalyEventsRequest
   * @returns ListUserAbnormalyEventsResponse
   */
  async listUserAbnormalyEvents(request: $_model.ListUserAbnormalyEventsRequest): Promise<$_model.ListUserAbnormalyEventsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listUserAbnormalyEventsWithOptions(request, headers, runtime);
  }

  /**
   * 获取用户功能白名单
   * 
   * @param request - ListUserFeatureRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListUserFeatureResponse
   */
  async listUserFeatureWithOptions(request: $_model.ListUserFeatureRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListUserFeatureResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.feature)) {
      query["feature"] = request.feature;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListUserFeature",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/configManage/feature/listUserFeature`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListUserFeatureResponse>(await this.callApi(params, req, runtime), new $_model.ListUserFeatureResponse({}));
  }

  /**
   * 获取用户功能白名单
   * 
   * @param request - ListUserFeatureRequest
   * @returns ListUserFeatureResponse
   */
  async listUserFeature(request: $_model.ListUserFeatureRequest): Promise<$_model.ListUserFeatureResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listUserFeatureWithOptions(request, headers, runtime);
  }

  /**
   * 获取诊断历史记录列表
   * 
   * @param request - ListVllmTracingJobsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListVllmTracingJobsResponse
   */
  async listVllmTracingJobsWithOptions(request: $_model.ListVllmTracingJobsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListVllmTracingJobsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.maxResults)) {
      query["maxResults"] = request.maxResults;
    }

    if (!$dara.isNull(request.nextToken)) {
      query["nextToken"] = request.nextToken;
    }

    if (!$dara.isNull(request.page)) {
      query["page"] = request.page;
    }

    if (!$dara.isNull(request.pageSize)) {
      query["pageSize"] = request.pageSize;
    }

    if (!$dara.isNull(request.region)) {
      query["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["serviceName"] = request.serviceName;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListVllmTracingJobs",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/listVllmTracingJobs`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListVllmTracingJobsResponse>(await this.callApi(params, req, runtime), new $_model.ListVllmTracingJobsResponse({}));
  }

  /**
   * 获取诊断历史记录列表
   * 
   * @param request - ListVllmTracingJobsRequest
   * @returns ListVllmTracingJobsResponse
   */
  async listVllmTracingJobs(request: $_model.ListVllmTracingJobsRequest): Promise<$_model.ListVllmTracingJobsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listVllmTracingJobsWithOptions(request, headers, runtime);
  }

  /**
   * Queries the list of historical down diagnosis tasks.
   * 
   * @param request - ListVmcoreDiagnosisTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ListVmcoreDiagnosisTaskResponse
   */
  async listVmcoreDiagnosisTaskWithOptions(request: $_model.ListVmcoreDiagnosisTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ListVmcoreDiagnosisTaskResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.days)) {
      query["days"] = request.days;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "ListVmcoreDiagnosisTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/crashAgent/diagnosis/queryTaskList`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ListVmcoreDiagnosisTaskResponse>(await this.callApi(params, req, runtime), new $_model.ListVmcoreDiagnosisTaskResponse({}));
  }

  /**
   * Queries the list of historical down diagnosis tasks.
   * 
   * @param request - ListVmcoreDiagnosisTaskRequest
   * @returns ListVmcoreDiagnosisTaskResponse
   */
  async listVmcoreDiagnosisTask(request: $_model.ListVmcoreDiagnosisTaskRequest): Promise<$_model.ListVmcoreDiagnosisTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.listVmcoreDiagnosisTaskWithOptions(request, headers, runtime);
  }

  /**
   * 操作定时任务
   * 
   * @param request - OperateScheduledTaskRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns OperateScheduledTaskResponse
   */
  async operateScheduledTaskWithOptions(request: $_model.OperateScheduledTaskRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.OperateScheduledTaskResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentCode)) {
      body["agentCode"] = request.agentCode;
    }

    if (!$dara.isNull(request.cronExp)) {
      body["cronExp"] = request.cronExp;
    }

    if (!$dara.isNull(request.destinationId)) {
      body["destinationId"] = request.destinationId;
    }

    if (!$dara.isNull(request.enable)) {
      body["enable"] = request.enable;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    if (!$dara.isNull(request.inspectionId)) {
      body["inspectionId"] = request.inspectionId;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.operation)) {
      body["operation"] = request.operation;
    }

    if (!$dara.isNull(request.prompt)) {
      body["prompt"] = request.prompt;
    }

    if (!$dara.isNull(request.taskType)) {
      body["taskType"] = request.taskType;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "OperateScheduledTask",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/imGateway/operateScheduledTask`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.OperateScheduledTaskResponse>(await this.callApi(params, req, runtime), new $_model.OperateScheduledTaskResponse({}));
  }

  /**
   * 操作定时任务
   * 
   * @param request - OperateScheduledTaskRequest
   * @returns OperateScheduledTaskResponse
   */
  async operateScheduledTask(request: $_model.OperateScheduledTaskRequest): Promise<$_model.OperateScheduledTaskResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.operateScheduledTaskWithOptions(request, headers, runtime);
  }

  /**
   * 探测实例 Livetrace 心跳状态
   * 
   * @remarks
   * 检查指定 ECS 或 EFLO 实例的 Livetrace 心跳及模块状态。
   * 
   * @param request - ProbeLivetraceRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ProbeLivetraceResponse
   */
  async probeLivetraceWithOptions(request: $_model.ProbeLivetraceRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ProbeLivetraceResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.channel)) {
      body["channel"] = request.channel;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "ProbeLivetrace",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/livetrace_probe`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ProbeLivetraceResponse>(await this.callApi(params, req, runtime), new $_model.ProbeLivetraceResponse({}));
  }

  /**
   * 探测实例 Livetrace 心跳状态
   * 
   * @remarks
   * 检查指定 ECS 或 EFLO 实例的 Livetrace 心跳及模块状态。
   * 
   * @param request - ProbeLivetraceRequest
   * @returns ProbeLivetraceResponse
   */
  async probeLivetrace(request: $_model.ProbeLivetraceRequest): Promise<$_model.ProbeLivetraceResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.probeLivetraceWithOptions(request, headers, runtime);
  }

  /**
   * Asynchronously queries the CVE hotfix status on the specified instances.
   * 
   * @remarks
   * Calling this API operation to install the agent is asynchronous. After the call, a task_id is returned. You can use this ID to call the GetHotfixTask operation to query the execution status of the task.
   * 
   * @param request - QueryHotfixStatusRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns QueryHotfixStatusResponse
   */
  async queryHotfixStatusWithOptions(request: $_model.QueryHotfixStatusRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.QueryHotfixStatusResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cveId)) {
      body["cveId"] = request.cveId;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "QueryHotfixStatus",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/hotfix_manager/hotfix/query_status`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.QueryHotfixStatusResponse>(await this.callApi(params, req, runtime), new $_model.QueryHotfixStatusResponse({}));
  }

  /**
   * Asynchronously queries the CVE hotfix status on the specified instances.
   * 
   * @remarks
   * Calling this API operation to install the agent is asynchronous. After the call, a task_id is returned. You can use this ID to call the GetHotfixTask operation to query the execution status of the task.
   * 
   * @param request - QueryHotfixStatusRequest
   * @returns QueryHotfixStatusResponse
   */
  async queryHotfixStatus(request: $_model.QueryHotfixStatusRequest): Promise<$_model.QueryHotfixStatusResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.queryHotfixStatusWithOptions(request, headers, runtime);
  }

  /**
   * 查询 Profiling Agent 会话记录
   * 
   * @param request - QueryProfilingAgentSessionsRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns QueryProfilingAgentSessionsResponse
   */
  async queryProfilingAgentSessionsWithOptions(request: $_model.QueryProfilingAgentSessionsRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.QueryProfilingAgentSessionsResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.analysisId)) {
      query["analysis_id"] = request.analysisId;
    }

    if (!$dara.isNull(request.sessionId)) {
      query["session_id"] = request.sessionId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "QueryProfilingAgentSessions",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiprofilingAgent/sessions/query`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.QueryProfilingAgentSessionsResponse>(await this.callApi(params, req, runtime), new $_model.QueryProfilingAgentSessionsResponse({}));
  }

  /**
   * 查询 Profiling Agent 会话记录
   * 
   * @param request - QueryProfilingAgentSessionsRequest
   * @returns QueryProfilingAgentSessionsResponse
   */
  async queryProfilingAgentSessions(request: $_model.QueryProfilingAgentSessionsRequest): Promise<$_model.QueryProfilingAgentSessionsResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.queryProfilingAgentSessionsWithOptions(request, headers, runtime);
  }

  /**
   * 重置 ECS 巡检项阈值，删除用户自定义配置并回落默认值
   * 
   * @param request - ResetInspectionItemThresholdRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ResetInspectionItemThresholdResponse
   */
  async resetInspectionItemThresholdWithOptions(request: $_model.ResetInspectionItemThresholdRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ResetInspectionItemThresholdResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionType)) {
      body["inspectionType"] = request.inspectionType;
    }

    if (!$dara.isNull(request.itemNames)) {
      body["itemNames"] = request.itemNames;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "ResetInspectionItemThreshold",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/resetItemThreshold`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ResetInspectionItemThresholdResponse>(await this.callApi(params, req, runtime), new $_model.ResetInspectionItemThresholdResponse({}));
  }

  /**
   * 重置 ECS 巡检项阈值，删除用户自定义配置并回落默认值
   * 
   * @param request - ResetInspectionItemThresholdRequest
   * @returns ResetInspectionItemThresholdResponse
   */
  async resetInspectionItemThreshold(request: $_model.ResetInspectionItemThresholdRequest): Promise<$_model.ResetInspectionItemThresholdResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.resetInspectionItemThresholdWithOptions(request, headers, runtime);
  }

  /**
   * 设置 ECS 巡检项的用户自定义阈值
   * 
   * @param request - SetInspectionItemThresholdRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns SetInspectionItemThresholdResponse
   */
  async setInspectionItemThresholdWithOptions(request: $_model.SetInspectionItemThresholdRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.SetInspectionItemThresholdResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionType)) {
      body["inspectionType"] = request.inspectionType;
    }

    if (!$dara.isNull(request.itemName)) {
      body["itemName"] = request.itemName;
    }

    if (!$dara.isNull(request.thresholds)) {
      body["thresholds"] = request.thresholds;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "SetInspectionItemThreshold",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspection/setItemThreshold`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.SetInspectionItemThresholdResponse>(await this.callApi(params, req, runtime), new $_model.SetInspectionItemThresholdResponse({}));
  }

  /**
   * 设置 ECS 巡检项的用户自定义阈值
   * 
   * @param request - SetInspectionItemThresholdRequest
   * @returns SetInspectionItemThresholdResponse
   */
  async setInspectionItemThreshold(request: $_model.SetInspectionItemThresholdRequest): Promise<$_model.SetInspectionItemThresholdResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.setInspectionItemThresholdWithOptions(request, headers, runtime);
  }

  /**
   * Starts AI job analysis.
   * 
   * @param request - StartAIAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartAIAnalysisResponse
   */
  async startAIAnalysisWithOptions(request: $_model.StartAIAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartAIAnalysisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.analysisTool)) {
      body["analysisTool"] = request.analysisTool;
    }

    if (!$dara.isNull(request.analysisParams)) {
      body["analysis_params"] = request.analysisParams;
    }

    if (!$dara.isNull(request.channel)) {
      body["channel"] = request.channel;
    }

    if (!$dara.isNull(request.comms)) {
      body["comms"] = request.comms;
    }

    if (!$dara.isNull(request.createdBy)) {
      body["created_by"] = request.createdBy;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.instanceType)) {
      body["instance_type"] = request.instanceType;
    }

    if (!$dara.isNull(request.iterationFunc)) {
      body["iteration_func"] = request.iterationFunc;
    }

    if (!$dara.isNull(request.iterationMod)) {
      body["iteration_mod"] = request.iterationMod;
    }

    if (!$dara.isNull(request.iterationRange)) {
      body["iteration_range"] = request.iterationRange;
    }

    if (!$dara.isNull(request.pids)) {
      body["pids"] = request.pids;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    if (!$dara.isNull(request.timeout)) {
      body["timeout"] = request.timeout;
    }

    if (!$dara.isNull(request.uid)) {
      body["uid"] = request.uid;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartAIAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/start_ai_analysis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartAIAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.StartAIAnalysisResponse({}));
  }

  /**
   * Starts AI job analysis.
   * 
   * @param request - StartAIAnalysisRequest
   * @returns StartAIAnalysisResponse
   */
  async startAIAnalysis(request: $_model.StartAIAnalysisRequest): Promise<$_model.StartAIAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startAIAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * Starts an AI Infra differential analysis.
   * 
   * @remarks
   * Currently, only comparative analysis of the same PID across different steps within the same AI Infra analysis record is supported.
   * 
   * @param request - StartAIDiffAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartAIDiffAnalysisResponse
   */
  async startAIDiffAnalysisWithOptions(request: $_model.StartAIDiffAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartAIDiffAnalysisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.task1)) {
      body["task1"] = request.task1;
    }

    if (!$dara.isNull(request.task2)) {
      body["task2"] = request.task2;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartAIDiffAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/appObserv/aiAnalysis/diffAnalysis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartAIDiffAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.StartAIDiffAnalysisResponse({}));
  }

  /**
   * Starts an AI Infra differential analysis.
   * 
   * @remarks
   * Currently, only comparative analysis of the same PID across different steps within the same AI Infra analysis record is supported.
   * 
   * @param request - StartAIDiffAnalysisRequest
   * @returns StartAIDiffAnalysisResponse
   */
  async startAIDiffAnalysis(request: $_model.StartAIDiffAnalysisRequest): Promise<$_model.StartAIDiffAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startAIDiffAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * 创建 Agent 优化分析任务
   * 
   * @param request - StartAgentOptimizationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartAgentOptimizationResponse
   */
  async startAgentOptimizationWithOptions(request: $_model.StartAgentOptimizationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartAgentOptimizationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.dimensions)) {
      body["dimensions"] = request.dimensions;
    }

    if (!$dara.isNull(request.endTime)) {
      body["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.includeLlmJudgement)) {
      body["includeLlmJudgement"] = request.includeLlmJudgement;
    }

    if (!$dara.isNull(request.regionId)) {
      body["regionId"] = request.regionId;
    }

    if (!$dara.isNull(request.sessionId)) {
      body["sessionId"] = request.sessionId;
    }

    if (!$dara.isNull(request.sourceType)) {
      body["sourceType"] = request.sourceType;
    }

    if (!$dara.isNull(request.startTime)) {
      body["startTime"] = request.startTime;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartAgentOptimization",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/startAgentOptimization`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartAgentOptimizationResponse>(await this.callApi(params, req, runtime), new $_model.StartAgentOptimizationResponse({}));
  }

  /**
   * 创建 Agent 优化分析任务
   * 
   * @param request - StartAgentOptimizationRequest
   * @returns StartAgentOptimizationResponse
   */
  async startAgentOptimization(request: $_model.StartAgentOptimizationRequest): Promise<$_model.StartAgentOptimizationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startAgentOptimizationWithOptions(request, headers, runtime);
  }

  /**
   * Triggers AI application diagnostics.
   * 
   * @remarks
   * Currently, only comparative analysis of the same PID across different steps under the same AI Infra analysis record is supported.
   * 
   * @param request - StartAifgAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartAifgAnalysisResponse
   */
  async startAifgAnalysisWithOptions(request: $_model.StartAifgAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartAifgAnalysisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.channel)) {
      body["channel"] = request.channel;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      body["serviceName"] = request.serviceName;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartAifgAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/startAifgAnalysis`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartAifgAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.StartAifgAnalysisResponse({}));
  }

  /**
   * Triggers AI application diagnostics.
   * 
   * @remarks
   * Currently, only comparative analysis of the same PID across different steps under the same AI Infra analysis record is supported.
   * 
   * @param request - StartAifgAnalysisRequest
   * @returns StartAifgAnalysisResponse
   */
  async startAifgAnalysis(request: $_model.StartAifgAnalysisRequest): Promise<$_model.StartAifgAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startAifgAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * 发起 Profiling Agent 分析任务
   * 
   * @param request - StartProfilingAgentAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartProfilingAgentAnalysisResponse
   */
  async startProfilingAgentAnalysisWithOptions(request: $_model.StartProfilingAgentAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartProfilingAgentAnalysisResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.files)) {
      body["files"] = request.files;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.profilingType)) {
      body["profiling_type"] = request.profilingType;
    }

    if (!$dara.isNull(request.prompt)) {
      body["prompt"] = request.prompt;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartProfilingAgentAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiprofilingAgent/analyze`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartProfilingAgentAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.StartProfilingAgentAnalysisResponse({}));
  }

  /**
   * 发起 Profiling Agent 分析任务
   * 
   * @param request - StartProfilingAgentAnalysisRequest
   * @returns StartProfilingAgentAnalysisResponse
   */
  async startProfilingAgentAnalysis(request: $_model.StartProfilingAgentAnalysisRequest): Promise<$_model.StartProfilingAgentAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startProfilingAgentAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * 启动vllm并发分析
   * 
   * @param request - StartVllmTracingRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns StartVllmTracingResponse
   */
  async startVllmTracingWithOptions(request: $_model.StartVllmTracingRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.StartVllmTracingResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.endTime)) {
      body["endTime"] = request.endTime;
    }

    if (!$dara.isNull(request.ipv4)) {
      body["ipv4"] = request.ipv4;
    }

    if (!$dara.isNull(request.modelName)) {
      body["modelName"] = request.modelName;
    }

    if (!$dara.isNull(request.region)) {
      body["region"] = request.region;
    }

    if (!$dara.isNull(request.serviceName)) {
      body["serviceName"] = request.serviceName;
    }

    if (!$dara.isNull(request.startTime)) {
      body["startTime"] = request.startTime;
    }

    if (!$dara.isNull(request.traceId)) {
      body["traceId"] = request.traceId;
    }

    if (!$dara.isNull(request.workspace)) {
      body["workspace"] = request.workspace;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "StartVllmTracing",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aifg/startVllmTracing`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.StartVllmTracingResponse>(await this.callApi(params, req, runtime), new $_model.StartVllmTracingResponse({}));
  }

  /**
   * 启动vllm并发分析
   * 
   * @param request - StartVllmTracingRequest
   * @returns StartVllmTracingResponse
   */
  async startVllmTracing(request: $_model.StartVllmTracingRequest): Promise<$_model.StartVllmTracingResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.startVllmTracingWithOptions(request, headers, runtime);
  }

  /**
   * 发起应用热点分析
   * 
   * @param request - SubmitAppAnalysisRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns SubmitAppAnalysisResponse
   */
  async submitAppAnalysisWithOptions(request: $_model.SubmitAppAnalysisRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.SubmitAppAnalysisResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.appType)) {
      body["appType"] = request.appType;
    }

    if (!$dara.isNull(request.comms)) {
      body["comms"] = request.comms;
    }

    if (!$dara.isNull(request.cut)) {
      body["cut"] = request.cut;
    }

    if (!$dara.isNull(request.end)) {
      body["end"] = request.end;
    }

    if (!$dara.isNull(request.instance)) {
      body["instance"] = request.instance;
    }

    if (!$dara.isNull(request.pids)) {
      body["pids"] = request.pids;
    }

    if (!$dara.isNull(request.podip)) {
      body["podip"] = request.podip;
    }

    if (!$dara.isNull(request.podname)) {
      body["podname"] = request.podname;
    }

    if (!$dara.isNull(request.ports)) {
      body["ports"] = request.ports;
    }

    if (!$dara.isNull(request.start)) {
      body["start"] = request.start;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "SubmitAppAnalysis",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/app_observ/appAnalysis/analysis_post`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.SubmitAppAnalysisResponse>(await this.callApi(params, req, runtime), new $_model.SubmitAppAnalysisResponse({}));
  }

  /**
   * 发起应用热点分析
   * 
   * @param request - SubmitAppAnalysisRequest
   * @returns SubmitAppAnalysisResponse
   */
  async submitAppAnalysis(request: $_model.SubmitAppAnalysisRequest): Promise<$_model.SubmitAppAnalysisResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.submitAppAnalysisWithOptions(request, headers, runtime);
  }

  /**
   * 提交主机巡检对象 manifest
   * 
   * @remarks
   * 校验 objectKey 归属、上传有效期、profile、schemaVersion、对象大小与 sha256，把任务置为 queued。首次提交返回 202；同一 inspectionId 与相同 sha256 的重复提交幂等返回 200 与当前任务状态。
   * 
   * @param request - SubmitHostInspectionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns SubmitHostInspectionResponse
   */
  async submitHostInspectionWithOptions(request: $_model.SubmitHostInspectionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.SubmitHostInspectionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.inspectionId)) {
      query["inspectionId"] = request.inspectionId;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.bytes)) {
      body["bytes"] = request.bytes;
    }

    if (!$dara.isNull(request.collectedAt)) {
      body["collectedAt"] = request.collectedAt;
    }

    if (!$dara.isNull(request.contentType)) {
      body["contentType"] = request.contentType;
    }

    if (!$dara.isNull(request.host)) {
      body["host"] = request.host;
    }

    if (!$dara.isNull(request.objectKey)) {
      body["objectKey"] = request.objectKey;
    }

    if (!$dara.isNull(request.profile)) {
      body["profile"] = request.profile;
    }

    if (!$dara.isNull(request.schemaVersion)) {
      body["schemaVersion"] = request.schemaVersion;
    }

    if (!$dara.isNull(request.sha256)) {
      body["sha256"] = request.sha256;
    }

    if (!$dara.isNull(request.window)) {
      body["window"] = request.window;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "SubmitHostInspection",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/submitHostInspection`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.SubmitHostInspectionResponse>(await this.callApi(params, req, runtime), new $_model.SubmitHostInspectionResponse({}));
  }

  /**
   * 提交主机巡检对象 manifest
   * 
   * @remarks
   * 校验 objectKey 归属、上传有效期、profile、schemaVersion、对象大小与 sha256，把任务置为 queued。首次提交返回 202；同一 inspectionId 与相同 sha256 的重复提交幂等返回 200 与当前任务状态。
   * 
   * @param request - SubmitHostInspectionRequest
   * @returns SubmitHostInspectionResponse
   */
  async submitHostInspection(request: $_model.SubmitHostInspectionRequest): Promise<$_model.SubmitHostInspectionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.submitHostInspectionWithOptions(request, headers, runtime);
  }

  /**
   * 启用或停用定时巡检计划
   * 
   * @param request - ToggleInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns ToggleInspectionScheduleResponse
   */
  async toggleInspectionScheduleWithOptions(request: $_model.ToggleInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.ToggleInspectionScheduleResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "ToggleInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/toggleInspectionSchedule`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.ToggleInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.ToggleInspectionScheduleResponse({}));
  }

  /**
   * 启用或停用定时巡检计划
   * 
   * @param request - ToggleInspectionScheduleRequest
   * @returns ToggleInspectionScheduleResponse
   */
  async toggleInspectionSchedule(request: $_model.ToggleInspectionScheduleRequest): Promise<$_model.ToggleInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.toggleInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * 立即触发一次定时巡检计划
   * 
   * @param request - TriggerInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns TriggerInspectionScheduleResponse
   */
  async triggerInspectionScheduleWithOptions(request: $_model.TriggerInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.TriggerInspectionScheduleResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "TriggerInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/triggerInspectionSchedule`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.TriggerInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.TriggerInspectionScheduleResponse({}));
  }

  /**
   * 立即触发一次定时巡检计划
   * 
   * @param request - TriggerInspectionScheduleRequest
   * @returns TriggerInspectionScheduleResponse
   */
  async triggerInspectionSchedule(request: $_model.TriggerInspectionScheduleRequest): Promise<$_model.TriggerInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.triggerInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * Uninstalls a specified version of a component.
   * 
   * @remarks
   * Calling this operation to uninstall an Agent is asynchronous. After the call, a task_id is returned. You can use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UninstallAgentRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UninstallAgentResponse
   */
  async uninstallAgentWithOptions(request: $_model.UninstallAgentRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UninstallAgentResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UninstallAgent",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/uninstall_agent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UninstallAgentResponse>(await this.callApi(params, req, runtime), new $_model.UninstallAgentResponse({}));
  }

  /**
   * Uninstalls a specified version of a component.
   * 
   * @remarks
   * Calling this operation to uninstall an Agent is asynchronous. After the call, a task_id is returned. You can use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UninstallAgentRequest
   * @returns UninstallAgentResponse
   */
  async uninstallAgent(request: $_model.UninstallAgentRequest): Promise<$_model.UninstallAgentResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uninstallAgentWithOptions(request, headers, runtime);
  }

  /**
   * Uninstalls a component from a cluster.
   * 
   * @param request - UninstallAgentForClusterRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UninstallAgentForClusterResponse
   */
  async uninstallAgentForClusterWithOptions(request: $_model.UninstallAgentForClusterRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UninstallAgentForClusterResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.clusterId)) {
      body["cluster_id"] = request.clusterId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UninstallAgentForCluster",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/uninstall_agent_by_cluster`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UninstallAgentForClusterResponse>(await this.callApi(params, req, runtime), new $_model.UninstallAgentForClusterResponse({}));
  }

  /**
   * Uninstalls a component from a cluster.
   * 
   * @param request - UninstallAgentForClusterRequest
   * @returns UninstallAgentForClusterResponse
   */
  async uninstallAgentForCluster(request: $_model.UninstallAgentForClusterRequest): Promise<$_model.UninstallAgentForClusterResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uninstallAgentForClusterWithOptions(request, headers, runtime);
  }

  /**
   * Uninstalls a specified version of a component.
   * 
   * @remarks
   * Calling this operation to uninstall an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UninstallAgentWithTypeRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UninstallAgentWithTypeResponse
   */
  async uninstallAgentWithTypeWithOptions(request: $_model.UninstallAgentWithTypeRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UninstallAgentWithTypeResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agentVersion"] = request.agentVersion;
    }

    if (!$dara.isNull(request.instanceType)) {
      body["instanceType"] = request.instanceType;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UninstallAgentWithType",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/uninstallAgent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UninstallAgentWithTypeResponse>(await this.callApi(params, req, runtime), new $_model.UninstallAgentWithTypeResponse({}));
  }

  /**
   * Uninstalls a specified version of a component.
   * 
   * @remarks
   * Calling this operation to uninstall an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UninstallAgentWithTypeRequest
   * @returns UninstallAgentWithTypeResponse
   */
  async uninstallAgentWithType(request: $_model.UninstallAgentWithTypeRequest): Promise<$_model.UninstallAgentWithTypeResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uninstallAgentWithTypeWithOptions(request, headers, runtime);
  }

  /**
   * Asynchronously uninstalls a CVE hotfix from a specified instance.
   * 
   * @remarks
   * Calling this API to install the agent is asynchronous. After you call this API, a task_id is returned. You can use this ID to call the GetHotfixTask API to obtain the execution status of the task.
   * 
   * @param request - UninstallHotfixRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UninstallHotfixResponse
   */
  async uninstallHotfixWithOptions(request: $_model.UninstallHotfixRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UninstallHotfixResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cveId)) {
      body["cveId"] = request.cveId;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UninstallHotfix",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/hotfix_manager/hotfix/uninstall`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UninstallHotfixResponse>(await this.callApi(params, req, runtime), new $_model.UninstallHotfixResponse({}));
  }

  /**
   * Asynchronously uninstalls a CVE hotfix from a specified instance.
   * 
   * @remarks
   * Calling this API to install the agent is asynchronous. After you call this API, a task_id is returned. You can use this ID to call the GetHotfixTask API to obtain the execution status of the task.
   * 
   * @param request - UninstallHotfixRequest
   * @returns UninstallHotfixResponse
   */
  async uninstallHotfix(request: $_model.UninstallHotfixRequest): Promise<$_model.UninstallHotfixResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uninstallHotfixWithOptions(request, headers, runtime);
  }

  /**
   * Updates the configuration of a component.
   * 
   * @remarks
   * After the configuration is updated, the new configuration is delivered to all resources to which the configuration is applied.
   * 
   * @param request - UpdateAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateAgentConfigResponse
   */
  async updateAgentConfigWithOptions(request: $_model.UpdateAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.configId)) {
      body["configId"] = request.configId;
    }

    if (!$dara.isNull(request.content)) {
      body["content"] = request.content;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/updateAgentConfig`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.UpdateAgentConfigResponse({}));
  }

  /**
   * Updates the configuration of a component.
   * 
   * @remarks
   * After the configuration is updated, the new configuration is delivered to all resources to which the configuration is applied.
   * 
   * @param request - UpdateAgentConfigRequest
   * @returns UpdateAgentConfigResponse
   */
  async updateAgentConfig(request: $_model.UpdateAgentConfigRequest): Promise<$_model.UpdateAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * Updates an alert contact.
   * 
   * @param request - UpdateAlertDestinationRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateAlertDestinationResponse
   */
  async updateAlertDestinationWithOptions(request: $_model.UpdateAlertDestinationRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateAlertDestinationResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.appId)) {
      body["app_id"] = request.appId;
    }

    if (!$dara.isNull(request.appSecret)) {
      body["app_secret"] = request.appSecret;
    }

    if (!$dara.isNull(request.groupId)) {
      body["group_id"] = request.groupId;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    if (!$dara.isNull(request.imbot)) {
      body["imbot"] = request.imbot;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.params)) {
      body["params"] = request.params;
    }

    if (!$dara.isNull(request.source)) {
      body["source"] = request.source;
    }

    if (!$dara.isNull(request.target)) {
      body["target"] = request.target;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateAlertDestination",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/updateDestination`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateAlertDestinationResponse>(await this.callApi(params, req, runtime), new $_model.UpdateAlertDestinationResponse({}));
  }

  /**
   * Updates an alert contact.
   * 
   * @param request - UpdateAlertDestinationRequest
   * @returns UpdateAlertDestinationResponse
   */
  async updateAlertDestination(request: $_model.UpdateAlertDestinationRequest): Promise<$_model.UpdateAlertDestinationResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateAlertDestinationWithOptions(request, headers, runtime);
  }

  /**
   * Updates the status of a push alert policy.
   * 
   * @param request - UpdateAlertEnabledRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateAlertEnabledResponse
   */
  async updateAlertEnabledWithOptions(request: $_model.UpdateAlertEnabledRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateAlertEnabledResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateAlertEnabled",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/updateEnabled`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateAlertEnabledResponse>(await this.callApi(params, req, runtime), new $_model.UpdateAlertEnabledResponse({}));
  }

  /**
   * Updates the status of a push alert policy.
   * 
   * @param request - UpdateAlertEnabledRequest
   * @returns UpdateAlertEnabledResponse
   */
  async updateAlertEnabled(request: $_model.UpdateAlertEnabledRequest): Promise<$_model.UpdateAlertEnabledResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateAlertEnabledWithOptions(request, headers, runtime);
  }

  /**
   * Updates a push alert policy.
   * 
   * @param request - UpdateAlertStrategyRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateAlertStrategyResponse
   */
  async updateAlertStrategyWithOptions(request: $_model.UpdateAlertStrategyRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateAlertStrategyResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    if (!$dara.isNull(request.k8sLabel)) {
      body["k8sLabel"] = request.k8sLabel;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.strategy)) {
      body["strategy"] = request.strategy;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateAlertStrategy",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/alertPusher/alert/updateStrategy`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateAlertStrategyResponse>(await this.callApi(params, req, runtime), new $_model.UpdateAlertStrategyResponse({}));
  }

  /**
   * Updates a push alert policy.
   * 
   * @param request - UpdateAlertStrategyRequest
   * @returns UpdateAlertStrategyResponse
   */
  async updateAlertStrategy(request: $_model.UpdateAlertStrategyRequest): Promise<$_model.UpdateAlertStrategyResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateAlertStrategyWithOptions(request, headers, runtime);
  }

  /**
   * Updates the component configuration of a cluster.
   * 
   * @param request - UpdateClusterAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateClusterAgentConfigResponse
   */
  async updateClusterAgentConfigWithOptions(request: $_model.UpdateClusterAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateClusterAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.clusterId)) {
      body["clusterId"] = request.clusterId;
    }

    if (!$dara.isNull(request.configId)) {
      body["configId"] = request.configId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateClusterAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/updateClusterAgentConfig`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateClusterAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.UpdateClusterAgentConfigResponse({}));
  }

  /**
   * Updates the component configuration of a cluster.
   * 
   * @param request - UpdateClusterAgentConfigRequest
   * @returns UpdateClusterAgentConfigResponse
   */
  async updateClusterAgentConfig(request: $_model.UpdateClusterAgentConfigRequest): Promise<$_model.UpdateClusterAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateClusterAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * Updates the title or archive status of a specified session.
   * 
   * @remarks
   * - Only sessions of the current user can be modified.
   * - You must provide a non-null value for at least one of the name and status parameters. Unprovided fields remain unchanged.
   * - You can modify the title when an active execution is in progress, but you cannot modify the session status.
   * - Archiving retains the history. After a session is restored, you can continue to send messages.
   * 
   * @param request - UpdateCopilotSessionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateCopilotSessionResponse
   */
  async updateCopilotSessionWithOptions(sessionId: string, request: $_model.UpdateCopilotSessionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateCopilotSessionResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.status)) {
      body["status"] = request.status;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateCopilotSession",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/copilot/sessions/${$dara.URL.percentEncode(sessionId)}`,
      method: "PATCH",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateCopilotSessionResponse>(await this.callApi(params, req, runtime), new $_model.UpdateCopilotSessionResponse({}));
  }

  /**
   * Updates the title or archive status of a specified session.
   * 
   * @remarks
   * - Only sessions of the current user can be modified.
   * - You must provide a non-null value for at least one of the name and status parameters. Unprovided fields remain unchanged.
   * - You can modify the title when an active execution is in progress, but you cannot modify the session status.
   * - Archiving retains the history. After a session is restored, you can continue to send messages.
   * 
   * @param request - UpdateCopilotSessionRequest
   * @returns UpdateCopilotSessionResponse
   */
  async updateCopilotSession(sessionId: string, request: $_model.UpdateCopilotSessionRequest): Promise<$_model.UpdateCopilotSessionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateCopilotSessionWithOptions(sessionId, request, headers, runtime);
  }

  /**
   * Updates the attention level of an anomaly item. Adjusting the attention level affects the sensitivity of the anomaly detection algorithm.
   * 
   * @param request - UpdateEventsAttentionRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateEventsAttentionResponse
   */
  async updateEventsAttentionWithOptions(request: $_model.UpdateEventsAttentionRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateEventsAttentionResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.mode)) {
      body["mode"] = request.mode;
    }

    if (!$dara.isNull(request.range)) {
      body["range"] = request.range;
    }

    if (!$dara.isNull(request.uuid)) {
      body["uuid"] = request.uuid;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateEventsAttention",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/proxy/post/cluster_update_events_attention`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateEventsAttentionResponse>(await this.callApi(params, req, runtime), new $_model.UpdateEventsAttentionResponse({}));
  }

  /**
   * Updates the attention level of an anomaly item. Adjusting the attention level affects the sensitivity of the anomaly detection algorithm.
   * 
   * @param request - UpdateEventsAttentionRequest
   * @returns UpdateEventsAttentionResponse
   */
  async updateEventsAttention(request: $_model.UpdateEventsAttentionRequest): Promise<$_model.UpdateEventsAttentionResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateEventsAttentionWithOptions(request, headers, runtime);
  }

  /**
   * Updates the configuration of a service feature module.
   * 
   * @remarks
   * - Populate parameters according to the general LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned data from a string to a dict before use. Refer to the general LLM service response format.
   * 
   * @param tmpReq - UpdateFuncSwitchRecordRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateFuncSwitchRecordResponse
   */
  async updateFuncSwitchRecordWithOptions(tmpReq: $_model.UpdateFuncSwitchRecordRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateFuncSwitchRecordResponse> {
    tmpReq.validate();
    let request = new $_model.UpdateFuncSwitchRecordShrinkRequest({ });
    OpenApiUtil.convert(tmpReq, request);
    if (!$dara.isNull(tmpReq.params)) {
      request.paramsShrink = OpenApiUtil.arrayToStringWithSpecifiedStyle(tmpReq.params, "params", "json");
    }

    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.channel)) {
      query["channel"] = request.channel;
    }

    if (!$dara.isNull(request.paramsShrink)) {
      query["params"] = request.paramsShrink;
    }

    if (!$dara.isNull(request.serviceName)) {
      query["service_name"] = request.serviceName;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateFuncSwitchRecord",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/func-switch/update-service-func-switch`,
      method: "GET",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateFuncSwitchRecordResponse>(await this.callApi(params, req, runtime), new $_model.UpdateFuncSwitchRecordResponse({}));
  }

  /**
   * Updates the configuration of a service feature module.
   * 
   * @remarks
   * - Populate parameters according to the general LLM service input parameters, convert them to a string, and assign the string to llmParamString.
   * - Convert the returned data from a string to a dict before use. Refer to the general LLM service response format.
   * 
   * @param request - UpdateFuncSwitchRecordRequest
   * @returns UpdateFuncSwitchRecordResponse
   */
  async updateFuncSwitchRecord(request: $_model.UpdateFuncSwitchRecordRequest): Promise<$_model.UpdateFuncSwitchRecordResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateFuncSwitchRecordWithOptions(request, headers, runtime);
  }

  /**
   * 编辑定时巡检计划
   * 
   * @param request - UpdateInspectionScheduleRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateInspectionScheduleResponse
   */
  async updateInspectionScheduleWithOptions(request: $_model.UpdateInspectionScheduleRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateInspectionScheduleResponse> {
    request.validate();
    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.cronExpr)) {
      body["cronExpr"] = request.cronExpr;
    }

    if (!$dara.isNull(request.enabled)) {
      body["enabled"] = request.enabled;
    }

    if (!$dara.isNull(request.fireTime)) {
      body["fireTime"] = request.fireTime;
    }

    if (!$dara.isNull(request.id)) {
      body["id"] = request.id;
    }

    if (!$dara.isNull(request.inspectionType)) {
      body["inspectionType"] = request.inspectionType;
    }

    if (!$dara.isNull(request.minSeverity)) {
      body["minSeverity"] = request.minSeverity;
    }

    if (!$dara.isNull(request.name)) {
      body["name"] = request.name;
    }

    if (!$dara.isNull(request.notifyDestinations)) {
      body["notifyDestinations"] = request.notifyDestinations;
    }

    if (!$dara.isNull(request.scheduleType)) {
      body["scheduleType"] = request.scheduleType;
    }

    if (!$dara.isNull(request.target)) {
      body["target"] = request.target;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateInspectionSchedule",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/inspectionAgent/updateInspectionSchedule`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateInspectionScheduleResponse>(await this.callApi(params, req, runtime), new $_model.UpdateInspectionScheduleResponse({}));
  }

  /**
   * 编辑定时巡检计划
   * 
   * @param request - UpdateInspectionScheduleRequest
   * @returns UpdateInspectionScheduleResponse
   */
  async updateInspectionSchedule(request: $_model.UpdateInspectionScheduleRequest): Promise<$_model.UpdateInspectionScheduleResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateInspectionScheduleWithOptions(request, headers, runtime);
  }

  /**
   * Updates the component configurations of an instance.
   * 
   * @param request - UpdateInstanceAgentConfigRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpdateInstanceAgentConfigResponse
   */
  async updateInstanceAgentConfigWithOptions(request: $_model.UpdateInstanceAgentConfigRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpdateInstanceAgentConfigResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.configId)) {
      body["configId"] = request.configId;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpdateInstanceAgentConfig",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/updateInstanceAgentConfig`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpdateInstanceAgentConfigResponse>(await this.callApi(params, req, runtime), new $_model.UpdateInstanceAgentConfigResponse({}));
  }

  /**
   * Updates the component configurations of an instance.
   * 
   * @param request - UpdateInstanceAgentConfigRequest
   * @returns UpdateInstanceAgentConfigResponse
   */
  async updateInstanceAgentConfig(request: $_model.UpdateInstanceAgentConfigRequest): Promise<$_model.UpdateInstanceAgentConfigResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.updateInstanceAgentConfigWithOptions(request, headers, runtime);
  }

  /**
   * Updates an installed component to a specified version.
   * 
   * @remarks
   * Calling this operation to update an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UpgradeAgentRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpgradeAgentResponse
   */
  async upgradeAgentWithOptions(request: $_model.UpgradeAgentRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpgradeAgentResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpgradeAgent",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/upgrade_agent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpgradeAgentResponse>(await this.callApi(params, req, runtime), new $_model.UpgradeAgentResponse({}));
  }

  /**
   * Updates an installed component to a specified version.
   * 
   * @remarks
   * Calling this operation to update an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UpgradeAgentRequest
   * @returns UpgradeAgentResponse
   */
  async upgradeAgent(request: $_model.UpgradeAgentRequest): Promise<$_model.UpgradeAgentResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.upgradeAgentWithOptions(request, headers, runtime);
  }

  /**
   * Updates a component for a cluster.
   * 
   * @param request - UpgradeAgentForClusterRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpgradeAgentForClusterResponse
   */
  async upgradeAgentForClusterWithOptions(request: $_model.UpgradeAgentForClusterRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpgradeAgentForClusterResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agent_id"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agent_version"] = request.agentVersion;
    }

    if (!$dara.isNull(request.clusterId)) {
      body["cluster_id"] = request.clusterId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpgradeAgentForCluster",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/upgrade_agent_by_cluster`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpgradeAgentForClusterResponse>(await this.callApi(params, req, runtime), new $_model.UpgradeAgentForClusterResponse({}));
  }

  /**
   * Updates a component for a cluster.
   * 
   * @param request - UpgradeAgentForClusterRequest
   * @returns UpgradeAgentForClusterResponse
   */
  async upgradeAgentForCluster(request: $_model.UpgradeAgentForClusterRequest): Promise<$_model.UpgradeAgentForClusterResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.upgradeAgentForClusterWithOptions(request, headers, runtime);
  }

  /**
   * Updates the version of an installed component to a specified version.
   * 
   * @remarks
   * Calling this operation to update an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UpgradeAgentWithTypeRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UpgradeAgentWithTypeResponse
   */
  async upgradeAgentWithTypeWithOptions(request: $_model.UpgradeAgentWithTypeRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UpgradeAgentWithTypeResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.agentId)) {
      body["agentId"] = request.agentId;
    }

    if (!$dara.isNull(request.agentVersion)) {
      body["agentVersion"] = request.agentVersion;
    }

    if (!$dara.isNull(request.instanceType)) {
      body["instanceType"] = request.instanceType;
    }

    if (!$dara.isNull(request.instances)) {
      body["instances"] = request.instances;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UpgradeAgentWithType",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/am/agent/upgradeAgent`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "json",
      bodyType: "json",
    });
    return $dara.cast<$_model.UpgradeAgentWithTypeResponse>(await this.callApi(params, req, runtime), new $_model.UpgradeAgentWithTypeResponse({}));
  }

  /**
   * Updates the version of an installed component to a specified version.
   * 
   * @remarks
   * Calling this operation to update an Agent is asynchronous. After the call, a task_id is returned. Use this ID to call the GetAgentTask operation to retrieve the execution status of the task.
   * 
   * @param request - UpgradeAgentWithTypeRequest
   * @returns UpgradeAgentWithTypeResponse
   */
  async upgradeAgentWithType(request: $_model.UpgradeAgentWithTypeRequest): Promise<$_model.UpgradeAgentWithTypeResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.upgradeAgentWithTypeWithOptions(request, headers, runtime);
  }

  /**
   * 上传离线诊断结果
   * 
   * @param request - UploadDiagnosisResultRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UploadDiagnosisResultResponse
   */
  async uploadDiagnosisResultWithOptions(request: $_model.UploadDiagnosisResultRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UploadDiagnosisResultResponse> {
    request.validate();
    let query : {[key: string ]: any} = { };
    if (!$dara.isNull(request.xDebugId)) {
      query["X-Debug-Id"] = request.xDebugId;
    }

    if (!$dara.isNull(request.xSysomInvokeSource)) {
      query["x-sysom-invoke-source"] = request.xSysomInvokeSource;
    }

    let body : {[key: string ]: any} = { };
    if (!$dara.isNull(request.contentEncoding)) {
      body["contentEncoding"] = request.contentEncoding;
    }

    if (!$dara.isNull(request.files)) {
      body["files"] = request.files;
    }

    if (!$dara.isNull(request.results)) {
      body["results"] = request.results;
    }

    if (!$dara.isNull(request.taskId)) {
      body["taskId"] = request.taskId;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      query: OpenApiUtil.query(query),
      body: OpenApiUtil.parseToMap(body),
    });
    let params = new $OpenApiUtil.Params({
      action: "UploadDiagnosisResult",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/openapi/offlineDiagnosis/uploadResult`,
      method: "POST",
      authType: "AK",
      style: "ROA",
      reqBodyType: "formData",
      bodyType: "json",
    });
    return $dara.cast<$_model.UploadDiagnosisResultResponse>(await this.callApi(params, req, runtime), new $_model.UploadDiagnosisResultResponse({}));
  }

  /**
   * 上传离线诊断结果
   * 
   * @param request - UploadDiagnosisResultRequest
   * @returns UploadDiagnosisResultResponse
   */
  async uploadDiagnosisResult(request: $_model.UploadDiagnosisResultRequest): Promise<$_model.UploadDiagnosisResultResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uploadDiagnosisResultWithOptions(request, headers, runtime);
  }

  /**
   * 上传 SuperBox 附件的单个分片（请求体为裸二进制）
   * 
   * @param request - UploadFilePartRequest
   * @param headers - map
   * @param runtime - runtime options for this request RuntimeOptions
   * @returns UploadFilePartResponse
   */
  async uploadFilePartWithOptions(fileId: string, partNumber: string, request: $_model.UploadFilePartRequest, headers: {[key: string ]: string}, runtime: $dara.RuntimeOptions): Promise<$_model.UploadFilePartResponse> {
    request.validate();
    let body : Buffer = null;
    if (!$dara.isNull(request.body)) {
      body = request.body;
    }

    let req = new $OpenApiUtil.OpenApiRequest({
      headers: headers,
      body: body,
    });
    let params = new $OpenApiUtil.Params({
      action: "UploadFilePart",
      version: "2023-12-30",
      protocol: "HTTPS",
      pathname: `/api/v1/aiObservAgent/files/uploads/${$dara.URL.percentEncode(fileId)}/parts/${$dara.URL.percentEncode(partNumber)}`,
      method: "PUT",
      authType: "AK",
      style: "ROA",
      reqBodyType: "byte",
      bodyType: "json",
    });
    return $dara.cast<$_model.UploadFilePartResponse>(await this.callApi(params, req, runtime), new $_model.UploadFilePartResponse({}));
  }

  /**
   * 上传 SuperBox 附件的单个分片（请求体为裸二进制）
   * 
   * @param request - UploadFilePartRequest
   * @returns UploadFilePartResponse
   */
  async uploadFilePart(fileId: string, partNumber: string, request: $_model.UploadFilePartRequest): Promise<$_model.UploadFilePartResponse> {
    let runtime = new $dara.RuntimeOptions({ });
    let headers : {[key: string ]: string} = { };
    return await this.uploadFilePartWithOptions(fileId, partNumber, request, headers, runtime);
  }

}
