// This file is auto-generated, don't edit it
import * as $dara from '@darabonba/typescript';


import * as $_model from './connectIdcChannelModels/model';
export * from './connectIdcChannelModels/model';

export default class Client {


}
