#ifndef __GX_H__
#define __GX_H__

#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>

#define GX_EXPORT_API __attribute__((visibility("default")))

#define GX_LIB_PATH "/usr/lib64/libgx.so"
#define GX_CLIENT_LIB_PATH "/usr/lib64/libgx_client.so"

static inline const char *get_GX_LIB_PATH()
{
    char *result = getenv("GX_LIB_PATH");
    if (!result || access(result, F_OK))
        return GX_LIB_PATH;

    return result;
}

static inline const char *get_GX_CLIENT_LIB_PATH()
{
    char *result = getenv("GX_CLIENT_LIB_PATH");
    if (!result || access(result, F_OK))
        return GX_CLIENT_LIB_PATH;

    return result;
}

struct queue_callback;
#ifdef __cplusplus
extern "C" {
#endif

GX_EXPORT_API void gx_set_vram_alloc_raw(size_t size);

#define GX_FIXUP_NV_FABRIC_MANAGER      0x1UL
GX_EXPORT_API int gx_fixup(unsigned long flags);

GX_EXPORT_API void gx_queue_register_callback(struct queue_callback *qcb);
GX_EXPORT_API void gx_queue_unregister_callback(struct queue_callback *qcb);
GX_EXPORT_API int gx_func_register_hook(const char *name,
                                        void *new_hook_addr,
                                        void **real_addr);
GX_EXPORT_API int gx_func_unregister_hook(const char *name,
                                          void *new_hook_addr);

struct dtod_req {
    uint64_t        paddr_src;
    uint64_t        paddr_dst;
    size_t          size;
};

#ifdef __cplusplus
}
#endif

#endif /* __GX_H__ */
